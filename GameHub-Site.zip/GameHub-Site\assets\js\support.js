/* ==========================================================================
   游集 GAMEHUB — support.js
   客服页：FAQ 单开手风琴 / 工单校验与成功态 / 字数计数
   ========================================================================== */

(function () {
  'use strict';

  var doc = document;
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var TICKET_NO = 'GH-20261112-0421';

  /* ======================================================================
     1. FAQ：同一时间只展开一条
     ====================================================================== */
  function initFaq() {
    var items = doc.querySelectorAll('.faq-item');
    if (!items.length) return;

    Array.prototype.forEach.call(items, function (item) {
      item.addEventListener('toggle', function () {
        if (!item.open) return;
        Array.prototype.forEach.call(items, function (other) {
          if (other !== item && other.open) other.open = false;
        });
      });
    });
  }

  /* ======================================================================
     2. 工单表单
     ====================================================================== */
  function initForm() {
    var form = doc.getElementById('ticketForm');
    if (!form) return;

    var type = doc.getElementById('tType');
    var email = doc.getElementById('tEmail');
    var order = doc.getElementById('tOrder');
    var desc = doc.getElementById('tDesc');
    var count = doc.getElementById('tCount');
    var error = doc.getElementById('ticketError');
    var success = doc.getElementById('ticketSuccess');
    var successEmail = doc.getElementById('successEmail');
    var ticketNo = doc.getElementById('ticketNo');
    var again = doc.getElementById('ticketAgain');

    function mark(input, invalid) {
      var field = input && input.closest ? input.closest('.field') : null;
      if (field) field.setAttribute('data-invalid', invalid ? 'true' : 'false');
    }

    function clearMarks() {
      var fields = form.querySelectorAll('.field');
      for (var i = 0; i < fields.length; i++) fields[i].removeAttribute('data-invalid');
    }

    /* 字数计数 */
    desc.addEventListener('input', function () {
      count.textContent = String(desc.value.length);
      if (desc.value.trim().length >= 10) mark(desc, false);
    });

    [type, email, desc].forEach(function (input) {
      input.addEventListener('input', function () { mark(input, false); });
      input.addEventListener('change', function () { mark(input, false); });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();

      var msg = '';
      var target = null;

      if (!type.value) {
        msg = '请选择问题类型';
        target = type;
      } else if (!EMAIL_RE.test(email.value.trim())) {
        msg = '请填写有效的联系邮箱，方便我们回复';
        target = email;
      } else if (desc.value.trim().length < 10) {
        msg = '问题描述至少写 10 个字，方便我们一次看懂';
        target = desc;
      }

      clearMarks();
      if (target) mark(target, true);

      if (msg) {
        error.textContent = msg;
        error.hidden = false;
        if (target) target.focus();
        return;
      }

      error.hidden = true;

      successEmail.textContent = email.value.trim();
      ticketNo.textContent = TICKET_NO;

      form.hidden = true;
      success.hidden = false;
      success.setAttribute('tabindex', '-1');
      success.focus({ preventScroll: true });
      success.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });

    again.addEventListener('click', function () {
      form.reset();
      count.textContent = '0';
      clearMarks();
      error.hidden = true;
      success.hidden = true;
      form.hidden = false;
      type.focus();
    });
  }

  /* ======================================================================
     启动
     ====================================================================== */
  function init() {
    initFaq();
    initForm();
  }

  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', init);
  else init();
})();
