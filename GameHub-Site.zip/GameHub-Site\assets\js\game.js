/* ==========================================================================
   游集 GAMEHUB — game.js
   详情页：数据装配 / 截图灯箱 / 购买与愿望单状态 / 相似推荐
   依赖：games.js（数据）、cover.js（封面与静帧）、app.js（公共组件）
   ========================================================================== */

(function () {
  'use strict';

  var doc = document;
  var GH = window.GameHub;
  var DATA = (window.GAME_DATA || []).slice();
  var OWNED_KEY = 'gamehub.owned';
  var SHOT_COUNT = 6;

  var el = {};
  var game = null;
  var lbIndex = 0;
  var lbBuilt = false;

  function esc(s) { return GH.escape(s); }

  /* ======================================================================
     文案素材
     ====================================================================== */
  var GENRE_NOTES = {
    '动作角色扮演': '以即时战斗推进角色成长，装备、技能与数值构筑决定你面对强敌时的解法。',
    '魂类': '强调风险与回报的取舍，死亡是学习的一部分，地图与敌人配置本身就在讲故事。',
    '开放世界': '地图不靠清单驱动，而是用看得见的地标把你从主线上拐走。',
    '第一人称射击': '枪械手感与关卡节奏是核心，掩体、弹药与站位决定每一次交火的走向。',
    '角色扮演': '分支、对话与队伍养成共同塑造走向，不同选择会改写结局。',
    '策略': '资源、地形与时机互为约束，胜负往往在开局之前就已经写好一半。',
    '模拟经营': '从一条产线、一块田地开始，把混乱慢慢整理成秩序。',
    '独立': '体量不大，但通常有一个非常明确的作者表达。',
    '恐怖生存': '资源永远不够，逃跑往往比战斗更划算。',
    '解谜': '规则先于故事，理解规则的那一刻就是解谜的高潮。',
    '竞速': '线路、刹车点与车辆调校构成一条可以被反复打磨的时间曲线。',
    '体育': '规则熟悉，难在细节操作与临场判断。',
    '动作冒险': '探索、战斗与叙事交替推进，节奏由你自己掌握。',
    '平台跳跃': '手感与关卡设计决定一切，失败快、重来也快。',
    'Roguelike': '每一局都是新的组合，失败会变成下一局的资源。',
    '视觉小说': '以文本与演出推进，选择比操作更重要。',
    '回合制': '把战斗拆成可计算的步骤，情报与配队大于手速。',
    '沙盒': '没有唯一正解，你的目标由自己定义。',
    '音乐': '节奏与操作绑定，音轨本身就是关卡设计。',
    '战术射击': '一枪定生死，信息、走位与队伍配合优先于反应速度。'
  };

  function scoreNote(score) {
    if (score >= 90) return '站内 ' + score + ' 分，属于这一类型里第一梯队的水准。';
    if (score >= 80) return '站内 ' + score + ' 分，整体完成度不错，个别环节仍能看出取舍。';
    return '站内 ' + score + ' 分，更适合对这类题材本来就有偏好的玩家。';
  }

  function priceNote(g) {
    if (!g.price) return '本作免费收录，点一下就能入库。';
    if (g.discount) {
      return '当前 ' + g.discount + '% 折扣，折后 ¥' + GH.render.finalPrice(g) + '，是入库的好时机。';
    }
    return '原价 ¥' + g.price + '，目前没有折扣。';
  }

  function descHtml(g) {
    var note = GENRE_NOTES[g.genre] || '这部作品属于「' + g.genre + '」类型，玩法重心与同类作品有明显差别。';
    var tags = g.tags.length ? g.tags : [g.genre];

    return (
      '<p>' + esc(g.cn) + '（' + esc(g.en) + '）由 ' + esc(g.dev) + ' 开发、' + esc(g.pub) +
      ' 于 ' + g.year + ' 年发行，是一部' + esc(g.genre) + '作品。' + esc(g.blurb) + '</p>' +
      '<p>' + esc(note) + '</p>' +
      '<h3>值得注意的地方</h3>' +
      '<ul>' +
      '<li>' + esc(scoreNote(g.score)) + '</li>' +
      '<li>题材标签是「' + esc(tags.join('」「')) + '」，如果你本来就在找这个方向，优先级可以往前排。</li>' +
      '<li>' + esc(priceNote(g)) + '</li>' +
      '</ul>' +
      '<h3>收录说明</h3>' +
      '<p>' + g.year + ' 年发行，本次收录的平台版本为 ' + esc(g.platforms.join(' / ')) +
      '。站内评分由编辑部单人游玩后给出，不包含多人模式与后续 DLC 的评价，因此只代表这一版作品本身。</p>'
    );
  }

  /* ======================================================================
     本地"已拥有"记录（演示用）
     ====================================================================== */
  function getOwned() {
    try {
      var arr = JSON.parse(localStorage.getItem(OWNED_KEY) || '[]');
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      return [];
    }
  }

  function saveOwned(list) {
    try { localStorage.setItem(OWNED_KEY, JSON.stringify(list)); } catch (e) { /* 忽略 */ }
  }

  function isOwned(id) { return getOwned().indexOf(id) >= 0; }

  /* ======================================================================
     渲染
     ====================================================================== */
  function renderHead(g) {
    var cover = window.CoverEngine ? window.CoverEngine.render(g) : '';
    if (cover) {
      var img = doc.createElement('img');
      img.src = cover;
      img.alt = g.cn + ' 封面';
      img.width = 600;
      img.height = 800;
      el.cover.appendChild(img);
    }

    if (g.discount) {
      el.coverFlag.textContent = '-' + g.discount + '%';
      el.coverFlag.hidden = false;
    }
    el.coverScore.textContent = g.score;
    el.coverScore.setAttribute('data-tier', g.score >= 90 ? 'high' : g.score >= 80 ? 'mid' : 'low');

    el.kicker.textContent = '作品详情 · ' + g.genre;
    el.title.textContent = g.cn;
    el.titleEn.textContent = g.en + ' · ' + g.year;

    el.tags.innerHTML =
      '<a class="chip chip--sm" href="category.html?genre=' + encodeURIComponent(g.genre) + '">' + esc(g.genre) + '</a>' +
      g.tags.map(function (t) {
        return '<span class="chip chip--sm chip--static">' + esc(t) + '</span>';
      }).join('');

    el.blurb.textContent = g.blurb;
    el.dev.textContent = g.dev;
    el.pub.textContent = g.pub;
    el.year.textContent = g.year;
    el.platforms.textContent = g.platforms.join(' / ');

    /* 购买卡 */
    if (!g.price) {
      el.price.textContent = '免费';
      el.price.className = 'gd-buy__price gd-buy__price--free';
    } else {
      el.price.textContent = '¥' + GH.render.finalPrice(g);
      if (g.discount) {
        el.was.textContent = '¥' + g.price;
        el.was.hidden = false;
        el.off.textContent = '-' + g.discount + '%';
        el.off.hidden = false;
      }
    }

    el.scoreText.textContent = g.score + ' / 100';
    el.idText.textContent = '#' + g.id;

    /* 面包屑与标题 */
    el.crumbGenre.textContent = g.genre;
    el.crumbGenre.href = 'category.html?genre=' + encodeURIComponent(g.genre);
    el.crumbNow.textContent = g.cn;

    doc.title = g.cn + ' · 游集 GAMEHUB';
    var meta = doc.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', g.cn + '（' + g.en + '，' + g.year + '）· ' + g.genre + '：' + g.blurb);

    /* 背景 */
    if (window.CoverEngine) {
      var bg = doc.createElement('img');
      bg.src = window.CoverEngine.renderShot(g, 0);
      bg.alt = '';
      bg.setAttribute('aria-hidden', 'true');
      el.backdrop.appendChild(bg);
    }
  }

  function renderShots(g) {
    var html = '';
    for (var i = 0; i < SHOT_COUNT; i++) {
      html += '<button class="gd-shot" type="button" data-shot="' + i + '" aria-label="放大查看场景 ' + (i + 1) + '">' +
        '<span class="gd-shot__cap">场景 ' + (i + 1 < 10 ? '0' + (i + 1) : i + 1) + '</span>' +
        '<span class="gd-shot__zoom" aria-hidden="true">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5M11 8.5v5M8.5 11h5"/></svg>' +
        '</span></button>';
    }
    el.shots.innerHTML = html;
    el.shotsCount.textContent = SHOT_COUNT + ' 张静帧';

    var nodes = el.shots.querySelectorAll('[data-shot]');
    for (var k = 0; k < nodes.length; k++) {
      window.CoverEngine.renderShotInto(nodes[k], g, k);
    }
  }

  function renderBody(g) {
    el.desc.innerHTML = descHtml(g);

    var rows = [
      ['中文名', g.cn],
      ['英文名', g.en],
      ['开发商', g.dev],
      ['发行商', g.pub],
      ['发行年份', g.year],
      ['类型', g.genre],
      ['平台', g.platforms.join(' / ')],
      ['站内评分', g.score + ' / 100'],
      ['收录编号', '#' + g.id]
    ];
    el.specs.innerHTML = rows.map(function (r) {
      return '<div><dt>' + esc(r[0]) + '</dt><dd>' + esc(r[1]) + '</dd></div>';
    }).join('');

    el.sideTags.innerHTML =
      '<a class="chip chip--sm" href="category.html?genre=' + encodeURIComponent(g.genre) + '">' + esc(g.genre) + '</a>' +
      g.tags.map(function (t) {
        return '<span class="chip chip--sm chip--static">' + esc(t) + '</span>';
      }).join('');
  }

  function renderRelated(g) {
    var list = DATA.filter(function (x) {
      return x.genre === g.genre && x.id !== g.id;
    }).sort(function (a, b) {
      return b.score - a.score || b.year - a.year;
    }).slice(0, 6);

    if (!list.length) {
      el.relatedSection.hidden = true;
      return false;
    }

    GH.render.cards(el.related, list);
    el.relatedSub.textContent = '同为「' + g.genre + '」，按站内评分排序';
    el.relatedMore.href = 'category.html?genre=' + encodeURIComponent(g.genre);
    el.relatedMore.textContent = '查看全部 ' + GH.data.byGenre(g.genre) + ' 部 →';
    return true;
  }

  /* ======================================================================
     状态同步
     ====================================================================== */
  function syncWish(g) {
    var on = GH.wishlist.has(g.id);
    el.wishBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
    el.wishText.textContent = on ? '已在愿望单' : '加入愿望单';
  }

  function syncOwned(g) {
    var owned = isOwned(g.id);
    var signedIn = !!GH.auth.get();

    if (owned) {
      el.buyBtn.textContent = '已在库中';
      el.buyBtn.disabled = true;
      el.buyState.textContent = '已购买 · 可在客户端下载游玩';
      el.buy.classList.add('is-owned');
    } else if (!signedIn) {
      el.buyBtn.textContent = g.price ? '登录并购买' : '登录后免费领取';
      el.buyState.textContent = '登录后可购买，购买一次即永久入库';
    } else {
      el.buyBtn.textContent = g.price ? '立即购买' : '免费领取';
      el.buyState.textContent = '购买后永久入库，支持云存档同步';
    }
  }

  function buy() {
    if (!game) return;
    if (isOwned(game.id)) return;

    if (!GH.auth.get()) {
      GH.ui.toast('请先登录，再回来完成购买');
      window.setTimeout(function () {
        window.location.href = 'login.html?next=' + encodeURIComponent('game.html?id=' + game.id);
      }, 700);
      return;
    }

    el.buyBtn.classList.add('is-loading');
    el.buyBtn.textContent = '正在创建订单…';

    window.setTimeout(function () {
      var list = getOwned();
      if (list.indexOf(game.id) < 0) list.push(game.id);
      saveOwned(list);
      el.buyBtn.classList.remove('is-loading');
      syncOwned(game);
      GH.ui.toast((game.price ? '购买成功' : '已领取') + '，已在游戏库中');
    }, 950);
  }

  /* ======================================================================
     截图灯箱
     ====================================================================== */
  function buildLb() {
    if (lbBuilt) return;
    lbBuilt = true;

    el.lb = doc.createElement('div');
    el.lb.className = 'modal gd-lb';
    el.lb.hidden = true;
    el.lb.setAttribute('role', 'dialog');
    el.lb.setAttribute('aria-modal', 'true');
    el.lb.setAttribute('aria-label', '截图浏览');
    el.lb.innerHTML =
      '<div class="modal__scrim" data-modal-close></div>' +
      '<div class="modal__panel">' +
      '<div class="gd-lb__head">' +
      '<span id="gdLbCap">场景 1 / ' + SHOT_COUNT + '</span>' +
      '<button class="icon-btn modal__close" type="button" data-modal-close aria-label="关闭">' +
      '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>' +
      '</button>' +
      '</div>' +
      '<div class="gd-lb__stage"><img id="gdLbImg" alt=""></div>' +
      '<div class="gd-lb__foot">' +
      '<button class="gd-lb__btn" type="button" data-lb-prev>' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>上一个</button>' +
      '<span class="gd-lb__dots" id="gdLbDots"></span>' +
      '<button class="gd-lb__btn" type="button" data-lb-next>下一个' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg></button>' +
      '</div>' +
      '</div>';

    doc.body.appendChild(el.lb);

    el.lbImg = el.lb.querySelector('#gdLbImg');
    el.lbCap = el.lb.querySelector('#gdLbCap');
    el.lbDots = el.lb.querySelector('#gdLbDots');

    var dotsHtml = '';
    for (var i = 0; i < SHOT_COUNT; i++) dotsHtml += '<span class="gd-lb__dot"></span>';
    el.lbDots.innerHTML = dotsHtml;

    el.lb.addEventListener('click', function (e) {
      if (e.target.closest('[data-lb-prev]')) paintLb(lbIndex - 1);
      else if (e.target.closest('[data-lb-next]')) paintLb(lbIndex + 1);
    });

    doc.addEventListener('keydown', function (e) {
      if (!el.lb.classList.contains('is-open')) return;
      if (e.key === 'ArrowLeft') paintLb(lbIndex - 1);
      else if (e.key === 'ArrowRight') paintLb(lbIndex + 1);
    });
  }

  function paintLb(i) {
    if (!game) return;
    var n = SHOT_COUNT;
    lbIndex = (i % n + n) % n;
    el.lbImg.src = window.CoverEngine.renderShot(game, lbIndex);
    el.lbImg.alt = game.cn + ' 场景 ' + (lbIndex + 1);
    el.lbCap.textContent = '场景 ' + (lbIndex + 1) + ' / ' + n + ' · ' + game.cn;
    var dots = el.lbDots.children;
    for (var k = 0; k < dots.length; k++) {
      dots[k].setAttribute('aria-current', k === lbIndex ? 'true' : 'false');
    }
  }

  function openLb(i) {
    buildLb();
    paintLb(i);
    GH.ui.openModal(el.lb);
  }

  /* ======================================================================
     绑定
     ====================================================================== */
  function bind(g) {
    el.buyBtn.addEventListener('click', buy);

    el.wishBtn.addEventListener('click', function () {
      var added = GH.wishlist.toggle(g.id);
      syncWish(g);
      GH.ui.toast(added ? '已加入愿望单' : '已从愿望单移除');
    });

    el.shots.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-shot]');
      if (btn) openLb(Number(btn.getAttribute('data-shot')));
    });

    el.browseBtn.href = 'category.html?genre=' + encodeURIComponent(g.genre);
  }

  /* ======================================================================
     启动
     ====================================================================== */
  function refs() {
    el.hero = doc.getElementById('gdHero');
    el.skeleton = doc.getElementById('gdSkeleton');
    el.missing = doc.getElementById('gdMissing');
    el.backdrop = doc.getElementById('gdBackdrop');
    el.cover = doc.getElementById('gdCover');
    el.coverFlag = doc.getElementById('gdCoverFlag');
    el.coverScore = doc.getElementById('gdCoverScore');
    el.kicker = doc.getElementById('gdKicker');
    el.title = doc.getElementById('gdTitle');
    el.titleEn = doc.getElementById('gdTitleEn');
    el.tags = doc.getElementById('gdTags');
    el.blurb = doc.getElementById('gdBlurb');
    el.dev = doc.getElementById('gdDev');
    el.pub = doc.getElementById('gdPub');
    el.year = doc.getElementById('gdYear');
    el.platforms = doc.getElementById('gdPlatforms');
    el.price = doc.getElementById('gdPrice');
    el.was = doc.getElementById('gdWas');
    el.off = doc.getElementById('gdOff');
    el.buyState = doc.getElementById('gdBuyState');
    el.buyBtn = doc.getElementById('gdBuyBtn');
    el.wishBtn = doc.getElementById('gdWishBtn');
    el.wishText = doc.getElementById('gdWishText');
    el.browseBtn = doc.getElementById('gdBrowseBtn');
    el.scoreText = doc.getElementById('gdScoreText');
    el.idText = doc.getElementById('gdId');
    el.crumbGenre = doc.getElementById('gdCrumbGenre');
    el.crumbNow = doc.getElementById('gdCrumbNow');
    el.buy = doc.getElementById('gdBuy');
    el.shots = doc.getElementById('gdShots');
    el.shotsCount = doc.getElementById('shotsCount');
    el.shotsSection = doc.getElementById('shots');
    el.aboutSection = doc.getElementById('about');
    el.desc = doc.getElementById('gdDesc');
    el.specs = doc.getElementById('gdSpecs');
    el.sideTags = doc.getElementById('gdSideTags');
    el.relatedSection = doc.getElementById('related');
    el.related = doc.getElementById('gdRelated');
    el.relatedSub = doc.getElementById('relatedSub');
    el.relatedMore = doc.getElementById('relatedMore');
  }

  function init() {
    if (!GH || !el.hero) return;

    var id = new window.URLSearchParams(window.location.search).get('id');
    var g = id ? GH.data.byId[id] : null;

    /* 没带参数时给一部代表作，避免空白页；参数无效则给出缺省态 */
    if (!id) {
      g = DATA.slice().sort(function (a, b) { return b.score - a.score; })[0];
    }

    if (!g) {
      if (el.skeleton) el.skeleton.hidden = true;
      el.missing.hidden = false;
      doc.title = '没有找到这部作品 · 游集 GAMEHUB';
      return;
    }

    game = g;

    renderHead(g);
    renderShots(g);
    renderBody(g);
    var hasRelated = renderRelated(g);
    bind(g);

    el.hero.hidden = false;
    el.shotsSection.hidden = false;
    el.aboutSection.hidden = false;
    el.relatedSection.hidden = !hasRelated;

    if (el.skeleton) el.skeleton.remove();
    el.skeleton = null;

    syncWish(g);
    syncOwned(g);
  }

  if (doc.readyState === 'loading') {
    doc.addEventListener('DOMContentLoaded', function () { refs(); init(); });
  } else {
    refs();
    init();
  }
})();
