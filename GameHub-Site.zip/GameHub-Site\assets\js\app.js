/* ==========================================================================
   游集 GAMEHUB — app.js
   公共层：主题 / 导航 / 抽屉 / 浮层（详情·登录·下载）/ 登录态 / 卡片 / 页脚
   约定：不使用 ES module（需支持 file:// 直接打开），一切挂在 window.GameHub。
   ========================================================================== */

(function () {
  'use strict';

  var THEME_KEY = 'gamehub.theme';
  var USER_KEY = 'gamehub.user';
  var WISH_KEY = 'gamehub.wishlist';

  var doc = document;
  var root = doc.documentElement;
  var DATA = window.GAME_DATA || [];
  var byId = Object.create(null);
  DATA.forEach(function (g) { byId[g.id] = g; });

  /* ---------- 小工具 ---------- */
  function esc(s) {
    return String(s === undefined || s === null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function initials(name) {
    return String(name || '游').trim().slice(0, 1).toUpperCase();
  }

  function finalPrice(g) {
    if (!g.price) return 0;
    if (!g.discount) return g.price;
    return Math.round(g.price * (1 - g.discount / 100));
  }

  function scoreTier(score) {
    if (score >= 90) return 'high';
    if (score >= 80) return 'mid';
    return 'low';
  }

  function priceHtml(g) {
    if (!g.price) return '<span class="game-card__price game-card__price--free">免费</span>';
    var out = '<span class="game-card__price">¥' + finalPrice(g) + '</span>';
    if (g.discount) out += '<span class="game-card__was">¥' + g.price + '</span>';
    return out;
  }

  function genreCount(genre) {
    var n = 0;
    for (var i = 0; i < DATA.length; i++) if (DATA[i].genre === genre) n++;
    return n;
  }

  /* ---------- 内联图标 ---------- */
  var ICON_X = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  var ICON_EYE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-6.4 10-6.4S22 12 22 12s-3.6 6.4-10 6.4S2 12 2 12z"/><circle cx="12" cy="12" r="2.6"/></svg>';
  var ICON_STEAM = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" width="16" height="16"><path d="M12 2a10 10 0 0 0-9.96 9.1l5.4 2.23a2.83 2.83 0 0 1 1.6-.49h.14l2.4-3.47v-.05a3.77 3.77 0 1 1 3.77 3.77h-.09l-3.42 2.44v.12a2.84 2.84 0 0 1-5.63.61L2.4 14.7A10 10 0 1 0 12 2zm-4.6 15.2-1.23-.51a2.13 2.13 0 0 0 3.93-.32 2.13 2.13 0 0 0-2.82-2.5l1.27.53a1.57 1.57 0 0 1-1.15 2.8zm8.7-6.02a2.51 2.51 0 1 0 0-5.03 2.51 2.51 0 0 0 0 5.03zm0-.66a1.86 1.86 0 1 1 0-3.71 1.86 1.86 0 0 1 0 3.71z"/></svg>';
  var ICON_WECHAT = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" width="16" height="16"><path d="M9.1 3C4.9 3 1.5 5.8 1.5 9.2c0 1.9 1.1 3.6 2.9 4.8l-.7 2.2 2.5-1.3c.9.3 1.9.4 2.9.4h.6a5.9 5.9 0 0 1-.3-1.9c0-3.2 3.2-5.8 7.1-5.8h.6C16.3 4.6 13 3 9.1 3zm-2.6 3.3a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm5.2 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2zM17.2 8c-3.4 0-6.1 2.2-6.1 4.9s2.7 4.9 6.1 4.9c.8 0 1.5-.1 2.2-.3l2 1-.6-1.7c1.4-.9 2.3-2.3 2.3-3.9C23.1 10.2 20.6 8 17.2 8zm-2 2.4a.9.9 0 1 1 0 1.8.9.9 0 0 1 0-1.8zm4.3 0a.9.9 0 1 1 0 1.8.9.9 0 0 1 0-1.8z"/></svg>';
  var ICON_WIN = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M3 4.6l8.2-1.1v8.1H3V4.6zm9.4-1.3L21 2v9.6h-8.6V3.3zM3 12.7h8.2v8.1L3 19.7v-7zm9.4 0H21V22l-8.6-1.2v-8.1z"/></svg>';
  var ICON_MAC = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M16.2 12.6c0-2 1.6-3 1.7-3.1-.9-1.4-2.4-1.6-2.9-1.6-1.2-.1-2.4.7-3 .7-.6 0-1.6-.7-2.6-.7-1.3 0-2.6.8-3.3 2-1.4 2.4-.4 6 1 8 .7 1 1.5 2 2.5 2 1 0 1.4-.6 2.6-.6s1.6.6 2.6.6 1.8-1 2.5-2c.8-1.1 1.1-2.2 1.1-2.3-.1 0-2.2-.9-2.2-3zM14.3 5.9c.6-.7 1-1.7.9-2.7-.9 0-2 .6-2.7 1.4-.6.6-1.1 1.7-.9 2.6 1 .1 2-.5 2.7-1.3z"/></svg>';
  var ICON_CHEVRON_R = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" width="16" height="16"><path d="M9 6l6 6-6 6"/></svg>';

  /* ======================================================================
     主题
     ====================================================================== */
  var media = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function storedTheme() {
    try { return localStorage.getItem(THEME_KEY); } catch (e) { return null; }
  }

  function systemTheme() {
    return media && media.matches ? 'dark' : 'light';
  }

  function applyTheme(theme) {
    root.setAttribute('data-theme', theme);
    var btns = doc.querySelectorAll('[data-theme-toggle]');
    for (var i = 0; i < btns.length; i++) {
      var label = theme === 'dark' ? '切换到浅色主题' : '切换到深色主题';
      btns[i].setAttribute('aria-label', label);
      btns[i].setAttribute('title', label);
      btns[i].setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
    }
    var meta = doc.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'dark' ? '#0b0f17' : '#ffffff');
  }

  function setTheme(theme) {
    applyTheme(theme);
    try { localStorage.setItem(THEME_KEY, theme); } catch (e) { /* 忽略 */ }
  }

  function toggleTheme() {
    setTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
  }

  applyTheme(storedTheme() || systemTheme());

  if (media) {
    var onSystemChange = function () {
      if (!storedTheme()) applyTheme(systemTheme());
    };
    if (media.addEventListener) media.addEventListener('change', onSystemChange);
    else if (media.addListener) media.addListener(onSystemChange);
  }

  /* ======================================================================
     导航滚动阴影 / 移动端抽屉
     ====================================================================== */
  function initNavScroll() {
    var nav = doc.querySelector('.site-nav');
    if (!nav) return;
    var ticking = false;
    function update() {
      nav.classList.toggle('is-scrolled', window.scrollY > 8);
      ticking = false;
    }
    window.addEventListener('scroll', function () {
      if (!ticking) {
        ticking = true;
        window.requestAnimationFrame(update);
      }
    }, { passive: true });
    update();
  }

  var drawerEl = null;
  var lastFocusBeforeDrawer = null;

  function buildDrawer() {
    if (drawerEl) return drawerEl;
    var links = doc.querySelectorAll('.site-nav__link');
    var items = [];
    for (var i = 0; i < links.length; i++) {
      var a = links[i];
      items.push(
        '<a class="drawer__link" href="' + a.getAttribute('href') + '"' +
        (a.getAttribute('aria-current') ? ' aria-current="page"' : '') + '>' +
        esc(a.textContent.trim()) + ICON_CHEVRON_R + '</a>'
      );
    }

    drawerEl = doc.createElement('div');
    drawerEl.className = 'drawer';
    drawerEl.id = 'navDrawer';
    drawerEl.hidden = true;
    drawerEl.innerHTML =
      '<div class="drawer__scrim" data-drawer-close></div>' +
      '<div class="drawer__panel" role="dialog" aria-modal="true" aria-label="导航菜单">' +
      '<div class="drawer__head">' +
      '<span class="brand__cn">游集 GAMEHUB</span>' +
      '<button class="icon-btn" type="button" data-drawer-close aria-label="关闭菜单">' + ICON_X + '</button>' +
      '</div>' +
      '<nav class="drawer__nav" aria-label="移动端导航">' + items.join('') + '</nav>' +
      '<div class="drawer__foot">' +
      '<div class="nav-auth" data-auth-slot></div>' +
      '<button class="btn btn--primary btn--block" type="button" data-download>下载客户端</button>' +
      '</div>' +
      '</div>';
    doc.body.appendChild(drawerEl);

    drawerEl.addEventListener('click', function (e) {
      if (e.target.closest('[data-drawer-close]')) closeDrawer();
      if (e.target.closest('a')) closeDrawer();
    });
    return drawerEl;
  }

  function openDrawer(trigger) {
    buildDrawer();
    renderAuthState();
    lastFocusBeforeDrawer = trigger || doc.activeElement;
    drawerEl.hidden = false;
    doc.body.style.overflow = 'hidden';
    window.requestAnimationFrame(function () { drawerEl.classList.add('is-open'); });
    var burger = doc.querySelector('[data-nav-burger]');
    if (burger) burger.setAttribute('aria-expanded', 'true');
    var first = drawerEl.querySelector('.drawer__link');
    if (first) window.setTimeout(function () { first.focus(); }, 80);
  }

  function closeDrawer() {
    if (!drawerEl) return;
    drawerEl.classList.remove('is-open');
    doc.body.style.overflow = '';
    var burger = doc.querySelector('[data-nav-burger]');
    if (burger) burger.setAttribute('aria-expanded', 'false');
    window.setTimeout(function () {
      if (drawerEl && !drawerEl.classList.contains('is-open')) drawerEl.hidden = true;
    }, 240);
    if (lastFocusBeforeDrawer && lastFocusBeforeDrawer.focus) lastFocusBeforeDrawer.focus();
  }

  function initDrawer() {
    var burger = doc.querySelector('[data-nav-burger]');
    if (!burger) return;
    burger.addEventListener('click', function () {
      if (drawerEl && drawerEl.classList.contains('is-open')) closeDrawer();
      else openDrawer(burger);
    });
  }

  /* ======================================================================
     浮层核心（焦点陷阱 / ESC / 遮罩 / 焦点归还）
     ====================================================================== */
  var openStack = [];

  function trapFocus(e, panel) {
    if (e.key !== 'Tab') return;
    var nodes = panel.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
    );
    if (!nodes.length) return;
    var first = nodes[0];
    var last = nodes[nodes.length - 1];
    if (e.shiftKey && doc.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && doc.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  function openModal(el, opts) {
    if (!el) return;
    opts = opts || {};
    el.hidden = false;
    var last = doc.activeElement;
    openStack.push({ el: el, last: last });
    doc.body.style.overflow = 'hidden';
    window.requestAnimationFrame(function () { el.classList.add('is-open'); });

    var target = el.querySelector('[data-autofocus]') || el.querySelector('.modal__close');
    if (target) window.setTimeout(function () { target.focus(); }, 70);

    el.__onKey = function (e) {
      if (e.key === 'Escape' && opts.dismissible !== false) {
        e.stopPropagation();
        closeModal(el);
      } else {
        var panel = el.querySelector('.modal__panel');
        if (panel) trapFocus(e, panel);
      }
    };
    doc.addEventListener('keydown', el.__onKey);

    if (!el.__wired) {
      el.__wired = true;
      el.addEventListener('click', function (e) {
        if (e.target.closest('[data-modal-close]')) closeModal(el);
      });
    }
  }

  function closeModal(el) {
    if (!el) return;
    el.classList.remove('is-open');
    if (el.__onKey) {
      doc.removeEventListener('keydown', el.__onKey);
      el.__onKey = null;
    }
    var entry = null;
    for (var i = openStack.length - 1; i >= 0; i--) {
      if (openStack[i].el === el) {
        entry = openStack.splice(i, 1)[0];
        break;
      }
    }
    if (!openStack.length) doc.body.style.overflow = '';
    window.setTimeout(function () {
      if (!el.classList.contains('is-open')) el.hidden = true;
      if (entry && entry.last && entry.last.focus) entry.last.focus();
    }, 200);
  }

  /* ======================================================================
     Toast（右下角，可叠加，2.6s 自动消失）
     ====================================================================== */
  var toastHost = null;

  function toast(msg) {
    if (!toastHost) {
      toastHost = doc.createElement('div');
      toastHost.className = 'toast-host';
      toastHost.setAttribute('aria-live', 'polite');
      doc.body.appendChild(toastHost);
    }
    var el = doc.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    toastHost.appendChild(el);
    window.setTimeout(function () { el.remove(); }, 2600);
  }

  /* ======================================================================
     登录态 / 愿望单
     ====================================================================== */
  function getUser() {
    try {
      var raw = localStorage.getItem(USER_KEY) || sessionStorage.getItem(USER_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function setUser(user, remember) {
    try {
      localStorage.removeItem(USER_KEY);
      sessionStorage.removeItem(USER_KEY);
      if (user) {
        var raw = JSON.stringify(user);
        if (remember === false) sessionStorage.setItem(USER_KEY, raw);
        else localStorage.setItem(USER_KEY, raw);
      }
    } catch (e) { /* 忽略 */ }
    renderAuthState();
  }

  function getWishlist() {
    try {
      var raw = localStorage.getItem(WISH_KEY);
      var arr = raw ? JSON.parse(raw) : [];
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      return [];
    }
  }

  function isWished(id) {
    return getWishlist().indexOf(id) >= 0;
  }

  function toggleWish(id) {
    var list = getWishlist();
    var i = list.indexOf(id);
    if (i >= 0) list.splice(i, 1);
    else list.push(id);
    try { localStorage.setItem(WISH_KEY, JSON.stringify(list)); } catch (e) { /* 忽略 */ }
    renderAuthState();
    return i < 0;
  }

  function userPillHtml(user) {
    return (
      '<button class="user-pill" type="button" data-user-toggle aria-expanded="false" aria-haspopup="menu">' +
      '<span class="user-pill__avatar" aria-hidden="true">' + esc(initials(user.name)) + '</span>' +
      '<span class="user-pill__name">' + esc(user.name) + '</span>' +
      '<svg class="user-pill__chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>' +
      '</button>' +
      '<div class="user-menu" role="menu" hidden>' +
      '<div class="user-menu__head">' +
      '<div class="user-menu__name">' + esc(user.name) + '</div>' +
      '<div class="user-menu__sub">本地演示账号</div>' +
      '</div>' +
      '<a class="user-menu__item" role="menuitem" href="category.html?wishlist=1">我的愿望单' +
      '<span class="badge">' + getWishlist().length + '</span></a>' +
      '<a class="user-menu__item" role="menuitem" href="login.html">账号与安全</a>' +
      '<button class="user-menu__item user-menu__item--danger" type="button" role="menuitem" data-logout>退出登录</button>' +
      '</div>'
    );
  }

  function renderAuthState() {
    var user = getUser();
    var slots = doc.querySelectorAll('[data-auth-slot]');
    for (var i = 0; i < slots.length; i++) {
      slots[i].innerHTML = user
        ? userPillHtml(user)
        : '<a class="btn btn--ghost btn--sm" href="login.html">登录</a>';
    }
  }

  function closeUserMenus() {
    var menus = doc.querySelectorAll('.user-menu');
    for (var i = 0; i < menus.length; i++) menus[i].hidden = true;
    var toggles = doc.querySelectorAll('[data-user-toggle]');
    for (var j = 0; j < toggles.length; j++) toggles[j].setAttribute('aria-expanded', 'false');
  }

  /* ======================================================================
     登录 / 注册浮层
     ====================================================================== */
  var authModal = null;
  var authMode = 'login';

  function buildAuthModal() {
    if (authModal) return authModal;
    authModal = doc.createElement('div');
    authModal.className = 'modal';
    authModal.hidden = true;
    authModal.setAttribute('role', 'dialog');
    authModal.setAttribute('aria-modal', 'true');
    authModal.setAttribute('aria-labelledby', 'authTitle');
    authModal.innerHTML =
      '<div class="modal__scrim" data-modal-close></div>' +
      '<div class="modal__panel">' +
      '<div class="modal__head">' +
      '<div><h2 class="modal__title" id="authTitle">登录游集</h2>' +
      '<p class="modal__desc" id="authDesc">登录后同步愿望单与购买记录。</p></div>' +
      '<button class="icon-btn modal__close" type="button" data-modal-close aria-label="关闭">' + ICON_X + '</button>' +
      '</div>' +
      '<div class="modal__body">' +
      '<div class="tabs" role="tablist" aria-label="登录或注册">' +
      '<button class="tab" type="button" role="tab" aria-selected="true" data-auth-tab="login">登录</button>' +
      '<button class="tab" type="button" role="tab" aria-selected="false" data-auth-tab="register">注册</button>' +
      '</div>' +
      '<form id="authForm" novalidate>' +
      '<div class="field">' +
      '<label class="field__label" for="authEmail">邮箱</label>' +
      '<input class="input" id="authEmail" name="email" type="email" autocomplete="email" ' +
      'placeholder="you@example.com" data-autofocus>' +
      '</div>' +
      '<div class="field">' +
      '<label class="field__label" for="authPwd">密码</label>' +
      '<div class="input-wrap">' +
      '<input class="input" id="authPwd" name="password" type="password" autocomplete="current-password" placeholder="至少 6 位">' +
      '<button class="input-eye" type="button" data-eye aria-label="显示密码" aria-pressed="false">' + ICON_EYE + '</button>' +
      '</div>' +
      '</div>' +
      '<div class="field" data-register-only hidden>' +
      '<label class="field__label" for="authPwd2">确认密码</label>' +
      '<input class="input" id="authPwd2" type="password" autocomplete="new-password" placeholder="再输入一次">' +
      '</div>' +
      '<label class="check" data-register-only hidden>' +
      '<input type="checkbox" id="authAgree">' +
      '<span>我已阅读并同意<a href="about.html#legal">《服务条款》</a>与<a href="about.html#legal">《隐私政策》</a></span>' +
      '</label>' +
      '<label class="check" data-login-only>' +
      '<input type="checkbox" id="authRemember" checked><span>记住我</span>' +
      '</label>' +
      '<p class="field__error" id="authError" role="alert" hidden></p>' +
      '<button class="btn btn--primary btn--block" type="submit" id="authSubmit">登录</button>' +
      '<div class="auth-divider">或使用以下方式</div>' +
      '<div class="auth-alt">' +
      '<button class="btn btn--ghost" type="button" data-third="Steam">' + ICON_STEAM + 'Steam</button>' +
      '<button class="btn btn--ghost" type="button" data-third="微信">' + ICON_WECHAT + '微信</button>' +
      '</div>' +
      '</form>' +
      '</div>' +
      '</div>';
    doc.body.appendChild(authModal);

    authModal.addEventListener('click', function (e) {
      var tab = e.target.closest('[data-auth-tab]');
      if (tab) {
        setAuthMode(tab.getAttribute('data-auth-tab'));
        return;
      }
      var eye = e.target.closest('[data-eye]');
      if (eye) {
        var input = authModal.querySelector('#authPwd');
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        eye.setAttribute('aria-pressed', show ? 'true' : 'false');
        eye.setAttribute('aria-label', show ? '隐藏密码' : '显示密码');
        input.focus();
        return;
      }
      var third = e.target.closest('[data-third]');
      if (third) toast(third.getAttribute('data-third') + ' 登录暂未开放');
    });

    authModal.querySelector('#authForm').addEventListener('submit', submitAuth);
    return authModal;
  }

  function setAuthMode(mode) {
    authMode = mode === 'register' ? 'register' : 'login';
    var isReg = authMode === 'register';
    var tabs = authModal.querySelectorAll('[data-auth-tab]');
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].setAttribute('aria-selected', tabs[i].getAttribute('data-auth-tab') === authMode ? 'true' : 'false');
    }
    authModal.querySelector('#authTitle').textContent = isReg ? '创建账号' : '登录游集';
    authModal.querySelector('#authDesc').textContent = isReg
      ? '注册后即可同步愿望单，演示站点无需真实信息。'
      : '登录后同步愿望单与购买记录。';
    authModal.querySelector('#authSubmit').textContent = isReg ? '注册并登录' : '登录';
    authModal.querySelector('#authPwd').setAttribute('autocomplete', isReg ? 'new-password' : 'current-password');

    var regs = authModal.querySelectorAll('[data-register-only]');
    for (var r = 0; r < regs.length; r++) regs[r].hidden = !isReg;
    var logs = authModal.querySelectorAll('[data-login-only]');
    for (var l = 0; l < logs.length; l++) logs[l].hidden = isReg;

    authModal.querySelector('#authError').hidden = true;
    authModal.querySelector('#authPwd2').value = '';
    var fields = authModal.querySelectorAll('.field');
    for (var f = 0; f < fields.length; f++) fields[f].removeAttribute('data-invalid');
  }

  function submitAuth(e) {
    e.preventDefault();
    var email = authModal.querySelector('#authEmail');
    var pwd = authModal.querySelector('#authPwd');
    var pwd2 = authModal.querySelector('#authPwd2');
    var agree = authModal.querySelector('#authAgree');
    var remember = authModal.querySelector('#authRemember');
    var err = authModal.querySelector('#authError');
    var isReg = authMode === 'register';
    var msg = '';

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) msg = '请输入有效的邮箱地址';
    else if (pwd.value.length < 6) msg = '密码至少 6 位';
    else if (isReg && pwd.value !== pwd2.value) msg = '两次输入的密码不一致';
    else if (isReg && !agree.checked) msg = '请先同意服务条款与隐私政策';

    email.closest('.field').setAttribute('data-invalid', msg.indexOf('邮箱') >= 0 ? 'true' : 'false');
    pwd.closest('.field').setAttribute('data-invalid', msg.indexOf('密码') >= 0 ? 'true' : 'false');
    pwd2.closest('.field').setAttribute('data-invalid', msg.indexOf('两次') >= 0 ? 'true' : 'false');

    if (msg) {
      err.textContent = msg;
      err.hidden = false;
      return;
    }

    err.hidden = true;
    var name = email.value.trim().split('@')[0].replace(/[._-]+/g, '').slice(0, 12) || '玩家';
    setUser({ name: name }, isReg ? true : remember.checked);
    closeModal(authModal);
    toast(isReg ? '注册成功，欢迎加入游集，' + name : '已登录，欢迎回来，' + name);
    authModal.querySelector('#authForm').reset();
    setAuthMode('login');
  }

  function openAuth(mode) {
    var m = buildAuthModal();
    setAuthMode(mode || 'login');
    openModal(m);
  }

  /* ======================================================================
     下载浮层
     ====================================================================== */
  var dlModal = null;

  function buildDownloadModal() {
    if (dlModal) return dlModal;
    dlModal = doc.createElement('div');
    dlModal.className = 'modal';
    dlModal.hidden = true;
    dlModal.setAttribute('role', 'dialog');
    dlModal.setAttribute('aria-modal', 'true');
    dlModal.setAttribute('aria-labelledby', 'dlTitle');
    dlModal.innerHTML =
      '<div class="modal__scrim" data-modal-close></div>' +
      '<div class="modal__panel">' +
      '<div class="modal__head">' +
      '<div><h2 class="modal__title" id="dlTitle">下载游集客户端</h2>' +
      '<p class="modal__desc">v2.4.1 · 更新于 2026-11-08</p></div>' +
      '<button class="icon-btn modal__close" type="button" data-modal-close aria-label="关闭">' + ICON_X + '</button>' +
      '</div>' +
      '<div class="modal__body">' +
      '<div class="dl-grid">' +
      '<button class="dl-card" type="button" data-dl="windows">' +
      '<span class="dl-card__icon">' + ICON_WIN + '</span>' +
      '<span><span class="dl-card__name">Windows</span>' +
      '<span class="dl-card__meta">Windows 10 及以上 · 68.4 MB</span></span>' +
      '<span class="dl-card__state">下载</span>' +
      '<span class="dl-card__bar"><i></i></span>' +
      '</button>' +
      '<button class="dl-card" type="button" data-dl="macos">' +
      '<span class="dl-card__icon">' + ICON_MAC + '</span>' +
      '<span><span class="dl-card__name">macOS</span>' +
      '<span class="dl-card__meta">macOS 12 及以上 · 68.4 MB</span></span>' +
      '<span class="dl-card__state">下载</span>' +
      '<span class="dl-card__bar"><i></i></span>' +
      '</button>' +
      '</div>' +
      '<p class="dl-note">客户端支持云存档同步与离线游玩。演示站点不会真正下载文件。</p>' +
      '</div>' +
      '</div>';
    doc.body.appendChild(dlModal);

    dlModal.addEventListener('click', function (e) {
      var card = e.target.closest('[data-dl]');
      if (!card || card.classList.contains('is-loading') || card.classList.contains('is-done')) return;
      var bar = card.querySelector('.dl-card__bar i');
      var state = card.querySelector('.dl-card__state');
      card.classList.add('is-loading');
      state.textContent = '0%';
      window.requestAnimationFrame(function () { bar.style.width = '100%'; });
      var start = Date.now();
      var timer = window.setInterval(function () {
        var p = Math.min(100, Math.round((Date.now() - start) / 24));
        state.textContent = p + '%';
        if (p >= 100) {
          window.clearInterval(timer);
          card.classList.remove('is-loading');
          card.classList.add('is-done');
          state.textContent = '已下载';
          toast('客户端已下载（演示）');
        }
      }, 100);
    });

    return dlModal;
  }

  function openDownload() {
    openModal(buildDownloadModal());
  }

  /* ======================================================================
     详情浮层
     ====================================================================== */
  var detailModal = null;
  var currentGame = null;

  function buildDetailModal() {
    if (detailModal) return detailModal;
    detailModal = doc.createElement('div');
    detailModal.className = 'modal';
    detailModal.hidden = true;
    detailModal.setAttribute('role', 'dialog');
    detailModal.setAttribute('aria-modal', 'true');
    detailModal.setAttribute('aria-labelledby', 'detailHeading');
    detailModal.innerHTML =
      '<div class="modal__scrim" data-modal-close></div>' +
      '<div class="modal__panel modal__panel--wide">' +
      '<div class="modal__head">' +
      '<p class="eyebrow">作品详情</p>' +
      '<button class="icon-btn modal__close" type="button" data-modal-close aria-label="关闭">' + ICON_X + '</button>' +
      '</div>' +
      '<div class="modal__body" id="detailBody"></div>' +
      '<div class="detail__foot" id="detailFoot"></div>' +
      '</div>';
    doc.body.appendChild(detailModal);

    detailModal.addEventListener('click', function (e) {
      if (e.target.closest('[data-buy]')) {
        toast('已加入购物车');
        return;
      }
      var wish = e.target.closest('[data-wishlist]');
      if (wish && currentGame) {
        var added = toggleWish(currentGame.id);
        wish.textContent = added ? '已在愿望单' : '加入愿望单';
        wish.setAttribute('aria-pressed', added ? 'true' : 'false');
        toast(added ? '已加入愿望单' : '已从愿望单移除');
      }
    });

    return detailModal;
  }

  function detailHtml(g) {
    var wished = isWished(g.id);
    var priceBlock;
    if (!g.price) {
      priceBlock = '<div><span class="detail__price" style="color:var(--good)">免费</span></div>';
    } else {
      priceBlock = '<div><span class="detail__price">¥' + finalPrice(g) + '</span>';
      if (g.discount) {
        priceBlock += '<span class="detail__was">¥' + g.price + '</span>' +
          ' <span class="badge badge--promo">-' + g.discount + '%</span>';
      }
      priceBlock += '</div>';
    }

    var tagChips = '<span class="chip chip--sm chip--static">' + esc(g.genre) + '</span>';
    g.tags.forEach(function (t) {
      tagChips += '<span class="chip chip--sm chip--static">' + esc(t) + '</span>';
    });

    var platformBadges = g.platforms.map(function (p) {
      return '<span class="badge badge--outline">' + esc(p) + '</span>';
    }).join('');

    return (
      '<div class="detail">' +
      '<div class="detail__cover" data-cover-id="' + esc(g.id) + '"></div>' +
      '<div class="detail__body">' +
      '<div>' +
      '<h2 class="detail__title" id="detailHeading">' + esc(g.cn) + '</h2>' +
      '<p class="detail__en">' + esc(g.en) + ' · ' + g.year + '</p>' +
      '</div>' +
      '<div class="detail__tags">' + tagChips + '</div>' +
      '<div class="detail__platforms">' + platformBadges +
      '<span class="badge badge--score" data-tier="' + scoreTier(g.score) + '">' + g.score + ' 分</span>' +
      '</div>' +
      '<p class="detail__blurb">' + esc(g.blurb) + '</p>' +
      '<dl class="detail__specs">' +
      '<div><dt>开发商</dt><dd>' + esc(g.dev) + '</dd></div>' +
      '<div><dt>发行商</dt><dd>' + esc(g.pub) + '</dd></div>' +
      '<div><dt>发行年份</dt><dd>' + g.year + '</dd></div>' +
      '<div><dt>平台</dt><dd>' + g.platforms.join(' / ') + '</dd></div>' +
      '</dl>' +
      '<div class="detail__buy">' + priceBlock +
      '<div class="row">' +
      '<button class="btn btn--ghost btn--sm" type="button" data-wishlist aria-pressed="' + (wished ? 'true' : 'false') + '">' +
      (wished ? '已在愿望单' : '加入愿望单') + '</button>' +
      '<button class="btn btn--primary btn--sm" type="button" data-buy>立即购买</button>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '</div>'
    );
  }

  function openDetail(game) {
    if (!game) return;
    currentGame = game;
    var m = buildDetailModal();
    m.querySelector('#detailBody').innerHTML = detailHtml(game);
    m.querySelector('#detailFoot').innerHTML =
      '<a href="category.html?genre=' + encodeURIComponent(game.genre) + '">浏览全部「' + esc(game.genre) + '」→</a>' +
      '<span class="dim">该类型共 ' + genreCount(game.genre) + ' 部</span>';
    openModal(m);
    mountCovers(m);
  }

  /* ======================================================================
     卡片 / 封面批量挂载
     ====================================================================== */
  function cardHtml(g) {
    var flag = g.discount ? '<span class="game-card__flag">-' + g.discount + '%</span>' : '';
    return (
      '<a class="game-card" href="game.html?id=' + encodeURIComponent(g.id) + '" data-game-id="' + esc(g.id) + '">' +
      '<span class="game-card__cover" data-cover-id="' + esc(g.id) + '" data-cover-pill="off">' +
      flag +
      '<span class="game-card__score" data-tier="' + scoreTier(g.score) + '">' + g.score + '</span>' +
      '<span class="game-card__hover" data-quick-view><span class="btn btn--sm">快速查看</span></span>' +
      '</span>' +
      '<span class="game-card__title" title="' + esc(g.cn) + '">' + esc(g.cn) + '</span>' +
      '<span class="game-card__meta">' + esc(g.genre) + ' · ' + g.year + '</span>' +
      '<span class="game-card__prices">' + priceHtml(g) + '</span>' +
      '</a>'
    );
  }

  function listCardHtml(g) {
    var flag = g.discount ? '<span class="game-card__flag">-' + g.discount + '%</span>' : '';
    return (
      '<a class="game-card" href="game.html?id=' + encodeURIComponent(g.id) + '" data-game-id="' + esc(g.id) + '">' +
      '<span class="game-card__cover" data-cover-id="' + esc(g.id) + '" data-cover-pill="off">' +
      flag +
      '<span class="game-card__score" data-tier="' + scoreTier(g.score) + '">' + g.score + '</span>' +
      '</span>' +
      '<span class="game-card__info">' +
      '<span class="game-card__title" title="' + esc(g.cn) + '">' + esc(g.cn) + '</span>' +
      '<span class="game-card__meta">' + esc(g.genre) + ' · ' + g.year + ' · ' + esc(g.dev) + '</span>' +
      '<span class="game-card__blurb">' + esc(g.blurb) + '</span>' +
      '</span>' +
      '<span class="game-card__prices">' + priceHtml(g) + '</span>' +
      '</a>'
    );
  }

  /* 统一封面挂载入口：每帧最多 12 张 */
  function mountCovers(scope, opts) {
    var engine = window.CoverEngine;
    if (!engine) return;
    scope = scope || doc;
    var all = scope.querySelectorAll('[data-cover-id]');
    var queue = [];
    for (var i = 0; i < all.length; i++) {
      if (!all[i].hasAttribute('data-covered')) queue.push(all[i]);
    }
    var idx = 0;
    function step() {
      var budget = 12;
      while (idx < queue.length && budget-- > 0) {
        var el = queue[idx++];
        var g = byId[el.getAttribute('data-cover-id')];
        if (g) {
          /* 卡片封面不画 SVG 内的类型胶囊（左上角留给折扣角标） */
          var o = opts;
          if (el.getAttribute('data-cover-pill') === 'off') {
            o = { pill: false };
            if (opts) for (var k in opts) if (k !== 'pill') o[k] = opts[k];
          }
          engine.renderInto(el, g, o);
          el.setAttribute('data-covered', '1');
        }
      }
      if (idx < queue.length) window.requestAnimationFrame(step);
    }
    if (queue.length) window.requestAnimationFrame(step);
  }

  function renderCards(host, games, opts) {
    if (!host) return;
    opts = opts || {};
    host.innerHTML = games.map(opts.view === 'list' ? listCardHtml : cardHtml).join('');
    mountCovers(host, opts);
  }

  /* ======================================================================
     页脚
     ====================================================================== */
  var FOOTER_HTML =
    '<div class="container">' +
    '<div class="site-footer__grid">' +
    '<div class="site-footer__brand">' +
    '<a class="brand" href="index.html" aria-label="游集 GAMEHUB 首页">' +
    '<svg class="brand__mark" viewBox="0 0 32 32" aria-hidden="true">' +
    '<rect width="32" height="32" rx="9" fill="#1F6FEB"/>' +
    '<path d="M11 9.5l10 6.5-10 6.5z" fill="#fff"/>' +
    '<circle cx="24" cy="24" r="2.4" fill="#7C5CFF"/>' +
    '</svg>' +
    '<span class="brand__cn">游集</span><span class="brand__en">GAMEHUB</span>' +
    '</a>' +
    '<p>收录 568 部单机作品的作品库。清爽地挑游戏，安静地玩完它。</p>' +
    '<p style="margin-top:10px;font-size:12px;line-height:1.7;color:var(--text-3)">' +
    '封面均为程序化生成的艺术再创作，游戏名称与商标归各发行商所有。</p>' +
    '</div>' +
    '<div class="site-footer__col"><h4>逛一逛</h4><ul>' +
    '<li><a href="index.html">首页</a></li>' +
    '<li><a href="category.html">全部分类</a></li>' +
    '<li><a href="category.html?sale=1">正在促销</a></li>' +
    '<li><a href="category.html?sort=score">高分作品</a></li>' +
    '</ul></div>' +
    '<div class="site-footer__col"><h4>帮助</h4><ul>' +
    '<li><a href="support.html">客服中心</a></li>' +
    '<li><a href="support.html#faq">常见问题</a></li>' +
    '<li><a href="support.html#download">下载客户端</a></li>' +
    '<li><a href="support.html#refund">退款说明</a></li>' +
    '</ul></div>' +
    '<div class="site-footer__col"><h4>关于</h4><ul>' +
    '<li><a href="about.html">关于游集</a></li>' +
    '<li><a href="about.html#how">收录标准</a></li>' +
    '<li><a href="about.html#contact">联系我们</a></li>' +
    '<li><a href="about.html#legal">条款与隐私</a></li>' +
    '</ul></div>' +
    '</div>' +
    '<div class="site-footer__bottom">' +
    '<span>© 2026 游集 GAMEHUB · 静态演示站点，作品信息与价格仅作展示</span>' +
    '<span class="site-footer__legal">' +
    '<a href="about.html#legal">服务条款</a><a href="about.html#legal">隐私政策</a><a href="about.html#contact">联系我们</a>' +
    '</span>' +
    '</div>' +
    '</div>';

  function initFooter() {
    var host = doc.getElementById('site-footer');
    if (!host) return;
    host.className = 'site-footer';
    host.innerHTML = FOOTER_HTML;
  }

  /* ======================================================================
     全局事件委托 & 初始化
     ====================================================================== */
  function init() {
    initFooter();
    initNavScroll();
    initDrawer();
    renderAuthState();

    doc.addEventListener('click', function (e) {
      if (e.target.closest('[data-theme-toggle]')) {
        toggleTheme();
        return;
      }

      if (e.target.closest('[data-login]')) {
        e.preventDefault();
        closeUserMenus();
        openAuth('login');
        return;
      }

      if (e.target.closest('[data-download]')) {
        e.preventDefault();
        closeUserMenus();
        openDownload();
        return;
      }

      var userToggle = e.target.closest('[data-user-toggle]');
      if (userToggle) {
        var menu = userToggle.parentNode.querySelector('.user-menu');
        var willOpen = menu && menu.hidden;
        closeUserMenus();
        if (menu && willOpen) {
          menu.hidden = false;
          userToggle.setAttribute('aria-expanded', 'true');
          var firstItem = menu.querySelector('.user-menu__item');
          if (firstItem) firstItem.focus();
        }
        return;
      }

      if (e.target.closest('[data-logout]')) {
        e.preventDefault();
        setUser(null);
        closeUserMenus();
        toast('已退出登录');
        return;
      }

      var card = e.target.closest('[data-game-id]');
      if (card) {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button === 1) return;
        /* 只有"快速查看"这一层拦截成浮层，卡片本身照常跳转详情页 */
        if (e.target.closest('[data-quick-view]')) {
          e.preventDefault();
          openDetail(byId[card.getAttribute('data-game-id')]);
        }
        return;
      }

      if (!e.target.closest('.user-menu')) closeUserMenus();
    });

    doc.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      closeUserMenus();
      if (drawerEl && drawerEl.classList.contains('is-open')) closeDrawer();
    });
  }

  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', init);
  else init();

  /* ---------- 对外 API ---------- */
  window.GameHub = {
    theme: { get: function () { return root.getAttribute('data-theme'); }, set: setTheme, toggle: toggleTheme },
    auth: { get: getUser, set: setUser, open: openAuth },
    wishlist: {
      get: getWishlist,
      has: isWished,
      toggle: toggleWish,
      count: function () { return getWishlist().length; }
    },
    ui: {
      toast: toast,
      openModal: openModal,
      closeModal: closeModal,
      detail: openDetail,
      login: openAuth,
      download: openDownload
    },
    render: {
      card: cardHtml,
      listCard: listCardHtml,
      cards: renderCards,
      price: priceHtml,
      finalPrice: finalPrice
    },
    mountCovers: mountCovers,
    data: { all: DATA, byId: byId, byGenre: genreCount },
    escape: esc
  };
})();
