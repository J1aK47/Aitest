/* ==========================================================================
   游集 GAMEHUB — category.js
   分类页：分面筛选 / 排序 / 视图切换 / 加载更多 / URL 状态同步 / 详情浮层
   依赖：games.js（数据）、cover.js（封面）、app.js（公共组件）
   ========================================================================== */

(function () {
  'use strict';

  var doc = document;
  var GH = window.GameHub;
  var DATA = (window.GAME_DATA || []).slice();
  var PAGE_SIZE = 36;

  var el = {};

  /* ======================================================================
     分面定义
     ====================================================================== */
  var PLATFORMS = ['PC', 'PS5', 'XSX', 'NS', 'PS4'];

  var YEAR_OPTIONS = [
    { value: '2021-2026', label: '2021—2026', test: function (y) { return y >= 2021 && y <= 2026; } },
    { value: '2016-2020', label: '2016—2020', test: function (y) { return y >= 2016 && y <= 2020; } },
    { value: '2011-2015', label: '2011—2015', test: function (y) { return y >= 2011 && y <= 2015; } },
    { value: '1998-2010', label: '1998—2010', test: function (y) { return y >= 1998 && y <= 2010; } }
  ];

  var SCORE_OPTIONS = [
    { value: '90-100', label: '90 分以上', test: function (s) { return s >= 90; } },
    { value: '80-89', label: '80—89 分', test: function (s) { return s >= 80 && s < 90; } },
    { value: '60-79', label: '80 分以下', test: function (s) { return s < 80; } }
  ];

  var PRICE_OPTIONS = [
    { value: 'free', label: '免费', test: function (p) { return p === 0; } },
    { value: '1-49', label: '¥1—49', test: function (p) { return p > 0 && p <= 49; } },
    { value: '50-99', label: '¥50—99', test: function (p) { return p > 49 && p <= 99; } },
    { value: '100-199', label: '¥100—199', test: function (p) { return p >= 100 && p <= 199; } },
    { value: '200-', label: '¥200 以上', test: function (p) { return p >= 200; } }
  ];

  var facetOptions = {
    genre: [],
    platform: [],
    year: YEAR_OPTIONS,
    score: SCORE_OPTIONS,
    price: PRICE_OPTIONS
  };

  var SORTS = ['hot', 'score', 'new', 'discount', 'price-asc', 'price-desc'];

  /* ======================================================================
     状态
     ====================================================================== */
  var state = {
    genre: [], platform: [], year: [], score: [], price: [],
    sale: false,
    sort: 'hot',
    q: '',
    view: 'grid',
    wishlist: false
  };

  var current = [];
  var shown = 0;

  /* ======================================================================
     工具
     ====================================================================== */
  function esc(s) { return GH.escape(s); }

  function priceOf(g) {
    if (!g.price) return 0;
    return GH.render.finalPrice(g);
  }

  function hash(str) {
    var h = 5381;
    for (var i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return h >>> 0;
  }

  function findOption(facet, value) {
    var list = facetOptions[facet];
    for (var i = 0; i < list.length; i++) if (list[i].value === value) return list[i];
    return null;
  }

  function optionHit(facet, value, g) {
    if (facet === 'genre') return g.genre === value;
    if (facet === 'platform') return g.platforms.indexOf(value) >= 0;
    var opt = findOption(facet, value);
    if (!opt) return false;
    if (facet === 'year') return opt.test(g.year);
    if (facet === 'score') return opt.test(g.score);
    if (facet === 'price') return opt.test(priceOf(g));
    return false;
  }

  function matchQuery(g, q) {
    var s = q.toLowerCase();
    if (g.cn.toLowerCase().indexOf(s) >= 0) return true;
    if (g.en.toLowerCase().indexOf(s) >= 0) return true;
    if (g.dev.toLowerCase().indexOf(s) >= 0) return true;
    if (g.pub.toLowerCase().indexOf(s) >= 0) return true;
    if (g.genre.indexOf(q) >= 0) return true;
    for (var i = 0; i < g.tags.length; i++) {
      if (g.tags[i].toLowerCase().indexOf(s) >= 0) return true;
    }
    return false;
  }

  function facetHit(facet, g) {
    var vals = state[facet];
    if (!vals.length) return true;
    for (var i = 0; i < vals.length; i++) if (optionHit(facet, vals[i], g)) return true;
    return false;
  }

  function matches(g) {
    if (state.wishlist && !GH.wishlist.has(g.id)) return false;
    if (!facetHit('genre', g) || !facetHit('platform', g)) return false;
    if (!facetHit('year', g) || !facetHit('score', g) || !facetHit('price', g)) return false;
    if (state.sale && !g.discount) return false;
    if (state.q && !matchQuery(g, state.q)) return false;
    return true;
  }

  function hasFilters() {
    if (state.q || state.sale || state.wishlist) return true;
    for (var i = 0; i < 5; i++) {
      if (state[['genre', 'platform', 'year', 'score', 'price'][i]].length) return true;
    }
    return false;
  }

  /* 综合推荐：评分占主要权重，年份、折扣与稳定哈希做微调，保证同一个库每次顺序一致 */
  function hotScore(g) {
    return g.score * 0.72 +
      (g.year >= 2020 ? 8 : g.year >= 2010 ? 4 : 0) +
      Math.min(g.discount || 0, 70) * 0.18 +
      (hash(g.id) % 13) * 0.5;
  }

  function sortList(list) {
    var arr = list.slice();
    arr.sort(function (a, b) {
      switch (state.sort) {
        case 'score': return b.score - a.score || b.year - a.year;
        case 'new': return b.year - a.year || b.score - a.score;
        case 'discount': return (b.discount || 0) - (a.discount || 0) || b.score - a.score;
        case 'price-asc': return priceOf(a) - priceOf(b) || b.score - a.score;
        case 'price-desc': return priceOf(b) - priceOf(a) || b.score - a.score;
        default: return hotScore(b) - hotScore(a);
      }
    });
    return arr;
  }

  /* ======================================================================
     分面选项与计数
     ====================================================================== */
  function countStatic(facet, opt) {
    var n = 0;
    for (var i = 0; i < DATA.length; i++) {
      var g = DATA[i];
      if (facet === 'year' && opt.test(g.year)) n++;
      else if (facet === 'score' && opt.test(g.score)) n++;
      else if (facet === 'price' && opt.test(priceOf(g))) n++;
    }
    return n;
  }

  function buildFacetOptions() {
    var genreCount = {};
    var platformCount = {};
    DATA.forEach(function (g) {
      genreCount[g.genre] = (genreCount[g.genre] || 0) + 1;
      g.platforms.forEach(function (p) { platformCount[p] = (platformCount[p] || 0) + 1; });
    });

    facetOptions.genre = Object.keys(genreCount)
      .sort(function (a, b) { return genreCount[b] - genreCount[a] || a.localeCompare(b, 'zh'); })
      .map(function (name) { return { value: name, label: name, count: genreCount[name] }; });

    facetOptions.platform = PLATFORMS.map(function (p) {
      return { value: p, label: p, count: platformCount[p] || 0 };
    });

    facetOptions.year.forEach(function (o) { o.count = countStatic('year', o); });
    facetOptions.score.forEach(function (o) { o.count = countStatic('score', o); });
    facetOptions.price.forEach(function (o) { o.count = countStatic('price', o); });
  }

  /* ======================================================================
     URL 读取 / 写回
     ====================================================================== */
  function listParam(raw) {
    if (!raw) return [];
    return raw.split(',').map(function (v) { return v.trim(); }).filter(function (v, i, arr) {
      return v && arr.indexOf(v) === i;
    });
  }

  function keepKnown(facet, values) {
    var opts = facetOptions[facet];
    return values.filter(function (v) {
      for (var i = 0; i < opts.length; i++) if (opts[i].value === v) return true;
      return false;
    });
  }

  /* 读参数：优先 ?query，其次 #hash（file:// 下 history 不可写，状态存 hash） */
  function urlParams() {
    var search = window.location.search;
    var hash = window.location.hash.replace(/^#/, '');
    var raw = search || (hash ? (hash.charAt(0) === '?' ? hash : '?' + hash) : '');
    return new window.URLSearchParams(raw);
  }

  function parseUrl() {
    var sp = urlParams();

    state.q = (sp.get('q') || '').trim().slice(0, 60);
    state.genre = keepKnown('genre', listParam(sp.get('genre')));
    state.platform = keepKnown('platform', listParam(sp.get('platform')));
    state.year = keepKnown('year', listParam(sp.get('year')));
    state.score = keepKnown('score', listParam(sp.get('score')));
    state.price = keepKnown('price', listParam(sp.get('price')));
    state.sale = sp.get('sale') === '1';
    state.wishlist = sp.get('wishlist') === '1';
    state.view = sp.get('view') === 'list' ? 'list' : 'grid';

    var sort = sp.get('sort');
    if (SORTS.indexOf(sort) >= 0) state.sort = sort;

    return sp.get('game');
  }

  function buildQuery() {
    var p = [];
    if (state.q) p.push('q=' + encodeURIComponent(state.q));
    if (state.genre.length) p.push('genre=' + state.genre.map(encodeURIComponent).join(','));
    if (state.platform.length) p.push('platform=' + state.platform.join(','));
    if (state.year.length) p.push('year=' + state.year.join(','));
    if (state.score.length) p.push('score=' + state.score.join(','));
    if (state.price.length) p.push('price=' + state.price.join(','));
    if (state.sale) p.push('sale=1');
    if (state.wishlist) p.push('wishlist=1');
    if (state.sort !== 'hot') p.push('sort=' + state.sort);
    if (state.view === 'list') p.push('view=list');
    return p.join('&');
  }

  function syncUrl() {
    var qs = buildQuery();
    var base = window.location.pathname;

    /* 首选 replaceState：不新增历史记录，地址栏干净 */
    try {
      window.history.replaceState(null, '', base + (qs ? '?' + qs : ''));
      return;
    } catch (e) {
      /* file:// 直接打开时文档 origin 为 null，history 写入会抛 SecurityError */
    }

    /* 退化：用 hash 承载同样一份状态；location.replace 不堆历史记录 */
    if (!qs && !window.location.hash) return;
    try {
      window.location.replace(base + '#' + qs);
    } catch (e2) { /* 忽略：极少数环境两个都不让写，筛选仍然可用 */ }
  }

  /* ======================================================================
     渲染
     ====================================================================== */
  function renderFacets() {
    var hosts = {
      genre: el.facetGenre, platform: el.facetPlatform,
      year: el.facetYear, score: el.facetScore, price: el.facetPrice
    };

    Object.keys(hosts).forEach(function (facet) {
      var host = hosts[facet];
      if (!host) return;
      host.innerHTML = facetOptions[facet].map(function (o) {
        return '<button class="chip chip--sm" type="button" data-facet="' + facet +
          '" data-value="' + esc(o.value) + '" aria-pressed="false">' +
          esc(o.label) + '<span class="chip__count">' + o.count + '</span></button>';
      }).join('');
    });
  }

  function syncFacets() {
    var chips = el.filters.querySelectorAll('[data-facet]');
    for (var i = 0; i < chips.length; i++) {
      var facet = chips[i].getAttribute('data-facet');
      var value = chips[i].getAttribute('data-value');
      chips[i].setAttribute('aria-pressed', state[facet].indexOf(value) >= 0 ? 'true' : 'false');
    }
    el.saleOnly.checked = state.sale;
  }

  function chipHtml(facet, value, label) {
    return '<button class="chip chip--sm" type="button" aria-pressed="true" ' +
      'data-remove-facet="' + facet + '" data-remove-value="' + esc(value) + '">' +
      esc(label) +
      '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
      'stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>' +
      '</button>';
  }

  function renderActive() {
    var out = [];

    ['genre', 'platform', 'year', 'score', 'price'].forEach(function (facet) {
      state[facet].forEach(function (value) {
        var opt = findOption(facet, value);
        out.push(chipHtml(facet, value, opt ? opt.label : value));
      });
    });
    if (state.sale) out.push(chipHtml('sale', '1', '正在促销'));
    if (state.wishlist) out.push(chipHtml('wishlist', '1', '我的愿望单'));
    if (state.q) out.push(chipHtml('q', '', '搜索：' + state.q));

    if (out.length) {
      out.push('<button class="chip chip--sm" type="button" data-clear-all>清空条件</button>');
      el.activeFilters.innerHTML = out.join('');
      el.activeFilters.hidden = false;
    } else {
      el.activeFilters.innerHTML = '';
      el.activeFilters.hidden = true;
    }
  }

  function updateCount(total) {
    var html = '共 <strong>' + total + '</strong> 部作品';
    if (total !== DATA.length) html += ' <span class="dim">/ ' + DATA.length + ' 部在库</span>';
    el.count.innerHTML = html;
  }

  function updateHead(total) {
    var title = '全部分类';
    var en = 'All games';
    var desc;

    if (state.wishlist) {
      title = '我的愿望单';
      en = 'Wishlist';
      desc = total
        ? '已收藏 ' + total + ' 部作品，点开卡片可以继续查看或移出愿望单。'
        : '愿望单还是空的。在任意作品详情里点「加入愿望单」，收藏会保存在这台设备的浏览器里。';
    } else if (state.q) {
      title = '搜索：' + state.q;
      en = 'Search';
      desc = total
        ? '关键词「' + state.q + '」匹配到 ' + total + ' 部作品。'
        : '没有找到与「' + state.q + '」匹配的作品，试试更短的关键词。';
    } else if (state.genre.length === 1) {
      title = state.genre[0];
      en = 'Genre';
      desc = '「' + state.genre[0] + '」共 ' + total + ' 部。可以继续叠加平台、年份、评分和价格条件。';
    } else if (state.genre.length > 1) {
      title = state.genre.length + ' 个类型';
      en = 'Genres';
      desc = '当前选中 ' + state.genre.length + ' 个类型，共 ' + total + ' 部作品。';
    } else {
      desc = total === DATA.length
        ? DATA.length + ' 部单机作品，按类型、平台、年份、评分和价格慢慢翻。筛选条件会写进地址栏，刷新和分享都能复现同一份结果。'
        : '当前条件筛出 ' + total + ' 部作品，库中共 ' + DATA.length + ' 部。';
    }

    el.title.textContent = title;
    el.titleEn.textContent = en;
    el.desc.textContent = desc;
    doc.title = title + ' · 游集 GAMEHUB';
  }

  function updateLoadMore() {
    var total = current.length;
    if (!total) {
      el.loadMore.hidden = true;
      return;
    }
    el.loadMore.hidden = false;
    if (shown >= total) {
      el.loadMoreBtn.hidden = true;
      el.loadHint.textContent = '已浏览全部 ' + total + ' 部';
    } else {
      el.loadMoreBtn.hidden = false;
      el.loadRemaining.textContent = total - shown;
      el.loadHint.textContent = '已显示 ' + shown + ' / ' + total + ' 部';
    }
  }

  function appendChunk() {
    var end = Math.min(shown + PAGE_SIZE, current.length);
    var html = '';
    for (var i = shown; i < end; i++) {
      html += state.view === 'list' ? GH.render.listCard(current[i]) : GH.render.card(current[i]);
    }
    if (html) {
      var tmp = doc.createElement('div');
      tmp.innerHTML = html;
      var frag = doc.createDocumentFragment();
      while (tmp.firstChild) frag.appendChild(tmp.firstChild);
      el.results.appendChild(frag);
      shown = end;
      GH.mountCovers(el.results);
    }
    updateLoadMore();
  }

  function render() {
    current = sortList(DATA.filter(matches));
    shown = 0;
    el.results.innerHTML = '';

    if (el.skeleton) {
      el.skeleton.remove();
      el.skeleton = null;
    }

    if (!current.length) {
      el.results.hidden = true;
      el.state.hidden = false;
      el.loadMore.hidden = true;

      if (state.wishlist) {
        el.stateTitle.textContent = '愿望单还是空的';
        el.stateDesc.textContent = '在任意作品详情里点「加入愿望单」，收藏会保存在这台设备的浏览器里。';
      } else if (state.q) {
        el.stateTitle.textContent = '没有匹配的作品';
        el.stateDesc.textContent = '没有找到与「' + state.q + '」相关的内容，试试更短的关键词，或者把筛选项放宽。';
      } else {
        el.stateTitle.textContent = '没有匹配的作品';
        el.stateDesc.textContent = '当前条件组合过窄。去掉一两个筛选项，通常就能看到结果。';
      }
      el.stateReset.hidden = !hasFilters();
    } else {
      el.results.hidden = false;
      el.state.hidden = true;
      appendChunk();
    }

    updateCount(current.length);
    updateHead(current.length);
    renderActive();
    syncFacets();
    syncUrl();
  }

  /* ======================================================================
     清空 / 视图
     ====================================================================== */
  function clearAll() {
    state.genre = [];
    state.platform = [];
    state.year = [];
    state.score = [];
    state.price = [];
    state.q = '';
    state.sale = false;
    state.wishlist = false;
    el.search.value = '';
    render();
  }

  function applyView() {
    el.results.className = state.view === 'list' ? 'cat-list' : 'cat-grid';
    var btns = el.viewToggle.querySelectorAll('[data-view]');
    for (var i = 0; i < btns.length; i++) {
      btns[i].setAttribute('aria-pressed', btns[i].getAttribute('data-view') === state.view ? 'true' : 'false');
    }
  }

  /* ======================================================================
     移动端筛选抽屉
     ====================================================================== */
  function openFilters() {
    el.filters.classList.add('is-open');
    el.scrim.classList.add('is-open');
    el.filterToggle.setAttribute('aria-expanded', 'true');
    doc.body.style.overflow = 'hidden';
    window.setTimeout(function () {
      if (el.filtersClose) el.filtersClose.focus();
    }, 60);
  }

  function closeFilters(restoreFocus) {
    if (!el.filters.classList.contains('is-open')) return;
    el.filters.classList.remove('is-open');
    el.scrim.classList.remove('is-open');
    el.filterToggle.setAttribute('aria-expanded', 'false');
    doc.body.style.overflow = '';
    if (restoreFocus) el.filterToggle.focus();
  }

  function scrollToResults() {
    var top = el.results.getBoundingClientRect().top + window.scrollY - 140;
    window.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
  }

  /* ======================================================================
     事件绑定
     ====================================================================== */
  function bind() {
    el.filters.addEventListener('click', function (e) {
      var chip = e.target.closest('[data-facet]');
      if (!chip) return;
      var facet = chip.getAttribute('data-facet');
      var value = chip.getAttribute('data-value');
      var i = state[facet].indexOf(value);
      if (i >= 0) state[facet].splice(i, 1);
      else state[facet].push(value);
      render();
    });

    el.activeFilters.addEventListener('click', function (e) {
      if (e.target.closest('[data-clear-all]')) {
        clearAll();
        return;
      }
      var chip = e.target.closest('[data-remove-facet]');
      if (!chip) return;
      var facet = chip.getAttribute('data-remove-facet');
      var value = chip.getAttribute('data-remove-value');

      if (facet === 'sale') state.sale = false;
      else if (facet === 'wishlist') state.wishlist = false;
      else if (facet === 'q') {
        state.q = '';
        el.search.value = '';
      } else {
        var i = state[facet].indexOf(value);
        if (i >= 0) state[facet].splice(i, 1);
      }
      render();
    });

    el.saleOnly.addEventListener('change', function () {
      state.sale = el.saleOnly.checked;
      render();
    });

    el.filterReset.addEventListener('click', clearAll);
    el.stateReset.addEventListener('click', clearAll);

    el.sortSelect.addEventListener('change', function () {
      state.sort = el.sortSelect.value;
      render();
    });

    el.viewToggle.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-view]');
      if (!btn) return;
      state.view = btn.getAttribute('data-view') === 'list' ? 'list' : 'grid';
      applyView();
      render();
    });

    var timer = null;
    function commitSearch() {
      var q = el.search.value.trim();
      if (q === state.q) return;
      state.q = q.slice(0, 60);
      render();
    }

    el.search.addEventListener('input', function () {
      window.clearTimeout(timer);
      timer = window.setTimeout(commitSearch, 220);
    });

    el.search.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        window.clearTimeout(timer);
        commitSearch();
      } else if (e.key === 'Escape' && el.search.value) {
        el.search.value = '';
        window.clearTimeout(timer);
        commitSearch();
      }
    });

    el.loadMoreBtn.addEventListener('click', function () {
      el.loadMoreBtn.disabled = true;
      window.requestAnimationFrame(function () {
        appendChunk();
        el.loadMoreBtn.disabled = false;
      });
    });

    el.filterToggle.addEventListener('click', function () {
      if (el.filters.classList.contains('is-open')) closeFilters(true);
      else openFilters();
    });
    el.filtersClose.addEventListener('click', function () { closeFilters(true); });
    el.scrim.addEventListener('click', function () { closeFilters(true); });
    el.filterApply.addEventListener('click', function () {
      closeFilters(false);
      scrollToResults();
    });

    doc.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeFilters(true);
    });

    var mq = window.matchMedia ? window.matchMedia('(min-width: 1025px)') : null;
    if (mq) {
      var onWide = function () { if (mq.matches) closeFilters(false); };
      if (mq.addEventListener) mq.addEventListener('change', onWide);
      else if (mq.addListener) mq.addListener(onWide);
    }
  }

  /* ======================================================================
     启动
     ====================================================================== */
  function refs() {
    el.title = doc.getElementById('catTitle');
    el.titleEn = doc.getElementById('catTitleEn');
    el.desc = doc.getElementById('catDesc');
    el.count = doc.getElementById('catCount');
    el.search = doc.getElementById('catSearch');
    el.sortSelect = doc.getElementById('sortSelect');
    el.viewToggle = doc.querySelector('.cat-view-toggle');
    el.filters = doc.getElementById('catFilters');
    el.filterToggle = doc.getElementById('filterToggle');
    el.filtersClose = doc.getElementById('filtersClose');
    el.filterApply = doc.getElementById('filterApply');
    el.filterReset = doc.getElementById('filterReset');
    el.saleOnly = doc.getElementById('saleOnly');
    el.scrim = doc.getElementById('filtersScrim');
    el.facetGenre = doc.getElementById('facetGenre');
    el.facetPlatform = doc.getElementById('facetPlatform');
    el.facetYear = doc.getElementById('facetYear');
    el.facetScore = doc.getElementById('facetScore');
    el.facetPrice = doc.getElementById('facetPrice');
    el.activeFilters = doc.getElementById('activeFilters');
    el.results = doc.getElementById('gameResults');
    el.skeleton = doc.getElementById('catSkeleton');
    el.state = doc.getElementById('catState');
    el.stateTitle = doc.getElementById('stateTitle');
    el.stateDesc = doc.getElementById('stateDesc');
    el.stateReset = doc.getElementById('stateReset');
    el.loadMore = doc.getElementById('loadMore');
    el.loadMoreBtn = doc.getElementById('loadMoreBtn');
    el.loadRemaining = doc.getElementById('loadRemaining');
    el.loadHint = doc.getElementById('loadHint');
  }

  function boot() {
    if (!el.results || !GH) return;

    buildFacetOptions();
    var gameId = parseUrl();

    renderFacets();
    el.sortSelect.value = state.sort;
    el.search.value = state.q;
    el.saleOnly.checked = state.sale;
    applyView();

    bind();
    render();

    /* 旧链接（?game=id）兼容：统一转到独立详情页 */
    if (gameId && GH.data.byId[gameId]) {
      window.location.replace('game.html?id=' + encodeURIComponent(gameId));
    }
  }

  function init() {
    refs();
    if (!el.results) return; /* 非分类页，直接退出 */
    if (DATA.length === 0) {
      /* 数据加载失败（脚本缺失或被拦截）：给出错误态而不是空白页 */
      if (el.skeleton) el.skeleton.remove();
      el.state.hidden = false;
      el.stateTitle.textContent = '作品库没有加载出来';
      el.stateDesc.textContent = '请确认 assets/js/games.js 与页面在同一目录下，然后刷新重试。';
      el.stateReset.hidden = true;
      el.count.textContent = '数据加载失败';
      return;
    }
    boot();
  }

  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', init);
  else init();
})();
