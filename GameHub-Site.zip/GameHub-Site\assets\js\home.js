/* ==========================================================================
   游集 GAMEHUB — home.js
   首页：封面拼接墙、搜索联想、数字滚动、横向轨道、类型入口
   依赖：games.js（数据）、cover.js（封面）、app.js（公共组件）
   ========================================================================== */

(function () {
  'use strict';

  var doc = document;
  var DATA = window.GAME_DATA || [];
  var GH = window.GameHub;

  function byId(id) { return GH && GH.data.byId[id]; }

  function esc(s) {
    return String(s === undefined || s === null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* ---------- 确定性打散：同一批数据每次打开顺序一致 ---------- */
  function seeded(list, seed) {
    var arr = list.slice();
    var s = seed || 7;
    for (var i = arr.length - 1; i > 0; i--) {
      s = (s * 1103515245 + 12345) & 0x7fffffff;
      var j = s % (i + 1);
      var t = arr[i];
      arr[i] = arr[j];
      arr[j] = t;
    }
    return arr;
  }

  /* ======================================================================
     1. Hero 封面拼接墙
     ====================================================================== */
  function buildWall() {
    var wall = doc.getElementById('heroWall');
    if (!wall) return;

    var picked = seeded(DATA, 20261112);
    var rows = 4;
    var perRow = window.innerWidth < 768 ? 7 : 11;
    var durations = [70, 88, 104, 120];

    var html = '';
    for (var r = 0; r < rows; r++) {
      var slice = picked.slice(r * perRow, r * perRow + perRow);
      var items = '';
      /* 复制两份以实现无缝循环：translateX(-50%) 正好回到起点 */
      for (var copy = 0; copy < 2; copy++) {
        for (var i = 0; i < slice.length; i++) {
          items += '<figure class="wall-item" data-cover-id="' + esc(slice[i].id) + '"></figure>';
        }
      }
      html += '<div class="wall-row" style="--row-dur:' + durations[r % durations.length] + 's">' + items + '</div>';
    }
    wall.innerHTML = html;

    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) {
      var rowsEls = wall.querySelectorAll('.wall-row');
      for (var k = 0; k < rowsEls.length; k++) rowsEls[k].style.animation = 'none';
    }

    GH.mountCovers(wall);
  }

  /* ======================================================================
     2. 搜索 + 即时联想
     ====================================================================== */
  function initSearch() {
    var form = doc.getElementById('heroSearch');
    var input = doc.getElementById('searchInput');
    var panel = doc.getElementById('searchPanel');
    if (!form || !input || !panel) return;

    var active = -1;
    var results = [];

    function match(q) {
      q = q.trim().toLowerCase();
      if (!q) return [];
      var starts = [];
      var contains = [];
      for (var i = 0; i < DATA.length && starts.length + contains.length < 60; i++) {
        var g = DATA[i];
        var cn = g.cn.toLowerCase();
        var en = g.en.toLowerCase();
        var dev = g.dev.toLowerCase();
        if (cn.indexOf(q) === 0 || en.indexOf(q) === 0) starts.push(g);
        else if (cn.indexOf(q) >= 0 || en.indexOf(q) >= 0 || dev.indexOf(q) >= 0 || g.genre.indexOf(q) >= 0) contains.push(g);
      }
      return starts.concat(contains).slice(0, 6);
    }

    function render(list) {
      results = list;
      active = -1;
      if (!list.length) {
        panel.innerHTML = '<div class="search__empty">没有匹配的作品，换个关键词试试</div>';
        panel.hidden = false;
        return;
      }
      panel.innerHTML = list.map(function (g, i) {
        return '<button class="search__opt" type="button" role="option" data-opt="' + i + '" data-id="' + esc(g.id) + '">' +
          '<span class="search__thumb" data-cover-id="' + esc(g.id) + '"></span>' +
          '<span class="search__opt-name">' + esc(g.cn) + '</span>' +
          '<span class="search__opt-meta">' + esc(g.genre) + ' · ' + g.year + '</span>' +
          '</button>';
      }).join('');
      panel.hidden = false;
      GH.mountCovers(panel);
    }

    function highlight(i) {
      var opts = panel.querySelectorAll('.search__opt');
      for (var k = 0; k < opts.length; k++) opts[k].classList.toggle('is-active', k === i);
      active = i;
    }

    var timer = null;
    input.addEventListener('input', function () {
      window.clearTimeout(timer);
      var val = input.value;
      timer = window.setTimeout(function () {
        if (val.trim().length < 1) {
          panel.hidden = true;
          return;
        }
        render(match(val));
      }, 180);
    });

    input.addEventListener('keydown', function (e) {
      if (panel.hidden || !results.length) {
        if (e.key === 'Escape') panel.hidden = true;
        return;
      }
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        highlight((active + 1) % results.length);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        highlight((active - 1 + results.length) % results.length);
      } else if (e.key === 'Enter') {
        if (active >= 0) {
          e.preventDefault();
          window.location.href = 'game.html?id=' + encodeURIComponent(results[active].id);
        }
      } else if (e.key === 'Escape') {
        panel.hidden = true;
      }
    });

    panel.addEventListener('click', function (e) {
      var opt = e.target.closest('[data-opt]');
      if (!opt) return;
      window.location.href = 'game.html?id=' + encodeURIComponent(opt.getAttribute('data-id'));
    });

    doc.addEventListener('click', function (e) {
      if (!e.target.closest('#heroSearch')) panel.hidden = true;
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var q = input.value.trim();
      window.location.href = q ? 'category.html?q=' + encodeURIComponent(q) : 'category.html';
    });
  }

  /* ======================================================================
     3. 数字滚动（进入视口触发一次）
     ====================================================================== */
  function initStats() {
    var nodes = doc.querySelectorAll('[data-count]');
    if (!nodes.length) return;

    function run(el) {
      var target = Number(el.getAttribute('data-count'));
      var suffix = el.getAttribute('data-suffix') || '';
      var dur = 900;
      var start = 0;
      var t0 = 0;

      function frame(t) {
        if (!t0) t0 = t;
        var p = Math.min(1, (t - t0) / dur);
        var eased = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(start + (target - start) * eased) + suffix;
        if (p < 1) window.requestAnimationFrame(frame);
      }
      window.requestAnimationFrame(frame);
    }

    if (!('IntersectionObserver' in window)) {
      for (var i = 0; i < nodes.length; i++) run(nodes[i]);
      return;
    }

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          run(entry.target);
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });

    for (var j = 0; j < nodes.length; j++) io.observe(nodes[j]);
  }

  /* ======================================================================
     4. 横向轨道
     ====================================================================== */
  function initRail() {
    var wraps = doc.querySelectorAll('[data-rail]');
    Array.prototype.forEach.call(wraps, function (wrap) {
      var rail = wrap.querySelector('.rail');
      var prev = wrap.querySelector('[data-rail-prev]');
      var next = wrap.querySelector('[data-rail-next]');
      if (!rail) return;

      function step() {
        var card = rail.querySelector('.game-card');
        return card ? card.getBoundingClientRect().width + 16 : 200;
      }

      function sync() {
        if (!prev || !next) return;
        prev.disabled = rail.scrollLeft <= 2;
        next.disabled = rail.scrollLeft + rail.clientWidth >= rail.scrollWidth - 2;
      }

      if (prev) prev.addEventListener('click', function () { rail.scrollBy({ left: -step() * 3, behavior: 'smooth' }); });
      if (next) next.addEventListener('click', function () { rail.scrollBy({ left: step() * 3, behavior: 'smooth' }); });
      rail.addEventListener('scroll', sync, { passive: true });
      window.addEventListener('resize', sync);
      sync();
    });
  }

  /* ======================================================================
     家族去重取样：相邻两张不同配色家族，优先用没出现过的家族
     ====================================================================== */
  function pickDiverse(list, n) {
    var pool = list.slice();
    var out = [];
    var used = {};

    function fam(g) {
      return (window.CoverEngine && window.CoverEngine.genreFamily)
        ? window.CoverEngine.genreFamily(g.genre)
        : g.genre;
    }

    while (out.length < n && pool.length) {
      var bestI = 0;
      var bestScore = Infinity;
      for (var i = 0; i < pool.length; i++) {
        var f = fam(pool[i]);
        var score = (used[f] || 0) * 10 + i * 0.001;
        if (out.length && fam(out[out.length - 1]) === f) score += 100;
        if (score < bestScore) {
          bestScore = score;
          bestI = i;
        }
      }
      var pick = pool.splice(bestI, 1)[0];
      used[fam(pick)] = (used[fam(pick)] || 0) + 1;
      out.push(pick);
    }
    return out;
  }

  /* ======================================================================
     5. 渲染各区块
     ====================================================================== */
  function renderSections() {
    var GHr = GH.render;

    /* 本周热门：评分最高的一批里做家族去重 */
    var hotPool = seeded(DATA, 911).sort(function (a, b) { return b.score - a.score; }).slice(0, 40);
    GHr.cards(doc.getElementById('hotRail'), pickDiverse(hotPool, 14));

    /* 新作上架：2025—2026 */
    var freshPool = DATA.filter(function (g) { return g.year >= 2025; })
      .sort(function (a, b) { return b.year - a.year || b.score - a.score; });
    GHr.cards(doc.getElementById('newGrid'), pickDiverse(freshPool, 6));

    /* 折扣专区：折扣幅度靠前的一批里做家族去重 */
    var salePool = DATA.filter(function (g) { return g.discount > 0; })
      .sort(function (a, b) { return b.discount - a.discount || b.score - a.score; })
      .slice(0, 24);
    GHr.cards(doc.getElementById('saleGrid'), pickDiverse(salePool, 6));

    /* 类型入口：取数量最多的 10 个类型 */
    var counts = {};
    DATA.forEach(function (g) { counts[g.genre] = (counts[g.genre] || 0) + 1; });
    var genres = Object.keys(counts).sort(function (a, b) { return counts[b] - counts[a]; }).slice(0, 10);

    var grid = doc.getElementById('genreGrid');
    if (grid) {
      grid.innerHTML = genres.map(function (genre) {
        var picks = DATA.filter(function (g) { return g.genre === genre; }).slice(0, 6);
        var mosaic = picks.map(function (g) {
          return '<span data-cover-id="' + esc(g.id) + '"></span>';
        }).join('');
        return '<a class="genre-card" href="category.html?genre=' + encodeURIComponent(genre) + '">' +
          '<span class="genre-card__mosaic" aria-hidden="true">' + mosaic + '</span>' +
          '<span class="genre-card__veil" aria-hidden="true"></span>' +
          '<span class="genre-card__text">' +
          '<span class="genre-card__name">' + esc(genre) + '</span>' +
          '<span class="genre-card__count">' + counts[genre] + ' 部作品</span>' +
          '</span></a>';
      }).join('');
      GH.mountCovers(grid);
    }
  }

  /* ======================================================================
     启动
     ====================================================================== */
  function boot() {
    if (!GH) return;
    buildWall();
    initSearch();
    renderSections();
    initStats();
    initRail();
  }

  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
