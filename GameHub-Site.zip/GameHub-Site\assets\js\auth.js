/* ==========================================================================
   游集 GAMEHUB — auth.js
   用户系统页：登录 / 注册切换、字段级校验、密码强度、提交态与结果态
   依赖：app.js（主题、登录态、toast、封面挂载）
   ========================================================================== */

(function () {
  'use strict';

  var doc = document;
  var GH = window.GameHub;
  var DATA = window.GAME_DATA || [];
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[A-Za-z]{2,}$/;
  var OWNED_KEY = 'gamehub.owned';

  var el = {};
  var mode = 'login';
  var nextUrl = '';

  /* ======================================================================
     规则
     ====================================================================== */
  function loginRules() {
    return {
      email: function () {
        var v = el.loginEmail.value.trim();
        if (!v) return '请输入邮箱地址';
        if (!EMAIL_RE.test(v)) return '邮箱格式不正确，示例：name@example.com';
        return '';
      },
      password: function () {
        var v = el.loginPwd.value;
        if (!v) return '请输入密码';
        if (v.length < 6) return '密码至少 6 位';
        return '';
      }
    };
  }

  function registerRules() {
    return {
      nickname: function () {
        var v = el.regNick.value.trim();
        if (v.length < 2) return '昵称至少 2 个字符';
        if (v.length > 16) return '昵称最多 16 个字符';
        return '';
      },
      email: function () {
        var v = el.regEmail.value.trim();
        if (!v) return '请输入邮箱地址';
        if (!EMAIL_RE.test(v)) return '邮箱格式不正确，示例：name@example.com';
        if (v.toLowerCase() === el.regPwd.value.toLowerCase()) return '密码不能和邮箱相同';
        return '';
      },
      password: function () {
        var v = el.regPwd.value;
        if (v.length < 6) return '密码至少 6 位';
        if (/^\d+$/.test(v)) return '纯数字密码太容易被猜到，加几个字母';
        return '';
      },
      confirm: function () {
        if (!el.regPwd2.value) return '请再输入一次密码';
        if (el.regPwd2.value !== el.regPwd.value) return '两次输入的密码不一致';
        return '';
      }
    };
  }

  /* ======================================================================
     校验与错误呈现
     ====================================================================== */
  function fieldsOf(form) {
    var nodes = form.querySelectorAll('.field[data-field]');
    var map = {};
    for (var i = 0; i < nodes.length; i++) {
      map[nodes[i].getAttribute('data-field')] = nodes[i];
    }
    return map;
  }

  function paintField(field, msg) {
    if (!field) return;
    var err = field.querySelector('.field__error');
    var input = field.querySelector('.input');
    if (msg) {
      field.setAttribute('data-invalid', 'true');
      if (err) { err.textContent = msg; err.hidden = false; }
      if (input) input.setAttribute('aria-invalid', 'true');
    } else {
      field.removeAttribute('data-invalid');
      if (err) { err.textContent = ''; err.hidden = true; }
      if (input) input.removeAttribute('aria-invalid');
    }
  }

  function validate(form, rules) {
    var fields = fieldsOf(form);
    var errors = {};
    Object.keys(rules).forEach(function (name) {
      var msg = rules[name]();
      if (msg) errors[name] = msg;
      paintField(fields[name], msg);
    });
    return errors;
  }

  function clearErrors(form) {
    var fields = fieldsOf(form);
    Object.keys(fields).forEach(function (k) { paintField(fields[k], ''); });
  }

  function setAlert(node, msg) {
    if (!node) return;
    node.textContent = msg || '';
    node.hidden = !msg;
  }

  function focusFirstInvalid(form) {
    var bad = form.querySelector('.field[data-invalid="true"] .input');
    if (bad) bad.focus();
  }

  function setLoading(btn, on, label) {
    if (!btn) return;
    if (on) {
      btn.dataset.label = btn.textContent;
      btn.classList.add('is-loading');
      btn.disabled = true;
      btn.textContent = label;
    } else {
      btn.classList.remove('is-loading');
      btn.disabled = false;
      btn.textContent = label || btn.dataset.label || '提交';
    }
  }

  /* ======================================================================
     形态切换：登录 / 注册 / 成功 / 已登录
     ====================================================================== */
  var VIEWS = ['loginForm', 'registerForm', 'authSuccess', 'authAccount'];

  function showView(name) {
    VIEWS.forEach(function (id) {
      if (el[id]) el[id].hidden = id !== name;
    });
    el.authTabs.hidden = name !== 'loginForm' && name !== 'registerForm';
    el.authHeading.hidden = name === 'authAccount';
    el.authSub.hidden = name === 'authAccount';
  }

  function setMode(next, opts) {
    opts = opts || {};
    mode = next === 'register' ? 'register' : 'login';
    var isReg = mode === 'register';

    el.tabLogin.setAttribute('aria-selected', isReg ? 'false' : 'true');
    el.tabRegister.setAttribute('aria-selected', isReg ? 'true' : 'false');

    el.authHeading.textContent = isReg ? '创建账号' : '登录游集';
    el.authSub.textContent = isReg
      ? '注册后即可同步愿望单，演示站点无需真实信息。'
      : '用邮箱登录，继续上次的进度。';

    showView(isReg ? 'registerForm' : 'loginForm');
    setAlert(el.loginAlert, '');
    setAlert(el.regAlert, '');
    clearErrors(el.loginForm);
    clearErrors(el.registerForm);

    if (!opts.silent) {
      try {
        var url = window.location.pathname + '?mode=' + mode +
          (nextUrl ? '&next=' + encodeURIComponent(nextUrl) : '');
        window.history.replaceState(null, '', url);
      } catch (e) { /* file:// 下可能受限，忽略 */ }
    }

    var focusTarget = isReg ? el.regNick : el.loginEmail;
    if (!opts.noFocus && focusTarget) focusTarget.focus();
    doc.title = (isReg ? '注册' : '登录') + ' · 游集 GAMEHUB';
  }

  function showSuccess(title, desc, target) {
    el.authTabs.hidden = true;
    el.authHeading.hidden = true;
    el.authSub.hidden = true;
    showView('authSuccess');

    el.authDoneTitle.textContent = title;
    el.authDoneDesc.textContent = desc;

    var btn = el.authDoneBtn;
    btn.href = target || 'index.html';
    btn.textContent = target && target.indexOf('http') === 0 ? '立即前往' : '继续逛作品库';

    if (nextUrl) {
      btn.href = nextUrl;
      btn.textContent = '返回刚才的页面';
      window.setTimeout(function () { window.location.href = nextUrl; }, 1100);
    }
  }

  function ownedCount() {
    try {
      var arr = JSON.parse(localStorage.getItem(OWNED_KEY) || '[]');
      return Array.isArray(arr) ? arr.length : 0;
    } catch (e) {
      return 0;
    }
  }

  function showAccount() {
    var user = GH.auth.get();
    if (!user) return;
    el.authTabs.hidden = true;
    el.authHeading.hidden = true;
    el.authSub.hidden = true;
    showView('authAccount');

    el.acctAvatar.textContent = String(user.name || '游').slice(0, 1).toUpperCase();
    el.acctName.textContent = user.name;
    el.acctId.textContent = '本地演示账号 · 通行证 #' + (user.name || 'guest').toLowerCase();
    el.acctWish.textContent = GH.wishlist.count();
    el.acctOwned.textContent = ownedCount();
    el.acctTheme.textContent = GH.theme.get() === 'dark' ? '深色' : '浅色';

    doc.title = '我的账号 · 游集 GAMEHUB';
  }

  /* ======================================================================
     提交
     ====================================================================== */
  function submitLogin(e) {
    e.preventDefault();
    var errors = validate(el.loginForm, loginRules());
    var keys = Object.keys(errors);

    if (keys.length) {
      setAlert(el.loginAlert, '还有 ' + keys.length + ' 处需要修正，请检查标红的输入框。');
      focusFirstInvalid(el.loginForm);
      return;
    }

    setAlert(el.loginAlert, '');
    setLoading(el.loginBtn, true, '正在登录…');

    window.setTimeout(function () {
      setLoading(el.loginBtn, false, '登录');

      /* 演示：密码 000000 触发一次“账号密码不匹配”的服务端错误态 */
      if (el.loginPwd.value === '000000') {
        setAlert(el.loginAlert, '邮箱或密码不正确，请检查后重试。连续 5 次失败会临时锁定 10 分钟。');
        var field = el.loginForm.querySelector('.field[data-field="password"]');
        paintField(field, '账号与密码不匹配');
        el.loginPwd.select();
        return;
      }

      var name = el.loginEmail.value.trim().split('@')[0].replace(/[._-]+/g, '').slice(0, 12) || '玩家';
      GH.auth.set({ name: name }, el.remember.checked);
      showSuccess('登录成功', '欢迎回来，' + name + '。愿望单和游戏库已经同步到这台设备。');
    }, 820);
  }

  function submitRegister(e) {
    e.preventDefault();
    var errors = validate(el.registerForm, registerRules());
    var agreeError = el.regAgree.checked ? '' : '请先阅读并同意服务条款与隐私政策';

    var keys = Object.keys(errors);
    if (!keys.length && !agreeError) {
      setAlert(el.regAlert, '');
      setLoading(el.regBtn, true, '正在创建账号…');

      window.setTimeout(function () {
        setLoading(el.regBtn, false, '注册并登录');
        var nickname = el.regNick.value.trim();
        GH.auth.set({ name: nickname }, true);
        showSuccess('账号已创建', '你好，' + nickname + '。愿望单会从这台设备开始累积。');
      }, 900);
      return;
    }

    var msg = agreeError || ('还有 ' + keys.length + ' 处需要修正，请检查标红的输入框。');
    if (keys.length && agreeError) msg = '请先修正标红的输入框，并勾选同意条款。';
    setAlert(el.regAlert, msg);
    if (keys.length) focusFirstInvalid(el.registerForm);
  }

  /* ======================================================================
     密码强度
     ====================================================================== */
  function updateMeter() {
    var v = el.regPwd.value;
    var score = 0;
    if (v.length >= 6) score++;
    if (v.length >= 10) score++;
    if (/[A-Za-z]/.test(v) && /\d/.test(v)) score++;
    if (/[^A-Za-z0-9]/.test(v)) score++;

    var level = !v ? 0 : score <= 1 ? 1 : score <= 3 ? 2 : 3;
    el.pwMeter.setAttribute('data-level', String(level));

    var text = '强度：未输入 · 至少 6 位，建议混合字母与数字';
    if (level === 1) text = '强度：偏弱 · 再长一点，或混入数字';
    else if (level === 2) text = '强度：中等 · 日常使用够了，加个符号更稳';
    else if (level === 3) text = '强度：较强 · 适合长期使用';
    el.pwHint.textContent = text;
  }

  /* ======================================================================
     事件
     ====================================================================== */
  function bindForms() {
    el.loginForm.addEventListener('submit', submitLogin);
    el.registerForm.addEventListener('submit', submitRegister);

    /* 输入时就地消除错误；失焦时补一次校验 */
    function liveCheck(form, rules, name) {
      var field = form.querySelector('.field[data-field="' + name + '"]');
      if (field && field.getAttribute('data-invalid') === 'true') {
        paintField(field, rules[name]());
      }
    }

    el.loginEmail.addEventListener('input', function () { liveCheck(el.loginForm, loginRules(), 'email'); });
    el.loginPwd.addEventListener('input', function () { liveCheck(el.loginForm, loginRules(), 'password'); });
    el.loginEmail.addEventListener('blur', function () {
      paintField(el.loginForm.querySelector('.field[data-field="email"]'), loginRules().email());
    });

    el.regNick.addEventListener('input', function () { liveCheck(el.registerForm, registerRules(), 'nickname'); });
    el.regEmail.addEventListener('input', function () { liveCheck(el.registerForm, registerRules(), 'email'); });
    el.regPwd.addEventListener('input', function () {
      updateMeter();
      liveCheck(el.registerForm, registerRules(), 'password');
      var confirm = el.registerForm.querySelector('.field[data-field="confirm"]');
      if (confirm && confirm.getAttribute('data-invalid') === 'true') {
        paintField(confirm, registerRules().confirm());
      }
    });
    el.regPwd2.addEventListener('input', function () { liveCheck(el.registerForm, registerRules(), 'confirm'); });

    doc.addEventListener('click', function (e) {
      /* 密码显示/隐藏 */
      var eye = e.target.closest('[data-eye]');
      if (eye) {
        var input = doc.getElementById(eye.getAttribute('data-eye'));
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        eye.setAttribute('aria-pressed', show ? 'true' : 'false');
        eye.setAttribute('aria-label', show ? '隐藏密码' : '显示密码');
        input.focus();
        return;
      }

      /* 标签页与文字按钮 */
      var m = e.target.closest('[data-mode]');
      if (m) {
        setMode(m.getAttribute('data-mode'));
        return;
      }

      var third = e.target.closest('[data-third]');
      if (third) {
        GH.ui.toast(third.getAttribute('data-third') + ' 快捷登录暂未开放');
        return;
      }

      if (e.target.closest('#forgotBtn')) {
        GH.ui.toast('演示站点没有找回流程，换个邮箱注册即可');
        return;
      }

      /* 退出登录后回到表单态 */
      if (e.target.closest('#authAccount [data-logout]')) {
        window.setTimeout(function () {
          setMode('login', { silent: true, noFocus: true });
          el.loginForm.reset();
          el.registerForm.reset();
          updateMeter();
          GH.ui.toast('已退出，可以换个账号登录');
        }, 80);
      }
    });
  }

  /* ======================================================================
     左栏封面流
     ====================================================================== */
  function buildWall() {
    if (!el.wall || !DATA.length) return;
    var picks = [];
    for (var i = 0; i < 6; i++) picks.push(DATA[(i * 97 + 13) % DATA.length]);
    el.wall.innerHTML = picks.map(function (g) {
      return '<span data-cover-id="' + GH.escape(g.id) + '"></span>';
    }).join('');
    GH.mountCovers(el.wall);
  }

  /* ======================================================================
     启动
     ====================================================================== */
  function refs() {
    el.authTabs = doc.getElementById('authTabs');
    el.tabLogin = doc.getElementById('tabLogin');
    el.tabRegister = doc.getElementById('tabRegister');
    el.authHeading = doc.getElementById('authHeading');
    el.authSub = doc.getElementById('authSub');
    el.authNext = doc.getElementById('authNext');

    el.loginForm = doc.getElementById('loginForm');
    el.registerForm = doc.getElementById('registerForm');
    el.loginEmail = doc.getElementById('loginEmail');
    el.loginPwd = doc.getElementById('loginPassword');
    el.remember = doc.getElementById('rememberMe');
    el.loginAlert = doc.getElementById('loginAlert');
    el.loginBtn = doc.getElementById('loginSubmit');

    el.regNick = doc.getElementById('regNick');
    el.regEmail = doc.getElementById('regEmail');
    el.regPwd = doc.getElementById('regPassword');
    el.regPwd2 = doc.getElementById('regPassword2');
    el.regAgree = doc.getElementById('regAgree');
    el.regAlert = doc.getElementById('regAlert');
    el.regBtn = doc.getElementById('registerSubmit');
    el.pwMeter = doc.getElementById('pwMeter');
    el.pwHint = doc.getElementById('pwMeterHint');

    el.authSuccess = doc.getElementById('authSuccess');
    el.authDoneTitle = doc.getElementById('authDoneTitle');
    el.authDoneDesc = doc.getElementById('authDoneDesc');
    el.authDoneBtn = doc.getElementById('authDoneBtn');

    el.authAccount = doc.getElementById('authAccount');
    el.acctAvatar = doc.getElementById('acctAvatar');
    el.acctName = doc.getElementById('acctName');
    el.acctId = doc.getElementById('acctId');
    el.acctWish = doc.getElementById('acctWish');
    el.acctOwned = doc.getElementById('acctOwned');
    el.acctTheme = doc.getElementById('acctTheme');

    el.wall = doc.getElementById('authWall');
  }

  function init() {
    refs();
    if (!el.loginForm || !GH) return;

    var sp = new window.URLSearchParams(window.location.search);
    nextUrl = sp.get('next') || '';
    if (nextUrl && !/^[a-zA-Z0-9./?=&_%-]+$/.test(nextUrl)) nextUrl = ''; /* 只接受站内相对路径 */

    /* 主题切换后账号卡上的文案要跟着变 */
    var themeBtn = doc.querySelector('[data-theme-toggle]');
    if (themeBtn) {
      themeBtn.addEventListener('click', function () {
        if (el.authAccount.hidden) return;
        window.setTimeout(function () {
          el.acctTheme.textContent = GH.theme.get() === 'dark' ? '深色' : '浅色';
        }, 30);
      });
    }

    buildWall();
    updateMeter();
    bindForms();

    if (GH.auth.get()) {
      showAccount();
      return;
    }

    if (nextUrl) {
      el.authNext.hidden = false;
      el.authNext.textContent = '登录后将继续访问：' + nextUrl.replace(/^\/+/, '');
    }

    setMode(sp.get('mode') === 'register' ? 'register' : 'login', { silent: true, noFocus: true });
    el.loginEmail.focus();
  }

  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', init);
  else init();
})();
