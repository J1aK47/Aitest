/* ==========================================================================
   游集 GAMEHUB — 静态游戏数据集
   --------------------------------------------------------------------------
   说明：
   1. 数据以「类型分块」书写，每个块用 G(类型, 行数组) 收集，保证可读与可维护。
   2. 行内列序固定（见下方 COLS），运行时展开为完整对象并生成稳定 id。
   3. 全部为真实存在的单机 / 可单人游玩作品；评分为站内编辑分（60-98）。
   4. 不发起任何网络请求，纯静态数据。
   ========================================================================== */

(function () {
  'use strict';

  /* 列序：
     0 cn 中文名 | 1 en 英文名 | 2 year 年份 | 3 tags 副标签(|分隔)
     4 platforms 平台(,分隔) | 5 score 评分 | 6 price 原价(元) | 7 discount 折扣(%)
     8 dev 开发商 | 9 pub 发行商 | 10 blurb 一句话简介 */
  var COLS = 11;
  var rows = [];

  function G(genre, list) {
    for (var i = 0; i < list.length; i++) {
      var r = list[i];
      if (r.length !== COLS) throw new Error('数据列数错误：' + r[0]);
      rows.push([genre].concat(r));
    }
  }

  /* ── 动作角色扮演 ───────────────────────────────────────────── */
  G('动作角色扮演', [
    ['艾尔登法环', 'Elden Ring', 2022, '开放世界|高难度', 'PC,PS5,XSX', 96, 298, 0, 'FromSoftware', '万代南梦宫', '在被诅咒的狭间地集齐大卢恩，探索与苦战同样迷人。'],
    ['巫师3：狂猎', 'The Witcher 3: Wild Hunt', 2015, '开放世界|剧情', 'PC,PS5,XSX,NS', 97, 158, 70, 'CD Projekt Red', 'CD Projekt', '白狼横跨大陆寻找希里，支线常常比主线更动人。'],
    ['赛博朋克2077', 'Cyberpunk 2077', 2020, '开放世界|科幻', 'PC,PS5,XSX', 86, 298, 50, 'CD Projekt Red', 'CD Projekt', '在夜之城改写自己的命运，义体与霓虹一样晃眼。'],
    ['上古卷轴5：天际', 'The Elder Scrolls V: Skyrim', 2011, '开放世界|奇幻', 'PC,PS5,XSX,NS', 96, 128, 0, 'Bethesda Game Studios', 'Bethesda Softworks', '龙裔的呼声响彻雪原，走哪条路都算正解。'],
    ['辐射4', 'Fallout 4', 2015, '末世|建造', 'PC,PS5,XSX', 88, 128, 50, 'Bethesda Game Studios', 'Bethesda Softworks', '在核战废土找儿子，顺手建起一座定居点。'],
    ['地平线：西之绝境', 'Horizon Forbidden West', 2022, '末世|机械兽', 'PC,PS5', 89, 398, 0, 'Guerrilla Games', '索尼互动娱乐', '埃洛伊深入西境，猎杀机械兽并揭开旧世界真相。'],
    ['地平线：零之曙光', 'Horizon Zero Dawn', 2017, '末世|机械兽', 'PC,PS4,PS5', 89, 198, 0, 'Guerrilla Games', '索尼互动娱乐', '原始部落与机械巨兽并存的世界，弓弦是唯一答案。'],
    ['战神', 'God of War', 2018, '北欧神话|父子', 'PC,PS4,PS5', 94, 198, 0, 'Santa Monica Studio', '索尼互动娱乐', '奎托斯带着儿子走进北欧神域，一镜到底的旅程。'],
    ['战神：诸神黄昏', 'God of War Ragnarök', 2022, '北欧神话|父子', 'PC,PS5', 94, 398, 0, 'Santa Monica Studio', '索尼互动娱乐', '诸神黄昏将至，父子各自面对预言里的结局。'],
    ['刺客信条：奥德赛', "Assassin's Creed Odyssey", 2018, '古希腊|潜行', 'PC,PS5,XSX', 88, 298, 70, 'Ubisoft Quebec', '育碧', '在伯罗奔尼撒战争里做雇佣兵，海上陆地都能打。'],
    ['刺客信条：起源', "Assassin's Creed Origins", 2017, '古埃及|潜行', 'PC,PS4,PS5', 86, 198, 60, 'Ubisoft Montreal', '育碧', '金字塔与尼罗河畔，见证兄弟会的起点。'],
    ['刺客信条：英灵殿', "Assassin's Creed Valhalla", 2020, '维京|开放世界', 'PC,PS5,XSX', 84, 298, 0, 'Ubisoft Montreal', '育碧', '率长船南下劫掠英格兰，顺便建起自己的村落。'],
    ['暗黑破坏神4', 'Diablo IV', 2023, '刷装备|黑暗', 'PC,PS5,XSX', 84, 298, 0, 'Blizzard Entertainment', '暴雪娱乐', '莉莉丝的低语笼罩庇护之地，砍怪掉装永不停歇。'],
    ['暗黑破坏神2：重制版', 'Diablo II: Resurrected', 2021, '刷装备|经典', 'PC,PS5,XSX,NS', 88, 198, 0, 'Blizzard Entertainment', '暴雪娱乐', '二十年后重回崔斯特瑞姆，符文与词缀依然迷人。'],
    ['恐怖黎明', 'Grim Dawn', 2016, '刷装备|克苏鲁', 'PC', 88, 78, 50, 'Crate Entertainment', 'Crate Entertainment', '末世废土上的双职业搭配，能刷到天亮的暗黑系。'],
    ['火炬之光2', 'Torchlight II', 2012, '刷装备|卡通', 'PC,NS', 87, 68, 60, 'Runic Games', '完美世界', '轻快明亮的刷装小品，宠物替你跑腿卖货。'],
    ['尼尔：机械纪元', 'NieR: Automata', 2017, '剧情|机器人', 'PC,PS4,NS', 89, 268, 50, 'PlatinumGames', '史克威尔艾尼克斯', '人造人与机械生命体的战争，结局让人久久沉默。'],
    ['尼尔：人工生命', 'NieR Replicant ver.1.22', 2021, '剧情|重制', 'PC,PS4', 85, 268, 0, 'Toylogic', '史克威尔艾尼克斯', '为救妹妹踏上旅程，代价在最后才揭晓。'],
    ['王国之心3', 'Kingdom Hearts III', 2019, '迪士尼|动作', 'PC,PS4,XSX', 83, 328, 0, 'Square Enix', '史克威尔艾尼克斯', '与迪士尼角色并肩，钥匙刃斩向无心者。'],
    ['最终幻想7 重制版', 'Final Fantasy VII Remake', 2020, '日式|剧情', 'PC,PS5', 89, 398, 0, 'Square Enix', '史克威尔艾尼克斯', '米德加的魔晄炉下，重新讲述克劳德的记忆。'],
    ['最终幻想16', 'Final Fantasy XVI', 2023, '召唤兽|剧情', 'PC,PS5', 87, 398, 0, 'Square Enix', '史克威尔艾尼克斯', '显化者之间的国战，召唤兽对轰极尽华丽。'],
    ['最终幻想15', 'Final Fantasy XV', 2016, '公路旅行|剧情', 'PC,PS4,XSX', 81, 298, 0, 'Square Enix', '史克威尔艾尼克斯', '四位好友的自驾之旅，路上比终点更长。'],
    ['勇者斗恶龙11 S', 'Dragon Quest XI S', 2019, '日式|王道', 'PC,PS4,NS,XSX', 92, 298, 0, 'Square Enix', '史克威尔艾尼克斯', '被追杀的勇者走遍世界，王道到极致的冒险。'],
    ['怪物猎人：世界', 'Monster Hunter: World', 2018, '狩猎|共斗', 'PC,PS4,XSX', 90, 198, 50, 'Capcom', '卡普空', '追踪古龙迁徙，一把武器练到极致就够。'],
    ['怪物猎人：崛起', 'Monster Hunter Rise', 2021, '狩猎|和风', 'PC,NS,PS5', 88, 298, 0, 'Capcom', '卡普空', '翔虫带来的立体机动，和风村庄的狩猎日常。'],
    ['龙之信条2', "Dragon's Dogma 2", 2024, '奇幻|随从', 'PC,PS5,XSX', 86, 298, 30, 'Capcom', '卡普空', '随从会成长会犯错，旅途因此变得不可预测。'],
    ['鬼泣5', 'Devil May Cry 5', 2019, '连招|恶魔', 'PC,PS5,XSX', 88, 158, 0, 'Capcom', '卡普空', '三个男人一台戏，连招评分从 D 一路打到 SSS。'],
    ['剑星', 'Stellar Blade', 2024, '末世|动作', 'PC,PS5', 82, 398, 0, 'Shift Up', '索尼互动娱乐', '后启示录地球上的空降战士，出手干脆利落。'],
    ['渡神纪：芬尼斯崛起', 'Immortals Fenyx Rising', 2020, '希腊神话|解谜', 'PC,PS5,XSX,NS', 82, 198, 0, 'Ubisoft Quebec', '育碧', '希腊神话版开放世界解谜冒险，旁白相当贫嘴。'],
    ['中土世界：战争之影', 'Middle-earth: Shadow of War', 2017, '兽人|复仇', 'PC,PS4,XSX', 84, 158, 60, 'Monolith Productions', '华纳兄弟游戏', '培养自己的兽人军队，逐城攻下并完成复仇。'],
    ['中土世界：暗影魔多', 'Middle-earth: Shadow of Mordor', 2014, '兽人|潜行', 'PC,PS4', 85, 128, 0, 'Monolith Productions', '华纳兄弟游戏', '复仇系统让每个兽人队长都记得你的脸。'],
    ['蝙蝠侠：阿卡姆骑士', 'Batman: Arkham Knight', 2015, '超级英雄|潜行', 'PC,PS4', 87, 158, 60, 'Rocksteady Studios', '华纳兄弟游戏', '哥谭的最后一夜，蝙蝠车碾过整条街。'],
    ['漫威蜘蛛侠', "Marvel's Spider-Man", 2018, '超级英雄|都市', 'PC,PS4,PS5', 87, 298, 0, 'Insomniac Games', '索尼互动娱乐', '在纽约楼宇间摆荡，手感好到不想落地。'],
    ['蜘蛛侠：迈尔斯·莫拉莱斯', "Marvel's Spider-Man: Miles Morales", 2020, '超级英雄|都市', 'PC,PS5', 84, 298, 0, 'Insomniac Games', '索尼互动娱乐', '新人英雄的第一个冬天，连摆荡都带着电。'],
    ['漫威蜘蛛侠2', "Marvel's Spider-Man 2", 2023, '超级英雄|都市', 'PC,PS5', 90, 398, 0, 'Insomniac Games', '索尼互动娱乐', '彼得与迈尔斯双主角，毒液登场，纽约又热闹了。'],
    ['对马岛之魂', 'Ghost of Tsushima', 2020, '武士|开放世界', 'PC,PS4,PS5', 92, 298, 0, 'Sucker Punch Productions', '索尼互动娱乐', '黑泽明滤镜下的武士道，风会为你指路。'],
    ['仙剑奇侠传七', 'Sword and Fairy 7', 2021, '仙侠|剧情', 'PC,PS5', 78, 128, 0, '软星科技', '方块游戏', '仙侠世界的新一章，御剑飞行与家国情怀。'],
    ['古剑奇谭三', 'Gujian 3', 2018, '国风|剧情', 'PC', 84, 99, 40, '上海烛龙', '网元圣唐', '国风动作角色扮演，画面与叙事都很扎实。'],
    ['轩辕剑外传：穹之扉', 'Xuan-Yuan Sword: Gate of Firmament', 2015, '国风|剧情', 'PC', 75, 58, 0, '大宇资讯 DOMO 小组', '大宇资讯', '上古神话里的兄弟情，老配方换上新画面。'],
    ['圣剑传说：玛娜幻象', 'Visions of Mana', 2024, '日式|幻想', 'PC,PS5,XSX', 79, 298, 0, 'Square Enix', '史克威尔艾尼克斯', '元素精灵与少年少女，明亮通透的一场冒险。']
  ]);

  /* ── 魂类 ──────────────────────────────────────────────────── */
  G('魂类', [
    ['黑暗之魂3', 'Dark Souls III', 2016, '高难度|黑暗', 'PC,PS4,XSX', 89, 158, 0, 'FromSoftware', '万代南梦宫', '传火终章，每个 Boss 都是一堂课。'],
    ['黑暗之魂 重制版', 'Dark Souls Remastered', 2018, '高难度|经典', 'PC,PS4,NS', 87, 158, 0, 'QLOC', '万代南梦宫', '不死人的罗德兰朝圣，地图设计仍是教科书。'],
    ['黑暗之魂2：原罪学者', 'Dark Souls II: Scholar of the First Sin', 2015, '高难度|黑暗', 'PC,PS4,XSX', 85, 128, 60, 'FromSoftware', '万代南梦宫', '多兰古雷格的旅程，最冷门也最难缠的一作。'],
    ['血源诅咒', 'Bloodborne', 2015, '高难度|克苏鲁', 'PS4', 92, 198, 0, 'FromSoftware', '索尼互动娱乐', '雅南的猎人夜行，攻击就是最好的防守。'],
    ['只狼：影逝二度', 'Sekiro: Shadows Die Twice', 2019, '高难度|战国', 'PC,PS4,XSX', 90, 268, 50, 'FromSoftware', '动视', '拼刀、弹反、忍杀，节奏型战斗的极致。'],
    ['匹诺曹的谎言', 'Lies of P', 2023, '高难度|蒸汽朋克', 'PC,PS5,XSX', 84, 298, 0, 'Round8 Studio', 'NEOWIZ', '童话改写的暗黑人偶，武器还能拆开重组。'],
    ['堕落之主', 'Lords of the Fallen', 2023, '高难度|黑暗', 'PC,PS5,XSX', 71, 298, 0, 'Hexworks', 'CI Games', '生死双世界随时切换，体量巨大的魂系。'],
    ['装甲核心6：境界天火', 'Armored Core VI: Fires of Rubicon', 2023, '机甲|高难度', 'PC,PS5,XSX', 87, 298, 30, 'FromSoftware', '万代南梦宫', '高速机甲对战，FromSoftware 的另一种硬。'],
    ['遗迹2', 'Remnant II', 2023, '高难度|射击', 'PC,PS5,XSX', 84, 198, 0, 'Gunfire Games', 'Gearbox Publishing', '随机生成的世界，射击版魂系，Boss 很够味。'],
    ['遗迹：灰烬重生', 'Remnant: From the Ashes', 2019, '高难度|射击', 'PC,PS4,XSX', 78, 128, 0, 'Gunfire Games', '完美世界', '末世射击加魂系难度，刷世界意外地上头。'],
    ['仁王2', 'Nioh 2', 2020, '高难度|战国', 'PC,PS4,PS5', 86, 249, 0, 'Team Ninja', '光荣特库摩', '妖怪化与三段架势，和风动作深不见底。'],
    ['仁王', 'Nioh', 2017, '高难度|战国', 'PC,PS4', 85, 158, 50, 'Team Ninja', '光荣特库摩', '落命，然后再一次变强，战国妖怪一个都不会少。'],
    ['卧龙：苍天陨落', 'Wo Long: Fallen Dynasty', 2023, '高难度|三国', 'PC,PS5,XSX', 80, 298, 0, 'Team Ninja', '光荣特库摩', '三国题材的化劲战斗，刀光比史书更清楚。'],
    ['钢铁崛起', 'Steelrising', 2022, '高难度|蒸汽朋克', 'PC,PS5,XSX', 71, 198, 60, 'Spiders', 'NACON', '法国大革命背景下的机械魂系，机关与断头台并列。'],
    ['致命躯壳', 'Mortal Shell', 2020, '高难度|黑暗', 'PC,PS4,XSX', 76, 118, 0, 'Cold Symmetry', 'Playstack', '附身不同躯壳，换来截然不同的战斗风格。'],
    ['地狱之刃2：塞娜的史诗', "Senua's Saga: Hellblade II", 2024, '高难度|心理', 'PC,XSX', 82, 248, 0, 'Ninja Theory', 'Xbox 游戏工作室', '声音与画面都是压迫感，一战精神世界。'],
    ['地狱之刃：塞娜的献祭', 'Hellblade: Senua\'s Sacrifice', 2017, '高难度|心理', 'PC,PS4,XSX,NS', 84, 88, 0, 'Ninja Theory', '忍者理论', '戴上耳机再玩，精神病症被具象成耳语。'],
    ['噬血代码', 'Code Vein', 2019, '高难度|吸血鬼', 'PC,PS4,XSX', 74, 268, 0, 'Shift', '万代南梦宫', '带着吸血鬼同伴探索，二次元画风的魂。'],
    ['记忆边境', 'Thymesia', 2022, '高难度|瘟疫', 'PC,PS5,XSX', 76, 118, 0, 'OverBorder Studio', '虎牙', '短小精悍的拼刀魂系，节奏快得惊人。'],
    ['地狱点', 'Hellpoint', 2020, '高难度|太空', 'PC,PS4,XSX', 70, 98, 0, 'Cradle Games', 'tinyBuild', '废弃空间站里的探索，孤独感拉满。'],
    ['流浪之刃', 'Stray Blade', 2023, '高难度|奇幻', 'PC,PS5,XSX', 65, 158, 0, 'Point Blank Games', '505 Games', '明亮卡通的外壳，硬核战斗的内核。'],
    ['盐与避难所', 'Salt and Sanctuary', 2016, '高难度|2D', 'PC,PS4,NS', 85, 68, 0, 'Ska Studios', 'Ska Studios', '2D 魂系的开山作，下手重得像铁块。'],
    ['灰烬', 'Ashen', 2018, '高难度|末世', 'PC,PS4,XSX,NS', 78, 128, 0, 'A44', 'Annapurna Interactive', '无光世界的探索，遇见陌生人才有温度。'],
    ['星之诅咒', 'Asterigos: Curse of the Stars', 2022, '高难度|神话', 'PC,PS4,PS5', 76, 138, 0, 'Acme Gamestudio', 'tinyBuild', '轻快的希腊神话魂系，画面清爽明亮。'],
    ['恶意不息', 'No Rest for the Wicked', 2024, '高难度|俯视', 'PC,PS5,XSX', 78, 198, 20, 'Moon Studios', 'Private Division', '俯视角的硬核动作，美术质感动人。'],
    ['恶魔之魂 重制版', "Demon's Souls", 2020, '高难度|经典', 'PS5', 92, 468, 20, 'Bluepoint Games', '索尼互动娱乐', '重制版把原点打磨得锋利如新，难度一点没让步。']
  ]);

  /* ── 开放世界 ──────────────────────────────────────────────── */
  G('开放世界', [
    ['荒野大镖客2', 'Red Dead Redemption 2', 2018, '西部|剧情', 'PC,PS4,XSX', 97, 328, 50, 'Rockstar Games', 'Rockstar Games', '亡命牛仔的黄昏，世界细节多到奢侈。'],
    ['荒野大镖客', 'Red Dead Redemption', 2010, '西部|剧情', 'PS4,NS', 95, 198, 30, 'Rockstar San Diego', 'Rockstar Games', '约翰·马斯顿的赎罪之路，一首西部挽歌。'],
    ['侠盗猎车手5', 'Grand Theft Auto V', 2013, '都市|犯罪', 'PC,PS5,XSX', 97, 198, 0, 'Rockstar North', 'Rockstar Games', '洛圣都的三个人，一台接一台的荒诞剧。'],
    ['塞尔达传说：旷野之息', 'The Legend of Zelda: Breath of the Wild', 2017, '探索|解谜', 'NS', 97, 398, 0, '任天堂企划制作本部', '任天堂', '看得到那座山就能走过去，自由的定义。'],
    ['塞尔达传说：王国之泪', 'The Legend of Zelda: Tears of the Kingdom', 2023, '探索|建造', 'NS', 96, 438, 10, '任天堂企划制作本部', '任天堂', '究极手一开，物理规则由你重写，连天空都能拆。'],
    ['上古卷轴4：湮灭', 'The Elder Scrolls IV: Oblivion', 2006, '奇幻|经典', 'PC,PS5,XSX', 94, 88, 60, 'Bethesda Game Studios', 'Bethesda Softworks', '湮灭之门开启，当年的开放世界奇迹。'],
    ['辐射：新维加斯', 'Fallout: New Vegas', 2010, '末世|抉择', 'PC,PS5,XSX', 88, 78, 60, 'Obsidian Entertainment', 'Bethesda Softworks', '新维加斯的派系棋局，每个选择都有回音。'],
    ['死亡搁浅', 'Death Stranding', 2019, '末世|送货', 'PC,PS5', 82, 298, 0, '小岛制作', 'Kojima Productions', '在荒原上架设绳结，走路也是一种玩法。'],
    ['看门狗2', 'Watch Dogs 2', 2016, '黑客|都市', 'PC,PS4,XSX', 82, 198, 0, 'Ubisoft Montreal', '育碧', '用手机黑进整座旧金山，青春又叛逆。'],
    ['看门狗：军团', 'Watch Dogs: Legion', 2020, '黑客|都市', 'PC,PS5,XSX', 74, 298, 70, 'Ubisoft Toronto', '育碧', '招募全城任何人当特工，想法比执行更大胆。'],
    ['孤岛惊魂5', 'Far Cry 5', 2018, '末世|射击', 'PC,PS4,XSX', 78, 198, 0, 'Ubisoft Montreal', '育碧', '蒙大拿的邪教小镇，随时被直升机追着跑。'],
    ['孤岛惊魂6', 'Far Cry 6', 2021, '革命|射击', 'PC,PS5,XSX', 76, 298, 0, 'Ubisoft Toronto', '育碧', '热带岛国的游击战，武器全靠自己拼。'],
    ['幽灵行动：荒野', 'Ghost Recon Wildlands', 2017, '战术|开放世界', 'PC,PS4,XSX', 76, 198, 60, 'Ubisoft Paris', '育碧', '玻利维亚的毒枭战争，四人小队随便打。'],
    ['极限竞速：地平线5', 'Forza Horizon 5', 2021, '竞速|开放世界', 'PC,XSX', 92, 298, 0, 'Playground Games', 'Xbox 游戏工作室', '墨西哥的公路与沙丘，开车就像度假。'],
    ['正当防卫4', 'Just Cause 4', 2018, '爆炸|沙盒', 'PC,PS4,XSX', 68, 198, 0, 'Avalanche Studios', '史克威尔艾尼克斯', '钩爪加滑翔衣，破坏就是全部乐趣。'],
    ['塞尔达传说：风之杖', 'The Legend of Zelda: The Wind Waker', 2002, '海上|卡通', 'NS', 96, 328, 0, '任天堂情报开发本部', '任天堂', '乘船横渡大海，卡通渲染的浪漫，海风一直吹到结尾。'],
    ['上古卷轴3：晨风', 'The Elder Scrolls III: Morrowind', 2002, '奇幻|经典', 'PC', 89, 48, 50, 'Bethesda Game Studios', 'Bethesda Softworks', '灰烬之地的异乡人，硬核又迷人，任务全靠自己找。'],
    ['辐射3', 'Fallout 3', 2008, '末世|经典', 'PC,PS5,XSX', 90, 68, 60, 'Bethesda Game Studios', 'Bethesda Softworks', '走出避难所 101 的那一刻，世界观被打开。'],
    ['潜行者2：切尔诺贝利之心', 'S.T.A.L.K.E.R. 2: Heart of Chornobyl', 2024, '末世|射击', 'PC,XSX', 73, 268, 0, 'GSC Game World', 'GSC Game World', '变异区的枪火与辐射，硬派到骨子里。'],
    ['地铁：离去', 'Metro Exodus', 2019, '末世|射击', 'PC,PS4,PS5,XSX', 84, 198, 60, '4A Games', 'Deep Silver', '乘着火车穿越俄罗斯荒原，寻找能呼吸的地方。'],
    ['地铁2033 重制版', 'Metro 2033 Redux', 2014, '末世|射击', 'PC,PS4,NS', 85, 68, 0, '4A Games', 'Deep Silver', '莫斯科地铁里的最后人类，连氧气都要数着用。'],
    ['地铁：最后的曙光 重制版', 'Metro: Last Light Redux', 2014, '末世|射击', 'PC,PS4,NS', 84, 68, 0, '4A Games', 'Deep Silver', '地表毒气弥漫，地下派系互相厮杀。'],
    ['无人深空', "No Man's Sky", 2016, '太空|探索', 'PC,PS5,XSX', 78, 198, 50, 'Hello Games', 'Hello Games', '十八京颗星球，一个人也能逛很久。'],
    ['星际拓荒', 'Outer Wilds', 2019, '太空|解谜', 'PC,PS5,XSX,NS', 92, 108, 30, 'Mobius Digital', 'Annapurna Interactive', '二十二分钟一轮的太阳系，靠好奇心破局。'],
    ['塞尔达传说：御天之剑 HD', 'The Legend of Zelda: Skyward Sword HD', 2021, '天空|解谜', 'NS', 88, 328, 0, 'Tantalus Media', '任天堂', '云中岛屿的起点，系列时间线的源头。'],
    ['侠盗猎车手4', 'Grand Theft Auto IV', 2008, '都市|犯罪', 'PC', 95, 98, 0, 'Rockstar North', 'Rockstar Games', '自由城的移民梦，黑色幽默的都市史诗。'],
    ['黑手党：最终版', 'Mafia: Definitive Edition', 2020, '黑帮|剧情', 'PC,PS4,XSX', 79, 158, 0, 'Hangar 13', '2K Games', '三十年代的黑帮故事，重制得相当体面。'],
    ['黑手党3', 'Mafia III', 2016, '黑帮|复仇', 'PC,PS4,XSX', 68, 158, 70, 'Hangar 13', '2K Games', '新波尔多的复仇之路，气氛比玩法更强。'],
    ['热血无赖', 'Sleeping Dogs', 2012, '香港|犯罪', 'PC,PS4,XSX', 84, 88, 0, 'United Front Games', '史克威尔艾尼克斯', '香港街头的卧底警察，近身格斗干脆利落。'],
    ['刺客信条：幻景', "Assassin's Creed Mirage", 2023, '潜行|巴格达', 'PC,PS5,XSX', 76, 348, 40, 'Ubisoft Bordeaux', '育碧', '回归潜行与跑酷，巴格达的一千零一夜。'],
    ['刺客信条：大革命', "Assassin's Creed Unity", 2014, '巴黎|潜行', 'PC,PS4,XSX', 71, 128, 0, 'Ubisoft Montreal', '育碧', '巴黎屋顶上的跑酷，画面当年惊艳全城。'],
    ['孤岛惊魂3', 'Far Cry 3', 2012, '岛屿|射击', 'PC,PS4,XSX', 89, 98, 0, 'Ubisoft Montreal', '育碧', '疯癫反派与一座吃人的岛，系列巅峰之一。'],
    ['极限竞速：地平线4', 'Forza Horizon 4', 2018, '竞速|开放世界', 'PC,XSX', 92, 198, 0, 'Playground Games', 'Xbox 游戏工作室', '英国的四季轮转，雨雪都会影响抓地。'],
    ['腐烂国度2', 'State of Decay 2', 2018, '丧尸|生存', 'PC,XSX', 74, 128, 0, 'Undead Labs', 'Xbox 游戏工作室', '管理幸存者社区，人死了就真的没了。'],
    ['深海迷航', 'Subnautica', 2018, '海洋|生存', 'PC,PS5,XSX,NS', 89, 138, 0, 'Unknown Worlds Entertainment', 'Unknown Worlds Entertainment', '坠落在一颗全是海的外星，潜艇就是你的家。'],
    ['深海迷航：冰点之下', 'Subnautica: Below Zero', 2021, '海洋|生存', 'PC,PS5,XSX,NS', 79, 138, 0, 'Unknown Worlds Entertainment', 'Unknown Worlds Entertainment', '极寒海域的新故事，冷得更加孤独。']
  ]);

  /* ── 第一人称射击 ──────────────────────────────────────────── */
  G('第一人称射击', [
    ['毁灭战士：永恒', 'DOOM Eternal', 2020, '快节奏|恶魔', 'PC,PS5,XSX,NS', 90, 198, 0, 'id Software', '贝塞斯达软件', '把恶魔撕开再撕开，重金属节奏的射击。'],
    ['毁灭战士', 'DOOM', 2016, '快节奏|重启', 'PC,PS4,XSX,NS', 89, 128, 60, 'id Software', '贝塞斯达软件', '不换弹不找掩体，往前冲才是活路。'],
    ['半条命2', 'Half-Life 2', 2004, '科幻|经典', 'PC', 96, 18, 40, 'Valve', 'Valve', '十七号城市的反抗，物理引擎改变了一个时代。'],
    ['半条命', 'Half-Life', 1998, '科幻|经典', 'PC', 94, 18, 30, 'Valve', 'Valve', '黑山基地的那场事故，叙事从此进入第一人称。'],
    ['半条命：爱莉克斯', 'Half-Life: Alyx', 2020, '科幻|VR', 'PC', 93, 198, 0, 'Valve', 'Valve', 'VR 里换弹夹都要动手，恐怖感成倍放大。'],
    ['生化奇兵', 'BioShock', 2007, '海底|反乌托邦', 'PC,PS4,NS', 94, 68, 0, 'Irrational Games', '2K Games', '销魂城的海底乌托邦，质体与扳手同样致命。'],
    ['生化奇兵：无限', 'BioShock Infinite', 2013, '天空|剧情', 'PC,PS4,NS', 92, 88, 0, 'Irrational Games', '2K Games', '哥伦比亚的天空之城，结尾让人回头重看一遍。'],
    ['德军总部：新秩序', 'Wolfenstein: The New Order', 2014, '架空历史|纳粹', 'PC,PS4,XSX', 86, 98, 0, 'MachineGames', '贝塞斯达软件', '架空 1960 年代，双持武器砸进纳粹堡垒。'],
    ['德军总部2：新巨像', 'Wolfenstein II: The New Colossus', 2017, '架空历史|反抗', 'PC,PS4,XSX,NS', 85, 128, 0, 'MachineGames', '贝塞斯达软件', '在美国本土打巷战，剧情比枪法更疯。'],
    ['泰坦陨落2', 'Titanfall 2', 2016, '机甲|跑墙', 'PC,PS4,XSX', 89, 128, 0, 'Respawn Entertainment', '艺电', '跑墙滑铲加机甲，单人战役短而惊艳。'],
    ['光环：士官长合集', 'Halo: The Master Chief Collection', 2019, '太空|经典', 'PC,XSX', 91, 198, 50, '343 Industries', 'Xbox 游戏工作室', '六部战役一次收齐，士官长的完整编年史。'],
    ['光环：无限', 'Halo Infinite', 2021, '太空|开放区域', 'PC,XSX', 82, 298, 0, '343 Industries', 'Xbox 游戏工作室', '抓钩带来的自由，环带上的一次重启。'],
    ['孤岛危机', 'Crysis', 2007, '纳米服|丛林', 'PC,PS4,XSX,NS', 88, 68, 60, 'Crytek', '艺电', '纳米服切换隐身与护甲，当年的显卡杀手。'],
    ['孤岛危机3', 'Crysis 3', 2013, '纳米服|都市废墟', 'PC,PS4,XSX', 84, 98, 0, 'Crytek', '艺电', '纽约变雨林，弓与纳米服组合作战。'],
    ['掠食', 'Prey', 2017, '太空站|拟态', 'PC,PS4,XSX', 88, 128, 0, 'Arkane Studios', '贝塞斯达软件', '空间站里什么都可能是外星生物，包括杯子。'],
    ['羞辱', 'Dishonored', 2012, '潜行|蒸汽朋克', 'PC,PS4,XSX', 91, 68, 60, 'Arkane Studios', '贝塞斯达软件', '瞬移与暗杀，一关能玩出十种解法。'],
    ['羞辱2', 'Dishonored 2', 2016, '潜行|蒸汽朋克', 'PC,PS4,XSX', 90, 128, 0, 'Arkane Studios', '贝塞斯达软件', '双主角双技能树，机关宅邸那关值得单看。'],
    ['死亡循环', 'Deathloop', 2021, '时间循环|潜入', 'PC,PS5', 84, 198, 60, 'Arkane Lyon', '贝塞斯达软件', '同一天循环到完美，把八个目标一次清完。'],
    ['原子之心', 'Atomic Heart', 2023, '苏联|机器人', 'PC,PS5,XSX', 78, 248, 0, 'Mundfish', 'Focus Entertainment', '苏联科幻的机器乐园，美术风格相当抢眼。'],
    ['英雄萨姆4', 'Serious Sam 4', 2020, '割草|幽默', 'PC,PS5,XSX', 74, 128, 0, 'Croteam', 'Devolver Digital', '成千上万的怪物冲过来，笑着扣扳机。'],
    ['影子武士3', 'Shadow Warrior 3', 2022, '恶魔|跑酷', 'PC,PS5,XSX', 74, 128, 0, 'Flying Wild Hog', 'Devolver Digital', '钩爪与处决连成一条流畅的杀戮线。'],
    ['黄昏', 'DUSK', 2018, '复古|邪典', 'PC,NS', 88, 68, 0, 'David Szymanski', 'New Blood Interactive', '九十年代射击的骨血，节奏快得像鼓点。'],
    ['邪恶之中', 'Amid Evil', 2019, '复古|奇幻', 'PC', 85, 68, 0, 'Indefatigable', 'New Blood Interactive', '复古画面配奇幻关卡，武器各有一段脑洞。'],
    ['离子狂怒', 'Ion Fury', 2019, '复古|赛博', 'PC,PS4,XSX,NS', 84, 68, 0, 'Voidpoint', '3D Realms', '用老引擎做出新关卡，射击手感扎实。'],
    ['极限杀戮', 'ULTRAKILL', 2020, '复古|高速', 'PC', 92, 78, 20, 'Arsi "Hakita" Patala', 'New Blood Interactive', '血是弹药，速度是信仰，连段评分很上头。'],
    ['战锤40K：爆弹枪', 'Warhammer 40,000: Boltgun', 2023, '复古|战锤', 'PC,PS5,XSX,NS', 79, 108, 0, 'Auroch Digital', 'Focus Entertainment', '星际战士端着爆弹枪，横扫复古像素战场。'],
    ['机械战警：暴戾都市', 'RoboCop: Rogue City', 2023, '复古|警匪', 'PC,PS5,XSX', 76, 198, 0, 'Teyon', 'NACON', '沉重的脚步与散弹枪，九十年代动作片质感。'],
    ['无主之地3', 'Borderlands 3', 2019, '刷枪|卡通', 'PC,PS5,XSX', 82, 198, 0, 'Gearbox Software', '2K Games', '十亿把枪和满屏卡通血花，和朋友一起更疯。'],
    ['无主之地2', 'Borderlands 2', 2012, '刷枪|幽默', 'PC,PS4,XSX,NS', 89, 98, 0, 'Gearbox Software', '2K Games', '帅杰克是系列最好的反派，刷枪也最舒服。'],
    ['使命召唤4：现代战争', 'Call of Duty 4: Modern Warfare', 2007, '现代战争|经典', 'PC,PS4,XSX', 92, 98, 0, 'Infinity Ward', '动视', '狙击关卡与核爆那一幕，定义了一代射击。'],
    ['使命召唤：现代战争', 'Call of Duty: Modern Warfare', 2019, '现代战争|重启', 'PC,PS4,XSX', 82, 298, 0, 'Infinity Ward', '动视', '夜战与清房做得极细，战役压迫感很强。'],
    ['荣誉勋章', 'Medal of Honor', 2010, '阿富汗|军事', 'PC,PS4', 72, 88, 0, 'Danger Close Games', '艺电', '山地战与小队协同，当年的写实派尝试。'],
    ['狙击精英4', 'Sniper Elite 4', 2017, '狙击|二战', 'PC,PS4,XSX', 84, 128, 0, 'Rebellion Developments', 'Rebellion Developments', '子弹飞行视角的 X 光击杀，潜行狙击的乐趣。'],
    ['战地：叛逆连队2', 'Battlefield: Bad Company 2', 2010, '战场|破坏', 'PC,PS4', 88, 98, 0, 'EA DICE', '艺电', '能拆掉整栋房子的战场，战役也够热闹。']
  ]);

  /* ── 角色扮演 ──────────────────────────────────────────────── */
  G('角色扮演', [
    ['博德之门3', "Baldur's Gate 3", 2023, '跑团|高自由度', 'PC,PS5,XSX', 96, 298, 0, 'Larian Studios', '拉瑞安工作室', '掷骰、对话、救人或者不救，选择多得惊人。'],
    ['神界：原罪2', 'Divinity: Original Sin 2', 2017, '回合制|元素互动', 'PC,PS5,XSX,NS', 93, 128, 60, 'Larian Studios', '拉瑞安工作室', '把油泼上去再点火，战斗解法全靠脑洞。'],
    ['极乐迪斯科', 'Disco Elysium', 2019, '侦探|文本', 'PC,PS5,XSX,NS', 91, 108, 40, 'ZA/UM', 'ZA/UM', '失忆警探与脑内二十四种人格吵架，文本惊人。'],
    ['天外世界', 'The Outer Worlds', 2019, '太空|讽刺', 'PC,PS5,XSX,NS', 83, 198, 0, 'Obsidian Entertainment', 'Private Division', '企业统治的殖民星球，嘴炮和子弹都能通关。'],
    ['星空', 'Starfield', 2023, '太空|探索', 'PC,XSX', 78, 298, 0, 'Bethesda Game Studios', '贝塞斯达软件', '上千颗星球与一艘自己的飞船，慢慢逛。'],
    ['质量效应 传奇版', 'Mass Effect Legendary Edition', 2021, '太空歌剧|队友', 'PC,PS4,XSX', 91, 248, 0, 'BioWare', '艺电', '三部曲连成一条线，队友比星舰更难忘。'],
    ['龙腾世纪：审判', 'Dragon Age: Inquisition', 2014, '奇幻|队友', 'PC,PS4,XSX', 85, 198, 0, 'BioWare', '艺电', '审判官整顿大陆，战术视角与长线剧情。'],
    ['永恒之柱2：死火', 'Pillars of Eternity II: Deadfire', 2018, 'CRPG|航海', 'PC,PS4,XSX,NS', 88, 128, 0, 'Obsidian Entertainment', 'Versus Evil', '驾船追一位海盗神，文本密度极高。'],
    ['暴君', 'Tyranny', 2016, 'CRPG|反派', 'PC,PS4,NS', 84, 98, 0, 'Obsidian Entertainment', 'Paradox Interactive', '开局邪恶已经赢了，你在暴政里做官。'],
    ['废土3', 'Wasteland 3', 2020, '末世|小队', 'PC,PS4,XSX', 84, 158, 0, 'inXile Entertainment', 'Deep Silver', '雪原游骑兵的小队战术，黑色幽默管够。'],
    ['开拓者：正义之怒', 'Pathfinder: Wrath of the Righteous', 2021, 'CRPG|神话', 'PC,PS4,XSX', 86, 158, 0, 'Owlcat Games', 'Owlcat Games', '神话道途让角色强到离谱，规则书玩家的盛宴。'],
    ['天国：拯救', 'Kingdom Come: Deliverance', 2018, '中世纪|写实', 'PC,PS4,XSX,NS', 83, 128, 0, 'Warhorse Studios', 'Deep Silver', '一个铁匠儿子的中世纪，连开锁都要练。'],
    ['贪婪之秋', 'GreedFall', 2019, '殖民|奇幻', 'PC,PS5,XSX', 78, 128, 60, 'Spiders', 'Focus Home Interactive', '殖民时代的奇幻岛屿，外交与刀剑并重。'],
    ['骑马与砍杀2：霸主', 'Mount & Blade II: Bannerlord', 2022, '中世纪|统兵', 'PC,PS5,XSX', 86, 248, 30, 'TaleWorlds Entertainment', 'TaleWorlds Entertainment', '从雇佣兵做到国王，千人战场自己冲锋。'],
    ['女神异闻录5 皇家版', 'Persona 5 Royal', 2020, '日式|校园', 'PC,PS5,XSX,NS', 95, 279, 0, 'Atlus', '世嘉', '白天上学晚上偷心，UI 设计漂亮得不像话。'],
    ['女神异闻录4 黄金版', 'Persona 4 Golden', 2020, '日式|悬疑', 'PC,PS5,XSX,NS', 91, 125, 0, 'Atlus', '世嘉', '小镇连续杀人案与青春日常，越玩越舍不得走。'],
    ['女神异闻录3 Reload', 'Persona 3 Reload', 2024, '日式|重制', 'PC,PS5,XSX', 87, 348, 0, 'Atlus', '世嘉', '塔尔塔罗斯的高塔与同伴的告别，重制得很完整。'],
    ['真·女神转生V 复仇', 'Shin Megami Tensei V: Vengeance', 2024, '恶魔|末世', 'PC,PS5,XSX,NS', 86, 348, 0, 'Atlus', '世嘉', '收集恶魔合成队伍，东京废墟里的神魔战争。'],
    ['异度神剑3', 'Xenoblade Chronicles 3', 2022, '日式|群像', 'NS', 89, 398, 20, 'Monolith Soft', '任天堂', '六个士兵逃离永恒的战争，地图大到奢侈。'],
    ['异度神剑2', 'Xenoblade Chronicles 2', 2017, '日式|巨神兽', 'NS', 83, 398, 20, 'Monolith Soft', '任天堂', '在巨神兽背上旅行，系统复杂但很甜。'],
    ['异度神剑 终极版', 'Xenoblade Chronicles: Definitive Edition', 2020, '日式|复仇', 'NS', 89, 358, 0, 'Monolith Soft', '任天堂', '巨神残骸上的复仇之旅，音乐足以单听。'],
    ['八方旅人2', 'Octopath Traveler II', 2023, 'HD-2D|群像', 'PC,PS5,XSX,NS', 86, 398, 30, 'Acquire', '史克威尔艾尼克斯', '八个旅人各自出发，HD-2D 画面细腻到犯规。'],
    ['八方旅人', 'Octopath Traveler', 2018, 'HD-2D|回合', 'PC,PS4,XSX,NS', 83, 298, 0, 'Acquire', '史克威尔艾尼克斯', '八条线八种活法，职业搭配很有嚼头。'],
    ['破晓传说', 'Tales of Arise', 2021, '日式|动作', 'PC,PS5,XSX', 85, 298, 60, 'Bandai Namco Studios', '万代南梦宫', '两个世界的对立，战斗演出华丽流畅。'],
    ['狂战传说', 'Tales of Berseria', 2016, '日式|复仇', 'PC,PS4', 84, 198, 0, 'Bandai Namco Studios', '万代南梦宫', '系列最野的女主角，复仇故事写得很痛快。'],
    ['二之国2：亡灵之国', 'Ni no Kuni II: Revenant Kingdom', 2018, '吉卜力|王国', 'PC,PS4,NS', 84, 198, 0, 'Level-5', '万代南梦宫', '建王国、打怪物，吉卜力风格的温柔世界。'],
    ['如龙7 光与暗的去向', 'Yakuza: Like a Dragon', 2020, '黑道|回合', 'PC,PS5,XSX', 88, 268, 0, 'Ryu Ga Gotoku Studio', '世嘉', '黑道中年转行当勇者，回合制打得又燃又好笑。'],
    ['如龙8', 'Like a Dragon: Infinite Wealth', 2024, '黑道|夏威夷', 'PC,PS5,XSX', 91, 398, 0, 'Ryu Ga Gotoku Studio', '世嘉', '横跨夏威夷的寻亲之旅，支线荒唐到极致。'],
    ['最终幻想9', 'Final Fantasy IX', 2000, '日式|经典', 'PC,PS4,NS', 94, 108, 0, 'Square', '史克威尔艾尼克斯', '回归水晶与童话，系列最温柔的一作。'],
    ['最终幻想10/10-2 高清重制版', 'Final Fantasy X/X-2 HD Remaster', 2016, '日式|剧情', 'PC,PS4,NS', 91, 168, 0, 'Square Enix', '史克威尔艾尼克斯', '斯菲尔与祈之子，结局让一代人记住。'],
    ['最终幻想12：黄道纪元', 'Final Fantasy XII: The Zodiac Age', 2017, '日式|政治', 'PC,PS4,NS', 88, 198, 50, 'Square Enix', '史克威尔艾尼克斯', '伊瓦利斯的政治博弈，战术布局系统耐玩。'],
    ['时空之轮', 'Chrono Trigger', 2018, '经典|时间旅行', 'PC', 96, 78, 40, 'Square', '史克威尔艾尼克斯', '时间旅行与多重结局，九十年代 JRPG 的顶点。'],
    ['星之海', 'Sea of Stars', 2023, '像素|回合', 'PC,PS5,XSX,NS', 87, 128, 0, 'Sabotage Studio', 'Sabotage Studio', '致敬经典的像素回合制，日月之力玩得漂亮。'],
    ['锁链回声', 'Chained Echoes', 2022, '像素|机甲', 'PC,PS5,XSX,NS', 85, 98, 40, 'Matthias Linda', 'Deck13', '一个人做的 JRPG，机甲与飞空艇都有。'],
    ['交叉准则', 'CrossCode', 2018, '像素|解谜', 'PC,PS4,XSX,NS', 86, 78, 0, 'Radical Fish Games', 'Deck13', '网游世界里的失忆少女，解谜与战斗都快。'],
    ['传说之下', 'Undertale', 2015, '像素|慈悲', 'PC,PS4,NS', 93, 36, 0, 'Toby Fox', 'Toby Fox', '你可以不杀任何一个怪物，结局会记得。'],
    ['符文工房4 特别版', 'Rune Factory 4 Special', 2020, '田园|冒险', 'PC,NS,PS4', 84, 168, 40, 'Marvelous', 'Marvelous', '种田、恋爱、打怪三件套，一天就过去了。'],
    ['莱莎的炼金工房2', 'Atelier Ryza 2: Lost Legends & the Secret Fairy', 2021, '炼金|夏日', 'PC,PS5,NS', 80, 298, 0, 'Gust', '光荣特库摩', '调和系统越玩越深，夏天的氛围拉满。']
  ]);

  /* ── 策略 ──────────────────────────────────────────────────── */
  G('策略', [
    ['文明6', 'Sid Meier\'s Civilization VI', 2016, '回合制|历史', 'PC,PS5,XSX,NS', 88, 199, 60, 'Firaxis Games', '2K Games', '再来一回合，然后天就亮了，历史上瘾性最强的一句。'],
    ['文明5', 'Sid Meier\'s Civilization V', 2010, '回合制|历史', 'PC', 90, 128, 60, 'Firaxis Games', '2K Games', '六边形地块与城邦外交，很多人的入门作。'],
    ['全面战争：三国', 'Total War: Three Kingdoms', 2019, '三国|大地图', 'PC', 86, 268, 0, 'Creative Assembly', '世嘉', '三国演义的势力棋局，带兵冲阵最爽。'],
    ['全面战争：战锤3', 'Total War: Warhammer III', 2022, '奇幻|战锤', 'PC', 82, 298, 0, 'Creative Assembly', '世嘉', '魔法与巨兽的战场，混沌军团压境。'],
    ['全面战争：幕府将军2', 'Total War: Shogun 2', 2011, '战国|经典', 'PC', 90, 98, 0, 'Creative Assembly', '世嘉', '日本战国的内政与合战，系列口碑巅峰。'],
    ['帝国时代4', 'Age of Empires IV', 2021, '即时|历史', 'PC,XSX', 83, 198, 50, 'Relic Entertainment', 'Xbox 游戏工作室', '中世纪到文艺复兴的即时战略，战役拍得像纪录片。'],
    ['帝国时代2 决定版', 'Age of Empires II: Definitive Edition', 2019, '即时|经典', 'PC,XSX', 89, 98, 0, 'Forgotten Empires', 'Xbox 游戏工作室', '二十年不过时的即时战略，资料片还在加。'],
    ['星际争霸2', 'StarCraft II', 2010, '即时|科幻', 'PC', 93, 0, 0, 'Blizzard Entertainment', '暴雪娱乐', '三个种族的战役与天梯，即时战略的标杆。'],
    ['英雄连3', 'Company of Heroes 3', 2023, '二战|战术', 'PC,PS5,XSX', 74, 298, 0, 'Relic Entertainment', '世嘉', '意大利与北非战场，掩体和压制做得细。'],
    ['XCOM 2', 'XCOM 2', 2016, '战棋|外星', 'PC,PS4,XSX,NS', 90, 158, 60, 'Firaxis Games', '2K Games', '每次射击都心惊，士兵死了不能读档。'],
    ['XCOM：未知敌人', 'XCOM: Enemy Unknown', 2012, '战棋|外星', 'PC,PS4', 88, 98, 60, 'Firaxis Games', '2K Games', '重建 XCOM 总部，回合制战术的现代化。'],
    ['陷阵之志', 'Into the Breach', 2018, '战棋|时间循环', 'PC,NS', 90, 68, 0, 'Subset Games', 'Subset Games', '棋盘上每一步都算得清，死了立刻重来。'],
    ['冰汽时代', 'Frostpunk', 2018, '末世|抉择', 'PC,PS4,XSX', 87, 128, 60, '11 bit studios', '11 bit studios', '零下四十度的城市，道德与锅炉一样烫手。'],
    ['冰汽时代2', 'Frostpunk 2', 2024, '末世|政治', 'PC,PS5,XSX', 80, 248, 0, '11 bit studios', '11 bit studios', '从管暖气到管议会，社会撕裂比寒冬更难。'],
    ['十字军之王3', 'Crusader Kings III', 2020, '中世纪|家族', 'PC,PS5,XSX', 91, 218, 0, 'Paradox Development Studio', 'Paradox Interactive', '结婚、密谋、继承，把家族经营成一部荡妇史。'],
    ['欧陆风云4', 'Europa Universalis IV', 2013, '大战略|历史', 'PC', 87, 198, 0, 'Paradox Development Studio', 'Paradox Interactive', '从 1444 年改写地图，外交比战争更难。'],
    ['群星', 'Stellaris', 2016, '大战略|太空', 'PC,PS5,XSX', 85, 218, 0, 'Paradox Development Studio', 'Paradox Interactive', '自定义种族走出母星，宇宙里什么都不缺。'],
    ['钢铁雄心4', 'Hearts of Iron IV', 2016, '二战|大战略', 'PC', 84, 218, 60, 'Paradox Development Studio', 'Paradox Interactive', '从工厂到前线，二战棋盘任你重排。'],
    ['环世界', 'RimWorld', 2018, '生存|故事生成', 'PC,PS4,PS5', 94, 158, 40, 'Ludeon Studios', 'Ludeon Studios', '三个人的殖民地，AI 会替你编出惨烈故事。'],
    ['缺氧', 'Oxygen Not Included', 2019, '资源|物理', 'PC', 89, 98, 50, 'Klei Entertainment', 'Klei Entertainment', '地下殖民地的氧气、热量与管道，全靠算。'],
    ['异星工厂', 'Factorio', 2020, '自动化|生产线', 'PC,NS', 96, 220, 0, 'Wube Software', 'Wube Software', '把一颗星球改造成传送带，然后继续扩建。'],
    ['城市：天际线', 'Cities: Skylines', 2015, '城建|交通', 'PC,PS5,XSX,NS', 87, 138, 60, 'Colossal Order', 'Paradox Interactive', '修一座城市，最后堵在立交桥上，交通是永恒难题。'],
    ['城市：天际线II', 'Cities: Skylines II', 2023, '城建|模拟', 'PC,PS5,XSX', 72, 248, 0, 'Colossal Order', 'Paradox Interactive', '新引擎的城市模拟，规模更大也更能堵。'],
    ['纪元1800', 'Anno 1800', 2019, '经营|工业革命', 'PC,PS5,XSX', 86, 218, 0, 'Ubisoft Blue Byte', '育碧', '工业革命的海岛贸易链，港口一堵全线停摆。'],
    ['火星求生', 'Surviving Mars', 2019, '太空|殖民', 'PC,PS4,XSX', 81, 128, 60, 'Haemimont Games', 'Paradox Interactive', '在火星上种下第一棵植物，然后祈祷别断电。'],
    ['亿万僵尸', 'They Are Billions', 2019, '丧尸|塔防', 'PC,PS4,XSX', 79, 88, 0, 'Numantian Games', 'Numantian Games', '建好城墙再看尸潮压过来，压力拉满。'],
    ['庄园领主', 'Manor Lords', 2024, '中世纪|城建', 'PC', 80, 158, 30, 'Slavic Magic', 'Hooded Horse', '一个人做的中世纪城建，村庄会自己长出来。'],
    ['北境之地', 'Northgard', 2018, '维京|即时', 'PC,PS4,XSX,NS', 81, 128, 50, 'Shiro Games', 'Shiro Games', '维京人的四季与领地，节奏比传统 RTS 慢。'],
    ['无尽传奇', 'Endless Legend', 2014, '奇幻|回合', 'PC', 83, 98, 60, 'Amplitude Studios', '世嘉', '分裂大陆上的奇幻文明，每个种族玩法不同。']
  ]);

  /* ── 模拟经营 ──────────────────────────────────────────────── */
  G('模拟经营', [
    ['星露谷物语', 'Stardew Valley', 2016, '农场|治愈', 'PC,PS4,XSX,NS', 94, 48, 0, 'ConcernedApe', 'ConcernedApe', '继承一座破农场，然后被村民的故事留住。'],
    ['集合啦！动物森友会', 'Animal Crossing: New Horizons', 2020, '岛屿|生活', 'NS', 92, 398, 20, '任天堂情报开发本部', '任天堂', '在无人岛上盖房子钓鱼，日子过得很慢。'],
    ['模拟农场22', 'Farming Simulator 22', 2021, '农机|写实', 'PC,PS5,XSX', 79, 218, 0, 'Giants Software', 'Giants Software', '开收割机收一整天麦子，比想象中解压。'],
    ['模拟人生4', 'The Sims 4', 2014, '人生|建造', 'PC,PS5,XSX', 82, 0, 0, 'Maxis', '艺电', '捏人、盖房、看他们吵架，免费本体也能玩很久。'],
    ['过山车之星', 'Planet Coaster', 2016, '乐园|建造', 'PC,PS5,XSX', 86, 158, 0, 'Frontier Developments', 'Frontier Developments', '自己画过山车轨道，然后看游客脸色。'],
    ['动物园之星', 'Planet Zoo', 2019, '动物|建造', 'PC,PS5,XSX', 87, 218, 0, 'Frontier Developments', 'Frontier Developments', '给雪豹造一座山，游客满意度全看细节。'],
    ['侏罗纪世界：进化2', 'Jurassic World Evolution 2', 2021, '恐龙|乐园', 'PC,PS5,XSX', 78, 218, 0, 'Frontier Developments', 'Frontier Developments', '养恐龙开乐园，然后处理逃出来的那几只。'],
    ['微软模拟飞行', 'Microsoft Flight Simulator', 2020, '飞行|拟真', 'PC,XSX', 91, 398, 0, 'Asobo Studio', 'Xbox 游戏工作室', '从自家城市上空飞过，云层和地形都很真实。'],
    ['欧洲卡车模拟2', 'Euro Truck Simulator 2', 2013, '卡车|公路', 'PC', 91, 88, 0, 'SCS Software', 'SCS Software', '开着卡车横穿欧洲，电台比目的地重要。'],
    ['美国卡车模拟', 'American Truck Simulator', 2016, '卡车|公路', 'PC', 86, 88, 0, 'SCS Software', 'SCS Software', '美国西部的长直公路，一箱货一段旅程。'],
    ['房产达人', 'House Flipper', 2018, '装修|清洁', 'PC,PS4,XSX,NS', 79, 88, 0, 'Empyrean', 'Frozen District', '把脏房子打扫干净再卖掉，满足感很直接。'],
    ['冲就完事模拟器', 'PowerWash Simulator', 2022, '清洁|解压', 'PC,PS5,XSX,NS', 86, 108, 0, 'FuturLab', 'Square Enix Collective', '高压水枪冲掉每一块污渍，纯粹的放松。'],
    ['料理模拟器', 'Cooking Simulator', 2019, '料理|物理', 'PC,PS4,XSX,NS', 72, 68, 0, 'Big Cheese Studio', 'PlayWay', '厨房里的物理乱飞，煎糊了也能端上桌。'],
    ['波西亚时光', 'My Time at Portia', 2019, '工坊|小镇', 'PC,PS4,XSX,NS', 80, 98, 50, 'Pathea Games', 'Team17', '继承一间工坊，在废土小镇接单造东西。'],
    ['沙石镇时光', 'My Time at Sandrock', 2023, '工坊|沙漠', 'PC,PS5,XSX,NS', 82, 128, 0, 'Pathea Games', 'Pathea Games', '沙漠小镇的重建计划，比前作更从容。'],
    ['珊瑚岛', 'Coral Island', 2023, '海岛|农场', 'PC,PS5,XSX', 79, 138, 0, 'Stairway Games', 'Humble Games', '热带海岛的农场生活，还能潜水种珊瑚。'],
    ['潜水员戴夫', 'Dave the Diver', 2023, '潜水|寿司', 'PC,PS5,NS', 88, 108, 0, 'Mintrocket', 'Mintrocket', '白天潜水捕鱼，晚上端盘子，节奏很魔性。'],
    ['灵魂旅人', 'Spiritfarer', 2020, '告别|手绘', 'PC,PS4,XSX,NS', 87, 118, 0, 'Thunder Lotus Games', 'Thunder Lotus Games', '摆渡灵魂的船，温柔地讲离别这件事。'],
    ['史莱姆牧场', 'Slime Rancher', 2017, '史莱姆|牧场', 'PC,PS4,XSX,NS', 84, 78, 50, 'Monomi Park', 'Monomi Park', '吸起一坨史莱姆，养在围栏里看它们蹦。'],
    ['史莱姆牧场2', 'Slime Rancher 2', 2022, '史莱姆|探索', 'PC,XSX', 80, 128, 0, 'Monomi Park', 'Monomi Park', '彩虹岛上的新牧场，画面亮得晃眼。'],
    ['医院计划', 'Project Hospital', 2018, '医院|管理', 'PC', 80, 88, 0, 'Oxymoron Games', 'Oxymoron Games', '亲手设计一座医院，连走廊宽度都要算。'],
    ['运输狂热2', 'Transport Fever 2', 2019, '交通|物流', 'PC', 82, 128, 50, 'Urban Games', 'Good Shepherd', '从马车到高铁，把整片大陆连成网络。'],
    ['超市模拟器', 'Supermarket Simulator', 2024, '超市|经营', 'PC', 74, 78, 0, 'Nokta Games', 'Nokta Games', '进货、定价、收银，一个人撑起一间超市。'],
    ['太阳港', 'Sun Haven', 2023, '农场|魔法', 'PC', 78, 98, 40, 'Pixel Sprout Studios', 'Pixel Sprout Studios', '种田之外还有魔法与三条恋爱线，一天过得很满。'],
    ['旅人酒馆', 'Travellers Rest', 2023, '酒馆|酿造', 'PC', 79, 78, 0, 'Isolated Games', 'Isolated Games', '自己酿酒、招呼客人，慢慢把酒馆开大。'],
    ['双点医院', 'Two Point Hospital', 2018, '医院|幽默', 'PC,PS4,XSX,NS', 85, 198, 60, 'Two Point Studios', '世嘉', '治一些不存在的怪病，英式幽默管够。'],
    ['双点校园', 'Two Point Campus', 2022, '校园|经营', 'PC,PS5,XSX,NS', 80, 198, 0, 'Two Point Studios', '世嘉', '办一所奇怪的大学，课程和食堂都要管。'],
    ['幸福工厂', 'Satisfactory', 2024, '工厂|自动化', 'PC', 91, 158, 20, 'Coffee Stain Studios', 'Coffee Stain Publishing', '在异星铺满传送带，第一人称的工厂梦。'],
    ['卡牌商店模拟器', 'TCG Card Shop Simulator', 2024, '卡牌|店铺', 'PC', 76, 78, 0, 'OPNeon Games', 'OPNeon Games', '开卡包、摆货架，运气也是经营的一部分。'],
    ['加油站大亨', 'Gas Station Simulator', 2021, '加油站|经营', 'PC', 73, 68, 50, 'Drago Entertainment', 'Movie Games', '修一间荒废加油站，从擦地开始翻身。'],
    ['牧场物语：重聚矿石镇', 'Story of Seasons: Friends of Mineral Town', 2020, '牧场|重制', 'PC,PS4,NS', 79, 218, 0, 'Marvelous', 'Marvelous', '矿石镇的经典重制，种地结婚一条龙。'],
    ['符文工房5', 'Rune Factory 5', 2022, '牧场|奇幻', 'PC,NS', 74, 218, 60, 'Hakama', 'Marvelous', '牧场与冒险的结合，还能和怪物做朋友。'],
    ['过山车大亨：乐园', 'Parkitect', 2018, '乐园|建造', 'PC', 84, 98, 0, 'Texel Raptor', 'Texel Raptor', '经营地下通道与员工路径，硬核乐园模拟。']
  ]);

  /* ── 独立 ──────────────────────────────────────────────────── */
  G('独立', [
    ['风之旅人', 'Journey', 2012, '沙漠|无对白', 'PC,PS4', 92, 68, 40, 'thatgamecompany', 'Annapurna Interactive', '走向山顶的一段路，陌生人只能靠鸣叫交流。'],
    ['格莉丝', 'GRIS', 2018, '手绘|悲伤', 'PC,PS5,XSX,NS', 88, 68, 0, 'Nomada Studio', 'Devolver Digital', '没有台词的悲伤，用颜色一层层走出来。'],
    ['囚禁', 'INSIDE', 2016, '反乌托邦|解谜', 'PC,PS4,XSX,NS', 93, 68, 0, 'Playdead', 'Playdead', '一路向右跑，没有一句台词，结局让人不敢细想。'],
    ['地狱边境', 'Limbo', 2010, '黑白|解谜', 'PC,PS4,XSX,NS', 89, 48, 0, 'Playdead', 'Playdead', '黑白剪影的森林，小男孩寻找姐姐。'],
    ['小小梦魇2', 'Little Nightmares II', 2021, '惊悚|解谜', 'PC,PS5,XSX,NS', 85, 148, 0, 'Tarsier Studios', '万代南梦宫', '瘦长身影与电视雪花，全程不敢松手。'],
    ['小小梦魇', 'Little Nightmares', 2017, '惊悚|解谜', 'PC,PS4,XSX,NS', 81, 98, 0, 'Tarsier Studios', '万代南梦宫', '贪食者的大船上，小孩只想着逃出去。'],
    ['艾迪芬奇的记忆', 'What Remains of Edith Finch', 2017, '叙事|家族', 'PC,PS5,XSX,NS', 91, 78, 0, 'Giant Sparrow', 'Annapurna Interactive', '每个家族成员的死法，都是一段不同玩法。'],
    ['看火人', 'Firewatch', 2016, '荒野|对话', 'PC,PS4,XSX,NS', 84, 78, 50, 'Campo Santo', 'Campo Santo', '在怀俄明看一夏天林子，和无线电那头聊天。'],
    ['奥伯拉丁的回归', 'Return of the Obra Dinn', 2018, '推理|黑白', 'PC,PS4,XSX,NS', 91, 78, 40, 'Lucas Pope', '3909 LLC', '靠一块怀表还原整船人的死因，推理纯度极高。'],
    ['请出示文件', 'Papers, Please', 2013, '检查|抉择', 'PC,PS4', 87, 42, 0, 'Lucas Pope', '3909 LLC', '在边境检查护照，盖一个章改变一个家庭。'],
    ['斯坦利的寓言', 'The Stanley Parable', 2013, '元叙事|幽默', 'PC,PS4,XSX', 90, 68, 50, 'Galactic Cafe', 'Galactic Cafe', '旁白一直说，你偏不听，然后世界就乱了。'],
    ['武士零', 'Katana ZERO', 2019, '横版|时间', 'PC,NS', 87, 68, 0, 'Askiisoft', 'Devolver Digital', '一刀一个，还能倒带重来，节奏像电子乐。'],
    ['迈阿密热线', 'Hotline Miami', 2012, '俯视|霓虹', 'PC,PS4,NS', 85, 48, 0, 'Dennaton Games', 'Devolver Digital', '戴着动物面具冲进房间，音乐比子弹更快。'],
    ['迈阿密热线2', 'Hotline Miami 2: Wrong Number', 2015, '俯视|暴力', 'PC,PS4', 82, 48, 0, 'Dennaton Games', 'Devolver Digital', '多线叙事拼出一场血腥的因果，音乐依旧炸裂。'],
    ['短途旅行', 'A Short Hike', 2019, '登山|治愈', 'PC,PS4,XSX,NS', 88, 38, 0, 'Adam Robinson-Yu', 'Adamgryu', '一座小岛，一段不长但很舒服的登山。'],
    ['大鹅模拟器', 'Untitled Goose Game', 2019, '恶作剧|鹅', 'PC,PS4,XSX,NS', 84, 68, 0, 'House House', 'Panic', '当一只讨人厌的鹅，把所有东西叼走。'],
    ['迷失', 'Stray', 2022, '猫|赛博', 'PC,PS5,XSX', 84, 138, 0, 'BlueTwelve Studio', 'Annapurna Interactive', '以猫的视角穿过机器人的城市，喵一声很有用。'],
    ['图尼克', 'Tunic', 2022, '解谜|狐狸', 'PC,PS5,XSX,NS', 86, 148, 40, 'Andrew Shouldice', 'Finji', '说明书本身就是谜题，靠猜也能通关。'],
    ['动物井', 'Animal Well', 2024, '探索|像素', 'PC,PS5,NS', 88, 108, 0, 'Shared Memory', 'Bigmode', '一个人做的像素井底，秘密比地图还多。'],
    ['邪恶冥刻', 'Inscryption', 2021, '卡牌|元叙事', 'PC,PS5,NS', 89, 88, 40, 'Daniel Mullins Games', 'Devolver Digital', '卡牌游戏玩着玩着，桌子对面的人开始说话。'],
    ['咩咩启示录', 'Cult of the Lamb', 2022, '邪教|经营', 'PC,PS5,XSX,NS', 82, 108, 0, 'Massive Monster', 'Devolver Digital', '养一群信徒，再带他们去打别的神。'],
    ['渔帆暗涌', 'DREDGE', 2023, '钓鱼|克苏鲁', 'PC,PS5,XSX,NS', 84, 108, 30, 'Black Salt Games', 'Team17', '白天钓鱼卖钱，夜里海里有东西跟着你。'],
    ['茧', 'COCOON', 2023, '解谜|世界嵌套', 'PC,PS5,XSX,NS', 87, 108, 0, 'Geometric Interactive', 'Annapurna Interactive', '把世界装进球里再带进另一个世界。'],
    ['世外之语', 'Chants of Sennaar', 2023, '语言|解谜', 'PC,PS5,XSX,NS', 86, 118, 30, 'Rundisc', 'Focus Entertainment', '靠猜词义打通各族语言，翻译出来的瞬间很爽。'],
    ['隐迹渐现', 'Pentiment', 2022, '历史|叙事', 'PC,PS5,XSX,NS', 89, 118, 30, 'Obsidian Entertainment', 'Xbox 游戏工作室', '中世纪村庄里的连环命案，插画风像手抄本。'],
    ['诺科', 'NORCO', 2022, '南方哥特|叙事', 'PC,PS5,XSX', 86, 78, 40, 'Geography of Robots', 'Raw Fury', '路易斯安那的炼油厂与失踪的哥哥。'],
    ['肯塔基零号公路', 'Kentucky Route Zero', 2020, '魔幻现实|戏剧', 'PC,PS4,XSX,NS', 87, 78, 0, 'Cardboard Computer', 'Annapurna Interactive', '一条不存在的公路，五幕剧般的叙事。'],
    ['奥森弗里', 'Oxenfree', 2016, '青春|超自然', 'PC,PS4,XSX,NS', 82, 68, 50, 'Night School Studio', 'Night School Studio', '岛上的无线电撕开裂缝，对话要抢时间选。'],
    ['信号', 'SIGNALIS', 2022, '科幻|恐怖', 'PC,PS5,XSX,NS', 86, 108, 30, 'rose-engine', 'Humble Games', '复古像素的太空恐怖，叙事藏在碎片里。'],
    ['公民沉睡者', 'Citizen Sleeper', 2022, '太空站|骰子', 'PC,PS5,XSX,NS', 85, 78, 40, 'Jump Over the Age', 'Fellow Traveller', '用骰子安排每一天，在空间站里活下去。'],
    ['天堂杀手', 'Paradise Killer', 2020, '推理|合成器', 'PC,PS5,XSX,NS', 84, 78, 40, 'Kaizen Game Works', 'Fellow Traveller', '一座岛全是嫌疑人，音乐和美术都很邪。'],
    ['金偶像迷案', 'The Case of the Golden Idol', 2022, '推理|拼图', 'PC,NS', 86, 68, 0, 'Color Gray Games', 'Playstack', '把证词里的词填进空位，真相自己浮出来。'],
    ['她的故事', 'Her Story', 2015, '真人|检索', 'PC', 84, 42, 0, 'Sam Barlow', 'Sam Barlow', '只有一段段审讯录像，靠关键词搜出全貌。'],
    ['不朽', 'Immortality', 2022, '真人|影像', 'PC,XSX', 82, 98, 40, 'Half Mermaid', 'Half Mermaid', '在三部未完成的电影里找出消失的女演员。'],
    ['遗忘之城', 'The Forgotten City', 2021, '时间循环|罗马', 'PC,PS5,XSX,NS', 87, 88, 0, 'Modern Storyteller', 'Dear Villagers', '罗马古城的时间循环，靠对话与推理破局。'],
    ['兄弟：双子传说', 'Brothers: A Tale of Two Sons', 2013, '双人协作|童话', 'PC,PS4,XSX,NS', 85, 48, 50, 'Starbreeze Studios', '505 Games', '一只手控制一个兄弟，结尾的操作很残忍。'],
    ['毛线小精灵', 'Unravel', 2016, '毛线|物理', 'PC,PS4,XSX', 82, 68, 50, 'Coldwood Interactive', '艺电', '一团毛线走遍北欧，画面温柔手感扎实。'],
    ['风来之国', 'Eastward', 2021, '像素|末日', 'PC,NS', 82, 98, 50, 'Pixpil', 'Chucklefish', '手绘像素的末日中国，父女俩一路向东。'],
    ['猫头鹰男孩', 'Owlboy', 2016, '像素|飞行', 'PC,PS4,XSX,NS', 80, 78, 50, 'D-Pad Studio', 'D-Pad Studio', '沉默的猫头鹰男孩，像素美术精细到变态。'],
    ['雨世界', 'Rain World', 2017, '生态|生存', 'PC,PS4,XSX,NS', 80, 68, 0, 'Videocult', 'Adult Swim Games', '食物链中层的生存，掠食者不会等你。'],
    ['女巫', 'Noita', 2020, '像素|法术', 'PC', 88, 78, 40, 'Nolla Games', 'Nolla Games', '每个像素都有物理，法术乱配能把自己炸死。'],
    ['画中世界', 'Gorogoa', 2017, '手绘|拼图', 'PC,PS4,XSX,NS', 87, 48, 0, 'Jason Roberts', 'Annapurna Interactive', '把画面拆开再拼起来，谜题与故事长在一起。'],
    ['疑案追声', 'Unheard', 2019, '声音|推理', 'PC', 80, 38, 40, 'NExT Studios', 'NExT Studios', '只听声音还原案件，在时间轴上反复回放。'],
    ['中国式家长', 'Chinese Parents', 2018, '养成|家庭', 'PC,NS', 78, 38, 0, '墨鱼玩游戏', '墨鱼玩游戏', '从出生养到高考，每一步都像被谁安排过。'],
    ['太吾绘卷', 'The Scroll of Taiwu', 2018, '武侠|世代', 'PC', 82, 68, 0, '螺舟工作室', '螺舟工作室', '武侠世界的世代更替，系统复杂得像论文。'],
    ['鬼谷八荒', 'Tale of Immortal', 2021, '修仙|开放', 'PC', 80, 68, 0, '鬼谷工作室', '鬼谷工作室', '从凡人一路修到化神，路上恩怨不少。'],
    ['戴森球计划', 'Dyson Sphere Program', 2021, '自动化|星际', 'PC', 91, 78, 0, '柚子猫工作室', 'Gamera Games', '把整颗星球的资源铺成产线，再包住恒星。'],
    ['帕斯卡契约', "Pascal's Wager", 2021, '魂类|手游移植', 'PC,NS', 76, 68, 0, 'TipsWorks', '巨人网络', '手机起家的硬核魂系，移植到 PC 后手感尚可。']
  ]);

  /* ── 恐怖生存 ──────────────────────────────────────────────── */
  G('恐怖生存', [
    ['生化危机2 重制版', 'Resident Evil 2', 2019, '丧尸|警局', 'PC,PS5,XSX', 91, 198, 0, 'Capcom', '卡普空', '浣熊市警察局的一夜，暴君的脚步跟着你上楼。'],
    ['生化危机4 重制版', 'Resident Evil 4', 2023, '丧尸|营救', 'PC,PS5,XSX', 92, 298, 30, 'Capcom', '卡普空', '去西班牙村庄救总统女儿，刀与体术都更好用。'],
    ['生化危机7', 'Resident Evil 7: Biohazard', 2017, '第一人称|家庭', 'PC,PS5,XSX', 86, 158, 0, 'Capcom', '卡普空', '第一人称回到路易斯安那的农舍，恐怖感回归。'],
    ['生化危机8：村庄', 'Resident Evil Village', 2021, '第一人称|吸血鬼', 'PC,PS5,XSX', 84, 298, 0, 'Capcom', '卡普空', '为了女儿闯进村庄，四位领主各有各的疯。'],
    ['生化危机3 重制版', 'Resident Evil 3', 2020, '丧尸|逃亡', 'PC,PS5,XSX', 79, 198, 0, 'Capcom', '卡普空', '追迹者一路追，浣熊市的最后几个小时。'],
    ['寂静岭2 重制版', 'Silent Hill 2', 2024, '心理|雾', 'PC,PS5', 87, 348, 0, 'Bloober Team', '科乐美', '收到亡妻的信回到雾中小镇，罪与罚很难分开。'],
    ['死亡空间 重制版', 'Dead Space', 2023, '太空|怪物', 'PC,PS5,XSX', 89, 298, 0, 'Motive Studio', '艺电', '石村号上的尸变体，切割枪比子弹更有效。'],
    ['死亡空间', 'Dead Space', 2008, '太空|经典', 'PC,PS4', 88, 98, 50, 'EA Redwood Shores', '艺电', '太空恐怖的开山之作，UI 全在角色身上。'],
    ['恶灵附身', 'The Evil Within', 2014, '生存|扭曲', 'PC,PS4,XSX', 76, 98, 0, 'Tango Gameworks', '贝塞斯达软件', '三上真司的怪物剧场，弹药永远不够。'],
    ['恶灵附身2', 'The Evil Within 2', 2017, '生存|半开放', 'PC,PS4,XSX', 79, 128, 0, 'Tango Gameworks', '贝塞斯达软件', '半开放的小镇，救女儿的路上全是陷阱。'],
    ['异形：隔离', 'Alien: Isolation', 2014, '异形|潜行', 'PC,PS4,XSX,NS', 85, 128, 0, 'Creative Assembly', '世嘉', '异形会学习你的习惯，躲柜子也不一定安全。'],
    ['失忆症：黑暗后裔', 'Amnesia: The Dark Descent', 2010, '古堡|理智', 'PC,PS4,XSX,NS', 84, 78, 0, 'Frictional Games', 'Frictional Games', '不能反抗的恐怖，理智值和油灯一起减少。'],
    ['SOMA', 'SOMA', 2015, '海底|哲学', 'PC,PS4,XSX', 85, 108, 60, 'Frictional Games', 'Frictional Games', '海底基地里追问意识是什么，比怪物更冷。'],
    ['逃生', 'Outlast', 2013, '第一人称|逃亡', 'PC,PS4,XSX,NS', 80, 78, 60, 'Red Barrels', 'Red Barrels', '只有一台摄像机，跑和躲是唯一选择。'],
    ['逃生2', 'Outlast 2', 2017, '第一人称|邪教', 'PC,PS4,XSX,NS', 76, 98, 0, 'Red Barrels', 'Red Barrels', '亚利桑那的邪教村落，追到你喘不上气。'],
    ['层层恐惧', 'Layers of Fear', 2016, '心理|画作', 'PC,PS5,XSX', 74, 78, 60, 'Bloober Team', 'Aspyr', '房子每推开一扇门都在变形，画家的疯狂。'],
    ['面容', 'Visage', 2020, '第一人称|住宅', 'PC,PS4,XSX', 82, 108, 0, 'SadSquare Studio', 'SadSquare Studio', '在一栋不断变化的房子里，安静得让人发抖。'],
    ['木卫四协议', 'The Callisto Protocol', 2022, '太空|近战', 'PC,PS5,XSX', 71, 248, 60, 'Striking Distance Studios', '卡夫隆游戏', '木卫四监狱的变异体，近战闪避很讲究时机。'],
    ['折磨之魂', 'Tormented Souls', 2021, '复古|解谜', 'PC,PS5,XSX,NS', 76, 98, 0, 'Dual Effect', 'PQube', '固定视角的复古生存恐怖，谜题相当扎实。'],
    ['还愿', 'Devotion', 2019, '民俗|家庭', 'PC', 85, 68, 0, '赤烛游戏', '赤烛游戏', '一间老式公寓里的家庭悲剧，中式恐怖入骨。'],
    ['返校', 'Detention', 2017, '民俗|校园', 'PC,PS4,NS', 82, 48, 40, '赤烛游戏', '赤烛游戏', '六十年代的山中校园，白色恐怖下的噩梦。'],
    ['纸人', 'Paper Dolls', 2019, '古宅|VR', 'PC,PS4', 72, 68, 0, '北京荔枝文化', '北京荔枝文化', '清末古宅里的纸人，中式的阴森很有味道。'],
    ['港诡实录', 'ParanormalHK', 2019, '香港|都市传说', 'PC', 70, 58, 0, 'Ghostpie Studio', 'Ghostpie Studio', '九龙城寨的都市传说，走一圈后背发凉。'],
    ['直到黎明', 'Until Dawn', 2015, '互动|蝴蝶效应', 'PC,PS4,PS5', 79, 198, 0, 'Supermassive Games', '索尼互动娱乐', '雪山小屋的一夜，每个选择都可能害死一个人。'],
    ['采石场惊魂', 'The Quarry', 2022, '互动|夏令营', 'PC,PS5,XSX', 77, 248, 50, 'Supermassive Games', '2K Games', '夏令营最后一晚，谁活下来取决于你的手速。'],
    ['零：濡鸦之巫女', 'Fatal Frame: Maiden of Black Water', 2021, '日式|摄影', 'PC,PS5,XSX,NS', 72, 218, 50, '光荣特库摩', '光荣特库摩', '用相机封印怨灵，日式恐怖的湿润感。']
  ]);

  /* ── 解谜 ──────────────────────────────────────────────────── */
  G('解谜', [
    ['传送门', 'Portal', 2007, '空间|黑色幽默', 'PC,PS4,NS', 92, 48, 40, 'Valve', 'Valve', '一把传送枪，一间间测试室，还有一个蛋糕。'],
    ['传送门2', 'Portal 2', 2011, '空间|合作', 'PC,PS4,NS', 96, 68, 40, 'Valve', 'Valve', '解谜与叙事的完美结合，台词一句都不想跳过。'],
    ['见证者', 'The Witness', 2016, '孤岛|线条', 'PC,PS4,XSX', 87, 108, 0, 'Thekla', 'Thekla', '一座岛全是画线谜题，规则要自己悟。'],
    ['巴巴是你', 'Baba Is You', 2019, '规则|文字', 'PC,PS5,NS', 90, 68, 40, 'Hempuli', 'Hempuli', '改写规则文字就能改变世界，脑洞开到底。'],
    ['塔罗斯法则', 'The Talos Principle', 2014, '哲学|机器人', 'PC,PS4,XSX,NS', 87, 128, 0, 'Croteam', 'Devolver Digital', '在遗迹里解谜，顺便被问什么是人。'],
    ['塔罗斯法则2', 'The Talos Principle 2', 2023, '哲学|机器人', 'PC,PS5,XSX', 86, 198, 30, 'Croteam', 'Devolver Digital', '更大的世界与更多追问，谜题依旧扎实。'],
    ['超阈限空间', 'Superliminal', 2019, '透视|错觉', 'PC,PS4,XSX,NS', 82, 68, 0, 'Pillow Castle', 'Pillow Castle', '靠近大远小骗过自己，视觉把戏玩得很妙。'],
    ['多重花园', 'Manifold Garden', 2019, '重力|埃舍尔', 'PC,PS5,XSX,NS', 84, 78, 40, 'William Chyr Studio', 'William Chyr Studio', '重力随时可以换方向，世界循环到无穷。'],
    ['反空间', 'Antichamber', 2013, '非欧|抽象', 'PC', 82, 48, 0, 'Alexander Bruce', 'Alexander Bruce', '走廊走回头就变了，逻辑在这里不管用。'],
    ['神秘岛', 'Myst', 2020, '经典|岛屿', 'PC,XSX', 80, 128, 0, 'Cyan Worlds', 'Cyan Worlds', '重制的解谜鼻祖，靠观察和笔记走完岛屿。'],
    ['星空断层', 'Riven', 2024, '经典|世界', 'PC', 83, 168, 0, 'Cyan Worlds', 'Cyan Worlds', '神秘岛的续作重制，谜题密度依旧惊人。'],
    ['香肠卷', "Stephen's Sausage Roll", 2016, '推箱|硬核', 'PC', 87, 68, 0, 'Increpare', 'Increpare', '用一根叉子翻动香肠，规则简单到极致。'],
    ['Opus Magnum', 'Opus Magnum', 2017, '机械|编程', 'PC', 89, 78, 40, 'Zachtronics', 'Zachtronics', '设计炼金机械臂，优化到每一帧都算数。'],
    ['无限工厂', 'Infinifactory', 2015, '流水线|3D', 'PC', 86, 78, 0, 'Zachtronics', 'Zachtronics', '在太空搭流水线，把方块送到该去的地方。'],
    ['太空化学', 'SpaceChem', 2011, '编程|化学', 'PC', 85, 48, 0, 'Zachtronics', 'Zachtronics', '用反应堆语言写程序，玩着玩着像在上课。'],
    ['迷你地铁', 'Mini Metro', 2015, '地铁|极简', 'PC,PS4,NS', 86, 48, 0, 'Dinosaur Polo Club', 'Dinosaur Polo Club', '画几条线让城市流动起来，越简洁越上瘾。'],
    ['迷你公路', 'Mini Motorways', 2021, '公路|极简', 'PC,NS', 83, 58, 40, 'Dinosaur Polo Club', 'Dinosaur Polo Club', '公路越修越乱，红点永远堵在路口。'],
    ['帕特里克的悖论箱', "Patrick's Parabox", 2022, '递归|推箱', 'PC,NS', 89, 78, 0, 'Patrick Traynor', 'Patrick Traynor', '箱子里面还有箱子，递归玩到头晕。'],
    ['锈湖：根源', 'Rusty Lake: Roots', 2016, '怪诞|家族', 'PC,PS4,NS', 86, 38, 0, 'Rusty Lake', 'Rusty Lake', '一个家族的怪诞族谱，画风越看越不对劲。'],
    ['蓝色王子', 'Blue Prince', 2025, '房间|随机', 'PC,PS5,XSX', 90, 158, 0, 'Dogubomb', 'Raw Fury', '每天重新规划宅邸房间，谜题藏在布局里。'],
    ['洛蕾莱与激光眼', 'Lorelei and the Laser Eyes', 2024, '酒店|机关', 'PC,NS', 87, 128, 0, 'Simogo', 'Annapurna Interactive', '一座诡异酒店，全是纸笔推理的谜题。'],
    ['虚空异境', 'Void Stranger', 2023, '推箱|元游戏', 'PC', 85, 68, 0, 'System Erasure', 'System Erasure', '看着像推箱子，玩下去发现不止如此。'],
    ['罗特里斯之死', 'The Roottrees are Dead', 2025, '族谱|推理', 'PC', 86, 78, 0, 'Evil Turtle Games', 'Evil Turtle Games', '靠搜索与档案拼出一家人的完整族谱。'],
    ['机械迷城', 'Machinarium', 2009, '手绘|机器人', 'PC,PS4,NS', 85, 48, 0, 'Amanita Design', 'Amanita Design', '锈迹斑斑的机器人城市，手绘解谜的经典。'],
    ['银河历险记3', 'Samorost 3', 2016, '手绘|音乐', 'PC,PS4,NS', 84, 78, 50, 'Amanita Design', 'Amanita Design', '跟着一支笛子穿过星球，画面像绘本。'],
    ['植物精灵', 'Botanicula', 2012, '手绘|森林', 'PC', 83, 48, 0, 'Amanita Design', 'Amanita Design', '五个小生物救一棵树，音乐与画面都轻。'],
    ['纪念碑谷 全景版', 'Monument Valley: Panoramic Edition', 2022, '视错觉|建筑', 'PC', 84, 48, 0, 'ustwo games', 'ustwo games', '用不可能的建筑骗过眼睛，走完一段安静的路。'],
    ['房间：旧罪', 'The Room: Old Sins', 2021, '机关|盒子', 'PC,NS', 82, 48, 40, 'Fireproof Games', 'Fireproof Games', '一层层拆开精巧的机关盒，手感极好。'],
    ['图灵完备', 'Turing Complete', 2021, '逻辑|计算机', 'PC', 86, 88, 0, 'LevelHead', 'LevelHead', '从逻辑门开始，一路搭出一台电脑。'],
    ['深圳 I/O', 'SHENZHEN I/O', 2016, '电路|编程', 'PC', 86, 78, 0, 'Zachtronics', 'Zachtronics', '读手册、写微代码，真的像在电子厂上班。']
  ]);

  /* ── 竞速 ──────────────────────────────────────────────────── */
  G('竞速', [
    ['GT赛车7', 'Gran Turismo 7', 2022, '拟真|赛道', 'PS5,PS4', 87, 398, 0, 'Polyphony Digital', '索尼互动娱乐', '从驾照考试到古董车收藏，赛车文化很足。'],
    ['GT赛车Sport', 'Gran Turismo Sport', 2017, '拟真|驾照', 'PS4', 78, 198, 50, 'Polyphony Digital', '索尼互动娱乐', '更纯粹的赛道竞速，驾照模式依旧折磨人。'],
    ['神力科莎', 'Assetto Corsa', 2014, '拟真|模组', 'PC,PS4,XSX', 87, 108, 0, 'Kunos Simulazioni', '505 Games', '手感硬核的模拟赛车，模组生态极其丰富。'],
    ['神力科莎：竞技版', 'Assetto Corsa Competizione', 2019, '拟真|GT', 'PC,PS5,XSX', 85, 168, 0, 'Kunos Simulazioni', '505 Games', '只做 GT3 赛事，轮胎与刹车都要认真对待。'],
    ['F1 23', 'F1 23', 2023, '方程式|赛季', 'PC,PS5,XSX', 82, 298, 0, 'Codemasters', '艺电', '完整的 F1 赛季与剧情模式，走线要练。'],
    ['F1 24', 'F1 24', 2024, '方程式|赛季', 'PC,PS5,XSX', 79, 348, 0, 'Codemasters', '艺电', '新赛季与新车感，方向盘后的细节更多。'],
    ['尘埃拉力赛2.0', 'DiRT Rally 2.0', 2019, '拉力|拟真', 'PC,PS4,XSX', 87, 148, 0, 'Codemasters', 'Codemasters', '碎石路上的拉力，一次失误就翻下山。'],
    ['EA Sports WRC', 'EA Sports WRC', 2023, '拉力|赛季', 'PC,PS5,XSX', 76, 298, 0, 'Codemasters', '艺电', '官方 WRC 授权，赛道长到需要记路书。'],
    ['极品飞车：热度', 'Need for Speed Heat', 2019, '街头|改装', 'PC,PS4,XSX', 76, 198, 0, 'Ghost Games', '艺电', '白天跑正规赛，夜里躲警察，改装很上瘾。'],
    ['极品飞车：不羁', 'Need for Speed Unbound', 2022, '街头|涂鸦', 'PC,PS5,XSX', 75, 298, 0, 'Criterion Games', '艺电', '卡通特效配街头狂飙，画风相当大胆。'],
    ['火爆狂飙：天堂 重制版', 'Burnout Paradise Remastered', 2020, '破坏|开放城市', 'PC,PS4,XSX,NS', 82, 108, 0, 'Criterion Games', '艺电', '撞车即艺术，天堂城的每条路都能飙。'],
    ['极限竞速', 'Forza Motorsport', 2023, '拟真|赛道', 'PC,XSX', 84, 298, 0, 'Turn 10 Studios', 'Xbox 游戏工作室', '赛道旁的轮胎颗粒都会影响抓地，拟真向。'],
    ['拉力艺术', 'art of rally', 2020, '拉力|极简', 'PC,PS5,XSX,NS', 84, 78, 0, 'Funselektor Labs', 'Funselektor Labs', '低多边形风格的拉力赛，漂移手感很顺。'],
    ['雪地奔驰', 'SnowRunner', 2020, '越野|卡车', 'PC,PS5,XSX,NS', 82, 168, 50, 'Saber Interactive', 'Focus Entertainment', '泥地里挪一米都难，卡车的暴力美学。'],
    ['极速骑行4', 'RIDE 4', 2020, '摩托|赛道', 'PC,PS5,XSX', 78, 198, 0, 'Milestone', 'Milestone', '两轮的世界，压弯与刹车都要精细。'],
    ['MotoGP 23', 'MotoGP 23', 2023, '摩托|赛季', 'PC,PS5,XSX', 76, 248, 50, 'Milestone', 'Milestone', '官方 MotoGP 赛事，高速压弯很刺激。'],
    ['赛车计划2', 'Project CARS 2', 2017, '拟真|全天候', 'PC,PS4,XSX', 80, 168, 0, 'Slightly Mad Studios', '万代南梦宫', '天气与赛道温度都在变，拟真玩家向。'],
    ['GRID Legends', 'GRID Legends', 2022, '赛道|剧情', 'PC,PS5,XSX', 76, 248, 0, 'Codemasters', '艺电', '有真人演出的赛车剧情，比赛类型很杂。'],
    ['飙酷车神：轰鸣盛典', 'The Crew Motorfest', 2023, '开放|夏威夷', 'PC,PS5,XSX', 74, 298, 0, 'Ubisoft Ivory Tower', '育碧', '在夏威夷岛上换着载具玩，车船飞机都有。'],
    ['Trackmania', 'Trackmania', 2020, '赛道|计时', 'PC', 84, 0, 0, 'Nadeo', '育碧', '一条赛道反复刷零点零几秒，纯粹的速度。']
  ]);

  /* ── 体育 ──────────────────────────────────────────────────── */
  G('体育', [
    ['EA Sports FC 24', 'EA Sports FC 24', 2023, '足球|俱乐部', 'PC,PS5,XSX,NS', 76, 348, 0, 'EA Vancouver', '艺电', '换名字之后的足球年货，球员动作更细腻。'],
    ['EA Sports FC 25', 'EA Sports FC 25', 2024, '足球|俱乐部', 'PC,PS5,XSX', 74, 398, 0, 'EA Vancouver', '艺电', '新赛季的战术系统，管理深度又加了一层。'],
    ['eFootball 2024', 'eFootball 2024', 2023, '足球|免费', 'PC,PS5,XSX', 70, 0, 0, 'Konami Digital Entertainment', '科乐美', '免费开踢的足球游戏，操作门槛比对手低。'],
    ['NBA 2K24', 'NBA 2K24', 2023, '篮球|生涯', 'PC,PS5,XSX', 74, 348, 0, 'Visual Concepts', '2K Games', '篮球年货，生涯模式的剧情比比赛还长。'],
    ['NBA 2K25', 'NBA 2K25', 2024, '篮球|生涯', 'PC,PS5,XSX', 76, 398, 0, 'Visual Concepts', '2K Games', '投篮手感更顺，MyCareer 依旧要慢慢打。'],
    ['WWE 2K24', 'WWE 2K24', 2024, '摔跤|表演', 'PC,PS5,XSX', 78, 398, 0, 'Visual Concepts', '2K Games', '擂台上的表演赛，剧情模式拍得比电视好看。'],
    ['MLB The Show 24', 'MLB The Show 24', 2024, '棒球|生涯', 'PS5,XSX,NS', 79, 398, 40, 'San Diego Studio', '索尼互动娱乐', '棒球模拟的标杆，挥棒时机决定一切。'],
    ['NHL 24', 'NHL 24', 2023, '冰球|赛季', 'PS5,XSX', 73, 348, 0, 'EA Vancouver', '艺电', '冰面上的高速对抗，碰撞感十足，赛季模式很完整。'],
    ['Madden NFL 24', 'Madden NFL 24', 2023, '橄榄球|战术', 'PC,PS5,XSX', 72, 348, 0, 'EA Tiburon', '艺电', '橄榄球战术板很厚，读防守是门学问。'],
    ['足球经理2024', 'Football Manager 2024', 2023, '足球|经营', 'PC,PS5,XSX,NS', 86, 258, 0, 'Sports Interactive', '世嘉', '看数据踢比赛，为一名边锋熬到凌晨。'],
    ['职业滑板高手1+2', "Tony Hawk's Pro Skater 1+2", 2020, '滑板|连招', 'PC,PS5,XSX,NS', 86, 218, 0, 'Vicarious Visions', '动视', '经典滑板重制，连招分数越滚越离谱。'],
    ['OlliOlli World', 'OlliOlli World', 2022, '滑板|卡通', 'PC,PS5,XSX,NS', 84, 108, 0, 'Roll7', 'Private Division', '卡通滑板世界的关卡设计，节奏很舒服。'],
    ['PGA Tour 2K23', 'PGA Tour 2K23', 2022, '高尔夫|球场', 'PC,PS5,XSX', 76, 298, 0, 'HB Studios', '2K Games', '挥杆手感扎实，球场风景也不错，适合慢节奏玩家。'],
    ['EA Sports PGA Tour', 'EA Sports PGA Tour', 2023, '高尔夫|拟真', 'PC,PS5,XSX', 74, 348, 0, 'EA Tiburon', '艺电', '大满贯球场收录齐全，风向很要命。'],
    ['板球24', 'Cricket 24', 2023, '板球|赛季', 'PC,PS5,XSX', 68, 248, 50, 'Big Ant Studios', 'NACON', '板球规则复杂，但打击感很痛快，入门要多看几场。'],
    ['极限国度', 'Riders Republic', 2021, '极限|开放', 'PC,PS5,XSX', 76, 298, 60, 'Ubisoft Annecy', '育碧', '滑雪、山地车、翼装一起上，很热闹。'],
    ['速降王者', 'Descenders', 2019, '山地车|速降', 'PC,PS5,XSX,NS', 80, 78, 0, 'RageSquid', 'No More Robots', '山地车下坡，摔了要重来，节奏很爽。'],
    ['上旋网球2K25', 'TopSpin 2K25', 2024, '网球|球场', 'PC,PS5,XSX', 75, 348, 30, 'Hangar 13', '2K Games', '底线对拉的节奏感，发球要算角度。'],
    ['网球世界巡回赛2', 'Tennis World Tour 2', 2020, '网球|赛季', 'PC,PS5,XSX,NS', 66, 198, 0, 'Big Ant Studios', 'NACON', '网球年货里的中规中矩之作，能打就行。'],
    ['火箭联盟', 'Rocket League', 2015, '足球|车辆', 'PC,PS5,XSX,NS', 88, 0, 0, 'Psyonix', 'Psyonix', '用车踢球的物理竞技，入门简单上限极高。']
  ]);

  /* ── 动作冒险 ──────────────────────────────────────────────── */
  G('动作冒险', [
    ['控制', 'Control', 2019, '超自然|联邦局', 'PC,PS5,XSX', 85, 158, 60, 'Remedy Entertainment', '505 Games', '会变形的联邦控制局大楼，超能力砸穿一切。'],
    ['心灵杀手2', 'Alan Wake 2', 2023, '超自然|叙事', 'PC,PS5,XSX', 89, 298, 0, 'Remedy Entertainment', 'Epic Games Publishing', '作家改写现实，双主角在黑暗里找出口。'],
    ['心灵杀手', 'Alan Wake', 2010, '超自然|光明', 'PC,XSX', 83, 68, 50, 'Remedy Entertainment', '微软工作室', '用手电筒照破黑暗，作家被困在自己的故事里。'],
    ['神秘海域4：盗贼末路', "Uncharted 4: A Thief's End", 2016, '寻宝|攀爬', 'PC,PS4,PS5', 93, 198, 0, 'Naughty Dog', '索尼互动娱乐', '德雷克的最后一次冒险，攀爬与对话都精彩。'],
    ['神秘海域：盗贼传奇合辑', 'Uncharted: Legacy of Thieves Collection', 2022, '寻宝|合集', 'PC,PS5', 88, 298, 40, 'Naughty Dog', '索尼互动娱乐', '两部作品打包，画面与手感都重新调过。'],
    ['最后生还者 第一部', 'The Last of Us Part I', 2022, '末世|父女', 'PC,PS5', 89, 398, 0, 'Naughty Dog', '索尼互动娱乐', '乔尔与艾莉穿越美国，最残忍的温柔。'],
    ['最后生还者 第二部', 'The Last of Us Part II', 2020, '末世|复仇', 'PS5,PS4', 90, 398, 0, 'Naughty Dog', '索尼互动娱乐', '复仇的两面都写透了，玩完需要缓一缓。'],
    ['古墓丽影', 'Tomb Raider', 2013, '生存|海岛', 'PC,PS4,XSX', 86, 98, 0, 'Crystal Dynamics', '史克威尔艾尼克斯', '劳拉的重启之作，从求生开始的成长。'],
    ['古墓丽影：崛起', 'Rise of the Tomb Raider', 2015, '雪原|古墓', 'PC,PS4,XSX', 87, 128, 0, 'Crystal Dynamics', '史克威尔艾尼克斯', '西伯利亚的雪与古墓，探索比例更高。'],
    ['古墓丽影：暗影', 'Shadow of the Tomb Raider', 2018, '雨林|末世', 'PC,PS5,XSX', 81, 198, 0, 'Eidos-Montréal', '史克威尔艾尼克斯', '玛雅雨林里的终章，潜行做得更细。'],
    ['死亡之门', "Death's Door", 2021, '乌鸦|灵魂', 'PC,PS5,XSX,NS', 85, 78, 0, 'Acid Nerve', 'Devolver Digital', '一只上班的乌鸦去收灵魂，手感干脆。'],
    ['奇纳：灵魂之桥', 'Kena: Bridge of Spirits', 2021, '精灵|手绘', 'PC,PS5', 83, 158, 0, 'Ember Lab', 'Ember Lab', '画面像动画电影，小精灵跟着你满地跑。'],
    ['星球大战 绝地：陨落的武士团', 'Star Wars Jedi: Fallen Order', 2019, '星战|绝地', 'PC,PS5,XSX', 84, 198, 0, 'Respawn Entertainment', '艺电', '光剑对决与跑酷攀爬，星战粉的菜。'],
    ['星球大战 绝地：幸存者', 'Star Wars Jedi: Survivor', 2023, '星战|绝地', 'PC,PS5,XSX', 85, 298, 0, 'Respawn Entertainment', '艺电', '更大的地图与更多光剑姿势，故事更沉。'],
    ['霍格沃茨之遗', 'Hogwarts Legacy', 2023, '魔法|学院', 'PC,PS5,XSX', 84, 298, 0, 'Avalanche Software', '华纳兄弟游戏', '在霍格沃茨上课、逛城堡、顺便拯救世界。'],
    ['瘟疫传说：无罪', 'A Plague Tale: Innocence', 2019, '中世纪|鼠群', 'PC,PS5,XSX,NS', 84, 158, 0, 'Asobo Studio', 'Focus Home Interactive', '带着弟弟躲避鼠潮，潜行与投石索并用。'],
    ['瘟疫传说：安魂曲', 'A Plague Tale: Requiem', 2022, '中世纪|鼠群', 'PC,PS5,XSX,NS', 85, 248, 40, 'Asobo Studio', 'Focus Entertainment', '鼠潮规模翻倍，画面与情绪都更沉。'],
    ['波斯王子：失落的王冠', 'Prince of Persia: The Lost Crown', 2024, '横版|时间', 'PC,PS5,XSX,NS', 86, 198, 0, 'Ubisoft Montpellier', '育碧', '横版银河城，跑酷与时间能力都很顺。'],
    ['大神：绝景版', 'Okami HD', 2017, '水墨|神话', 'PC,PS4,XSX,NS', 92, 98, 50, 'Clover Studio', '卡普空', '用笔刷改变世界，水墨风的日本神话。'],
    ['暗黑血统3', 'Darksiders III', 2018, '天启|动作', 'PC,PS4,XSX', 72, 128, 0, 'Gunfire Games', 'THQ Nordic', '天启四骑士的愤怒，鞭子抽得很爽。'],
    ['暗黑血统：创世', 'Darksiders Genesis', 2019, '俯视|双人', 'PC,PS4,XSX,NS', 78, 128, 60, 'Airship Syndicate', 'THQ Nordic', '俯视角的暗黑血统，双主角切换作战。'],
    ['猎天使魔女3', 'Bayonetta 3', 2022, '魔女|华丽', 'NS', 87, 398, 20, '白金工作室', '任天堂', '魔女踩着高跟鞋打天使，演出依旧浮夸。'],
    ['师傅', 'Sifu', 2022, '功夫|复仇', 'PC,PS5,XSX,NS', 82, 148, 0, 'Sloclap', 'Sloclap', '每死一次就老一岁，功夫片式的复仇。'],
    ['幽灵线：东京', 'Ghostwire: Tokyo', 2022, '都市|妖怪', 'PC,PS5', 75, 198, 60, 'Tango Gameworks', '贝塞斯达软件', '空无一人的涩谷，用结印驱散妖怪。'],
    ['邪恶西部', 'Evil West', 2022, '西部|吸血鬼', 'PC,PS5,XSX', 74, 198, 0, 'Flying Wild Hog', 'Focus Entertainment', '电拳套打吸血鬼，B 级片式的痛快。'],
    ['魔咒之地', 'Forspoken', 2023, '魔法|跑酷', 'PC,PS5', 68, 398, 0, 'Luminous Productions', '史克威尔艾尼克斯', '魔法跑酷很流畅，故事略显单薄，跑图本身够爽。'],
    ['天堂的陌生人：最终幻想起源', 'Stranger of Paradise: Final Fantasy Origin', 2022, '最终幻想|硬核', 'PC,PS5,XSX', 74, 298, 50, 'Team Ninja', '史克威尔艾尼克斯', '不断换职业的硬核动作，光污染式特效。'],
    ['血污：夜之仪式', 'Bloodstained: Ritual of the Night', 2019, '恶魔城|横版', 'PC,PS4,XSX,NS', 85, 138, 0, 'ArtPlay', '505 Games', '五十岚孝司的恶魔城精神续作，探索很正。'],
    ['钢铁之尾', 'Tails of Iron', 2021, '老鼠|手绘', 'PC,PS5,XSX,NS', 78, 98, 0, 'Odd Bug Studio', 'United Label', '老鼠国王的复仇，手绘画风加硬核战斗。'],
    ['阿玛拉王国：惩罚 重制版', 'Kingdoms of Amalur: Re-Reckoning', 2020, '奇幻|重制', 'PC,PS4,XSX', 72, 128, 0, 'KAIKO', 'THQ Nordic', '战斗手感出色，世界大得像一部设定集。'],
    ['塞尔达传说：织梦岛', "The Legend of Zelda: Link's Awakening", 2019, '重制|岛屿', 'NS', 87, 398, 0, 'Grezzo', '任天堂', '玩具质感的重制，一座岛与一个梦。'],
    ['恶魔城：暗影之王2', 'Castlevania: Lords of Shadow 2', 2014, '吸血鬼|暗黑', 'PC,PS4', 71, 98, 0, 'MercurySteam', '科乐美', '德古拉在现代城市与城堡之间穿梭。']
  ]);

  /* ── 平台跳跃 ──────────────────────────────────────────────── */
  G('平台跳跃', [
    ['蔚蓝', 'Celeste', 2018, '硬核|登山', 'PC,PS5,XSX,NS', 92, 68, 0, 'Maddy Makes Games', 'Maddy Makes Games', '爬一座山，也爬出自己的焦虑，手感极准。'],
    ['空洞骑士', 'Hollow Knight', 2017, '银河城|虫之王国', 'PC,PS5,XSX,NS', 92, 48, 0, 'Team Cherry', 'Team Cherry', '圣巢的虫子王国，探索与战斗都很深。'],
    ['空洞骑士：丝之歌', 'Hollow Knight: Silksong', 2025, '银河城|续作', 'PC,PS5,XSX,NS', 90, 148, 10, 'Team Cherry', 'Team Cherry', '黄蜂女的新王国，速度更快也更狠。'],
    ['奥日与黑暗森林', 'Ori and the Blind Forest', 2015, '唯美|森林', 'PC,PS4,XSX,NS', 89, 78, 0, 'Moon Studios', 'Xbox 游戏工作室', '画面美到舍不得快进，移动手感顺滑。'],
    ['奥日与精灵意志', 'Ori and the Will of the Wisps', 2020, '唯美|森林', 'PC,PS5,XSX,NS', 92, 118, 0, 'Moon Studios', 'Xbox 游戏工作室', '把前作的一切都做得更宽，战斗也更爽。'],
    ['超级马力欧 奥德赛', 'Super Mario Odyssey', 2017, '帽子|城市', 'NS', 96, 398, 0, '任天堂企划制作本部', '任天堂', '扔帽子附身一切，每个王国都有惊喜。'],
    ['超级马力欧兄弟 惊奇', 'Super Mario Bros. Wonder', 2023, '横版|创意', 'NS', 92, 438, 0, '任天堂企划制作本部', '任天堂', '大象变身与惊奇花，横版马力欧的新点子。'],
    ['大金刚：热带急冻', 'Donkey Kong Country: Tropical Freeze', 2018, '横版|硬核', 'NS', 88, 328, 20, 'Retro Studios', '任天堂', '关卡设计密度极高，配乐是加分项。'],
    ['雷曼：传奇', 'Rayman Legends', 2013, '横版|音乐关', 'PC,PS4,XSX,NS', 90, 68, 0, 'Ubisoft Montpellier', '育碧', '音乐关卡与手绘美术，四人同玩更热闹。'],
    ['古惑狼 疯狂三部曲', 'Crash Bandicoot N. Sane Trilogy', 2017, '重制|高难度', 'PC,PS4,XSX,NS', 82, 128, 60, 'Vicarious Visions', '动视', '原汁原味的高难度重制，摔手柄警告。'],
    ['小龙斯派罗 重燃三部曲', 'Spyro Reignited Trilogy', 2018, '重制|轻松', 'PC,PS4,XSX,NS', 84, 148, 0, 'Toys for Bob', '动视', '紫色小龙的三部曲重制，收集控的快乐。'],
    ['麻布仔大冒险', 'Sackboy: A Big Adventure', 2020, '合作|手工', 'PC,PS5,PS4', 80, 298, 0, 'Sumo Digital', '索尼互动娱乐', '布偶质感的世界，关卡设计轻快，两个人玩更热闹。'],
    ['时光之帽', 'A Hat in Time', 2017, '3D|收集', 'PC,PS4,XSX,NS', 85, 78, 50, 'Gears for Breakfast', 'Gears for Breakfast', '小女孩的帽子有各种能力，跳起来很欢快。'],
    ['铲子骑士', 'Shovel Knight', 2014, '复古|骑士', 'PC,PS4,XSX,NS', 88, 58, 50, 'Yacht Club Games', 'Yacht Club Games', '八位机手感的新作，铲子既能挖也能打。'],
    ['茶杯头', 'Cuphead', 2017, '手绘|Boss', 'PC,PS4,XSX,NS', 88, 68, 0, 'Studio MDHR', 'Studio MDHR', '三十年代动画风，Boss 战难得让人上头。'],
    ['渎神', 'Blasphemous', 2019, '像素|宗教', 'PC,PS4,XSX,NS', 82, 98, 60, 'The Game Kitchen', 'Team17', '忏悔者的朝圣，像素画面血腥又华丽。'],
    ['渎神2', 'Blasphemous 2', 2023, '像素|宗教', 'PC,PS5,XSX,NS', 84, 138, 0, 'The Game Kitchen', 'Team17', '三把武器三种打法，地图更开阔，宗教意象依旧浓。'],
    ['终焉之莉莉', 'Ender Lilies: Quietus of the Knights', 2021, '银河城|暗黑', 'PC,PS4,XSX,NS', 84, 98, 50, 'Adglobe', 'Live Wire', '少女与亡灵的净化之旅，音乐极为出色。'],
    ['九日', 'Nine Sols', 2024, '道朋克|格挡', 'PC,PS5,XSX,NS', 86, 118, 20, '赤烛游戏', '赤烛游戏', '道教朋克的动作游戏，格挡手感非常爽。'],
    ['银河战士 生存恐惧', 'Metroid Dread', 2021, '银河城|机器人', 'NS', 88, 398, 20, 'MercurySteam', '任天堂', '萨姆斯被追杀，逃与追的节奏极紧。'],
    ['银河战士 Prime 重制版', 'Metroid Prime Remastered', 2023, '第一人称|探索', 'NS', 90, 328, 20, 'Retro Studios', '任天堂', '第一人称探索的经典，重制后画面干净。'],
    ['星之卡比 探索发现', 'Kirby and the Forgotten Land', 2022, '可爱|3D', 'NS', 86, 398, 0, 'HAL Laboratory', '任天堂', '卡比吞下一切，3D 关卡设计很有巧思。'],
    ['瑞奇与叮当：时空跳转', 'Ratchet & Clank: Rift Apart', 2021, '科幻|裂缝', 'PC,PS5', 87, 398, 0, 'Insomniac Games', '索尼互动娱乐', '穿过裂缝瞬移换场景，武器脑洞极大。'],
    ['脑航员2', 'Psychonauts 2', 2021, '心理|喜剧', 'PC,PS5,XSX', 87, 158, 0, 'Double Fine Productions', 'Xbox 游戏工作室', '钻进别人的脑子里做关卡，创意密度很高。'],
    ['暗影火炬城', 'F.I.S.T.: Forged In Shadow Torch', 2021, '银河城|柴油朋克', 'PC,PS5,XSX', 81, 108, 0, '上海钛核', 'bilibili', '兔子挥着铁拳，柴油朋克的中国城市。'],
    ['公理边缘', 'Axiom Verge', 2015, '像素|科幻', 'PC,PS4,XSX,NS', 82, 68, 50, 'Thomas Happ Games', 'Thomas Happ Games', '一个人做的银河城，错位与故障的想象力。']
  ]);

  /* ── Roguelike ─────────────────────────────────────────────── */
  G('Roguelike', [
    ['哈迪斯', 'Hades', 2020, '希腊神话|叙事', 'PC,PS5,XSX,NS', 94, 118, 0, 'Supergiant Games', 'Supergiant Games', '每次逃出冥界都会死，但故事往前推了一点。'],
    ['哈迪斯II', 'Hades II', 2024, '希腊神话|巫术', 'PC,PS5,XSX,NS', 91, 158, 20, 'Supergiant Games', 'Supergiant Games', '冥界公主的复仇之旅，系统比前作更花。'],
    ['死亡细胞', 'Dead Cells', 2018, '像素|动作', 'PC,PS5,XSX,NS', 89, 88, 40, 'Motion Twin', 'Motion Twin', '手感极佳的动作 Roguelike，死了就再来。'],
    ['以撒的结合：重生', 'The Binding of Isaac: Rebirth', 2014, '地牢|道具', 'PC,PS4,XSX,NS', 89, 68, 0, 'Nicalis', 'Nicalis', '道具组合千变万化，一局比一局更荒诞。'],
    ['雨中冒险2', 'Risk of Rain 2', 2020, '第三人称|难度递增', 'PC,PS5,XSX,NS', 86, 108, 0, 'Hopoo Games', 'Gearbox Publishing', '时间越久敌人越强，堆道具堆到手软。'],
    ['枪火重生', 'Gunfire Reborn', 2021, '第一人称|国风', 'PC,PS5,XSX', 86, 78, 0, '多益网络', '多益网络', '国风射击 Roguelike，词条搭配很有意思。'],
    ['挺进地牢', 'Enter the Gungeon', 2016, '像素|弹幕', 'PC,PS4,XSX,NS', 85, 68, 50, 'Dodge Roll', 'Devolver Digital', '翻滚躲子弹，枪械多到记不住名字。'],
    ['洞窟探险2', 'Spelunky 2', 2020, '洞穴|硬核', 'PC,PS5,XSX,NS', 87, 78, 0, 'Mossmouth', 'Mossmouth', '每一层都可能是陷阱，规则还特别多。'],
    ['死亡回归', 'Returnal', 2021, '科幻|弹幕', 'PC,PS5', 86, 298, 0, 'Housemarque', '索尼互动娱乐', '异星循环里的子弹地狱，手感又快又狠。'],
    ['盗贼遗产2', 'Rogue Legacy 2', 2022, '家族|平台', 'PC,PS5,XSX,NS', 87, 88, 0, 'Cellar Door Games', 'Cellar Door Games', '死了换后代上，家族树就是成长系统。'],
    ['暗黑地牢', 'Darkest Dungeon', 2016, '克苏鲁|压力', 'PC,PS5,XSX,NS', 88, 88, 0, 'Red Hook Studios', 'Red Hook Studios', '队员的精神比血量更容易崩，压力管理很难。'],
    ['暗黑地牢2', 'Darkest Dungeon II', 2023, '克苏鲁|马车', 'PC,PS5,XSX,NS', 80, 158, 40, 'Red Hook Studios', 'Red Hook Studios', '坐着马车走向末日，路线选择就是叙事。'],
    ['循环英雄', 'Loop Hero', 2021, '卡牌|循环', 'PC,NS', 84, 68, 0, 'Four Quarters', 'Devolver Digital', '给英雄铺路放怪物，越贪心越危险。'],
    ['怪物火车', 'Monster Train', 2020, '卡牌|多层', 'PC,PS5,XSX,NS', 87, 88, 40, 'Shiny Shoe', 'Good Shepherd', '三层车厢的卡牌对战，构筑起来很爽。'],
    ['欺诈之地', 'Griftlands', 2021, '卡牌|谈判', 'PC,PS4,NS', 82, 78, 0, 'Klei Entertainment', 'Klei Entertainment', '打架靠牌，谈判也靠牌，两套构筑都得会。'],
    ['矮人要塞', 'Dwarf Fortress', 2022, '殖民地|深度', 'PC', 90, 128, 0, 'Bay 12 Games', 'Kitfox Games', '生成一段完整历史，然后看着要塞崩掉。'],
    ['土豆兄弟', 'Brotato', 2023, '弹幕|土豆', 'PC,PS5,XSX,NS', 84, 38, 0, 'Blobfish', 'Blobfish', '一局二十分钟，武器堆满屏的爽快感。'],
    ['黎明前20分钟', '20 Minutes Till Dawn', 2022, '弹幕|生存', 'PC,NS', 82, 38, 0, 'flanne', 'flanne', '撑过二十分钟的黑暗，升级选项很上头。'],
    ['吸血鬼幸存者', 'Vampire Survivors', 2022, '弹幕|极简', 'PC,PS5,XSX,NS', 87, 38, 0, 'poncle', 'poncle', '只按方向键也能爽，武器进化是核心乐趣。'],
    ['深岩银河：幸存者', 'Deep Rock Galactic: Survivor', 2024, '挖矿|弹幕', 'PC', 83, 68, 20, 'Funday Games', 'Ghost Ship Publishing', '在洞里挖矿又打虫，节奏比正作更快。'],
    ['传说法师', 'Wizard of Legend', 2018, '法术|高速', 'PC,PS4,XSX,NS', 82, 68, 0, 'Contingent99', 'Humble Games', '法术连招很顺，跑位比输出更重要。'],
    ['小骨：英雄杀手', 'Skul: The Hero Slayer', 2021, '换头|像素', 'PC,PS4,XSX,NS', 82, 78, 40, 'SouthPAW Games', 'NEOWIZ', '换一颗头换一套打法，动作节奏很快。'],
    ['祝你好死', 'Have a Nice Death', 2023, '死神|横版', 'PC,PS5,XSX,NS', 78, 108, 0, 'Magic Design Studios', 'Gearbox Publishing', '死神老板的办公室吐槽，横版动作很顺。'],
    ['星界飞升', 'Astral Ascent', 2023, '星座|横版', 'PC,PS5,XSX,NS', 84, 98, 30, 'Hibernian Workshop', 'Hibernian Workshop', '四个角色四条路，法术构筑花样多。'],
    ['杀戮尖塔', 'Slay the Spire', 2019, '卡牌|爬塔', 'PC,PS4,XSX,NS', 92, 78, 0, 'Mega Crit', 'Mega Crit', '卡组构筑的标杆，每一层都要做取舍。'],
    ['小丑牌', 'Balatro', 2024, '扑克|构筑', 'PC,PS5,XSX,NS', 91, 68, 20, 'LocalThunk', 'Playstack', '用扑克牌堆出离谱倍率，一局接一局。']
  ]);

  /* ── 视觉小说 ──────────────────────────────────────────────── */
  G('视觉小说', [
    ['命运石之门', 'STEINS;GATE', 2016, '时间线|科幻', 'PC,PS4,NS', 95, 98, 0, 'MAGES.', '5pb.', '一封短信改变世界线，前半慢热后半爆发。'],
    ['命运石之门0', 'STEINS;GATE 0', 2018, '时间线|分支', 'PC,PS4,NS', 89, 98, 0, 'MAGES.', '5pb.', '另一个世界线的失败与挣扎，更沉的一作。'],
    ['弹丸论破 希望的学园与绝望高中生', 'Danganronpa: Trigger Happy Havoc', 2016, '学园|推理', 'PC,PS4,NS', 88, 88, 40, 'Spike Chunsoft', 'Spike Chunsoft', '被困学园，靠学级裁判找出凶手，每个同学都可疑。'],
    ['超级弹丸论破2', 'Danganronpa 2: Goodbye Despair', 2016, '海岛|推理', 'PC,PS4,NS', 89, 88, 40, 'Spike Chunsoft', 'Spike Chunsoft', '热带海岛上的自相残杀，案件设计更狠。'],
    ['新弹丸论破V3', 'Danganronpa V3: Killing Harmony', 2017, '推理|元叙事', 'PC,PS4,NS', 85, 128, 0, 'Spike Chunsoft', 'Spike Chunsoft', '把系列本身当成谜题，结局争议很大。'],
    ['逆转裁判123 成步堂精选集', 'Phoenix Wright: Ace Attorney Trilogy', 2019, '法庭|推理', 'PC,PS4,XSX,NS', 92, 148, 0, 'Capcom', '卡普空', '一句「异议」拍了二十年，法庭辩论的爽快。'],
    ['大逆转裁判1&2', 'The Great Ace Attorney Chronicles', 2021, '法庭|明治', 'PC,PS4,NS', 89, 198, 0, 'Capcom', '卡普空', '明治日本与伦敦的法庭，双主角搭档。'],
    ['428 被封锁的涩谷', '428: Shibuya Scramble', 2018, '群像|真人', 'PC,PS4', 90, 128, 0, 'Chunsoft', 'Spike Chunsoft', '五个人的一天互相影响，真人照片的叙事。'],
    ['CLANNAD', 'CLANNAD', 2015, '校园|家庭', 'PC,NS', 91, 128, 0, 'Key', 'VisualArts', '校园恋爱走到家庭，后半段很难不哭。'],
    ['Fate/stay night REMASTERED', 'Fate/stay night REMASTERED', 2024, '圣杯|奇幻', 'PC,NS', 88, 218, 0, 'TYPE-MOON', 'TYPE-MOON', '圣杯战争的起点，三条线各自成立。'],
    ['月姬 -A piece of blue glass moon-', 'Tsukihime -A piece of blue glass moon-', 2021, '吸血鬼|都市', 'PC,PS4,NS', 87, 268, 0, 'TYPE-MOON', 'TYPE-MOON', '重制后的月姬，都市怪谈与直死之魔眼。'],
    ['赛博朋克酒保行动', 'VA-11 HALL-A', 2016, '赛博|调酒', 'PC,PS4,NS', 88, 68, 40, 'Sukeban Games', 'Ysbryd Games', '调一杯酒，听客人讲这座城市的破事。'],
    ['咖啡谈话', 'Coffee Talk', 2020, '咖啡|都市奇幻', 'PC,PS4,XSX,NS', 80, 68, 0, 'Toge Productions', 'Toge Productions', '深夜咖啡馆里的异种族客人，热饮暖胃。'],
    ['咖啡谈话 第二集', 'Coffee Talk Episode 2: Hibiscus & Butterfly', 2023, '咖啡|续作', 'PC,PS5,XSX,NS', 82, 78, 40, 'Toge Productions', 'Toge Productions', '老客人带着新烦恼回来，配方也变多了。'],
    ['无垠之心', 'A Space for the Unbound', 2023, '印尼|青春', 'PC,PS5,XSX,NS', 87, 98, 0, 'Mojiken', 'Toge Productions', '九十年代印尼小镇，超能力与青春期。'],
    ['十三机兵防卫圈', '13 Sentinels: Aegis Rim', 2019, '科幻|群像', 'PS4,NS', 93, 398, 20, 'Vanillaware', '阿特拉斯', '十三个人十三条线，拼图式叙事的巅峰。'],
    ['极限脱出：九人游戏', 'Zero Escape: The Nonary Games', 2017, '密室|抉择', 'PC,PS4', 87, 98, 40, 'Spike Chunsoft', 'Spike Chunsoft', '九人密室逃脱，路线分支多到画图。'],
    ['人工智能：梦境档案', 'AI: The Somnium Files', 2019, '梦境|刑侦', 'PC,PS4,NS', 84, 158, 50, 'Spike Chunsoft', 'Spike Chunsoft', '潜入嫌疑人的梦境找线索，脑洞很大。'],
    ['梦境档案 涅槃创世', 'AI: The Somnium Files - nirvanA Initiative', 2022, '梦境|续作', 'PC,PS4,NS', 83, 198, 40, 'Spike Chunsoft', 'Spike Chunsoft', '双主角双时间线，梦境关卡更离谱。'],
    ['弑君者', 'Slay the Princess', 2023, '循环|黑暗', 'PC,NS', 87, 68, 0, 'Black Tabby Games', 'Black Tabby Games', '每次都杀她，每次故事都变得不一样。'],
    ['心跳文学部 Plus', 'Doki Doki Literature Club Plus', 2021, '元叙事|惊悚', 'PC,PS4,XSX,NS', 82, 68, 40, 'Team Salvato', 'Serenity Forge', '看着是恋爱社团，别被开头骗了，后面会变得很冷。'],
    ['如果我的心有翅膀', 'If My Heart Had Wings', 2014, '校园|航空', 'PC', 78, 68, 50, 'MoeNovel', 'MoeNovel', '海边学校的滑翔机部，关于飞起来的青春。']
  ]);

  /* ── 回合制 ────────────────────────────────────────────────── */
  G('回合制', [
    ['火焰纹章：风花雪月', 'Fire Emblem: Three Houses', 2019, '战棋|学院', 'NS', 90, 398, 20, 'Intelligent Systems', '任天堂', '教书、带兵、选边，三条路线各有代价。'],
    ['火焰纹章 Engage', 'Fire Emblem Engage', 2023, '战棋|召唤', 'NS', 82, 398, 20, 'Intelligent Systems', '任天堂', '历代英雄戒指登场，战斗演出很张扬。'],
    ['三角战略', 'Triangle Strategy', 2022, '战棋|抉择', 'PC,NS', 85, 398, 30, 'Artdink', '史克威尔艾尼克斯', '天平投票决定路线，政治戏份比战斗还重。'],
    ['皇家骑士团：重生', 'Tactics Ogre: Reborn', 2022, '战棋|史诗', 'PC,PS5,NS', 87, 298, 0, 'Square Enix', '史克威尔艾尼克斯', '民族冲突与道德困境，战棋叙事的老祖宗。'],
    ['圣兽之王', 'Unicorn Overlord', 2024, '战棋|编队', 'PS5,NS,XSX', 87, 398, 0, 'Vanillaware', '阿特拉斯', '编程式的部队编成，开打后看自己的设计跑。'],
    ['漫威午夜之子', 'Marvel\'s Midnight Suns', 2022, '卡牌|超级英雄', 'PC,PS5,XSX', 82, 298, 0, 'Firaxis Games', '2K Games', '用卡牌打超级英雄战术战，人际关系也要养。'],
    ['战争机器：战术小队', 'Gears Tactics', 2020, '战棋|战争机器', 'PC,XSX', 78, 128, 60, 'Splash Damage', 'Xbox 游戏工作室', '战争机器世界里的回合制，节奏比 XCOM 快。'],
    ['马力欧+疯狂兔子 王国之战', 'Mario + Rabbids Kingdom Battle', 2017, '战棋|幽默', 'NS', 84, 298, 0, 'Ubisoft Milan', '育碧', '滑铲与跳跃的战术走位，意外地很硬核。'],
    ['马力欧+疯狂兔子 希望之光', 'Mario + Rabbids Sparks of Hope', 2022, '战棋|星火', 'NS', 85, 398, 0, 'Ubisoft Milan', '育碧', '取消格子限制，战斗更自由也更花。'],
    ['高级战争1+2 重制', 'Advance Wars 1+2: Re-Boot Camp', 2023, '战棋|卡通', 'NS', 83, 398, 0, 'WayForward', '任天堂', '简单规则下的深度战棋，指挥官技能很关键。'],
    ['战场女武神4', 'Valkyria Chronicles 4', 2018, '战棋|半即时', 'PC,PS4,XSX,NS', 85, 158, 0, 'Sega', '世嘉', '画布一样的战场，行动与射击连在一起。'],
    ['战场女武神', 'Valkyria Chronicles', 2014, '战棋|水彩', 'PC,PS4,NS', 87, 98, 50, 'Sega', '世嘉', '水彩画风的战争，狙击与坦克都要算。'],
    ['突变元年：伊甸之路', 'Mutant Year Zero: Road to Eden', 2018, '战棋|末世', 'PC,PS4,XSX,NS', 80, 98, 0, 'The Bearded Ladies', 'Funcom', '鸭子与野猪的废土潜行，先偷袭再开打。'],
    ['凤凰点', 'Phoenix Point', 2019, '战棋|克苏鲁', 'PC,PS4,XSX', 76, 158, 0, 'Snapshot Games', 'Snapshot Games', 'XCOM 原班人马的变异体战争，射击要瞄准部位。'],
    ['暴战机甲', 'BATTLETECH', 2018, '机甲|战棋', 'PC', 78, 158, 0, 'Harebrained Schemes', 'Paradox Interactive', '重型机甲的热管理与部位破坏，慢而扎实。'],
    ['铁血联盟3', 'Jagged Alliance 3', 2023, '佣兵|战术', 'PC', 82, 198, 30, 'Haemimont Games', 'THQ Nordic', '带一队嘴很碎的佣兵去救总统，战术自由度高。'],
    ['暗影狂奔：归来', 'Shadowrun Returns', 2013, '赛博|魔法', 'PC', 78, 48, 0, 'Harebrained Schemes', 'Harebrained Schemes', '赛博朋克加魔法，回合制小队作战。'],
    ['暗影狂奔：龙陨', 'Shadowrun: Dragonfall', 2014, '赛博|柏林', 'PC', 85, 48, 50, 'Harebrained Schemes', 'Harebrained Schemes', '柏林无政府区的故事，系列口碑最好的一部。'],
    ['战律', 'Wargroove', 2019, '战棋|像素', 'PC,PS4,XSX,NS', 82, 78, 0, 'Chucklefish', 'Chucklefish', '高级战争的精神续作，指挥官技能很关键。'],
    ['蒸汽世界：劫掠', 'SteamWorld Heist', 2016, '战棋|弹道', 'PC,PS4,XSX,NS', 85, 68, 0, 'Image & Form', 'Thunderful', '手动瞄准的弹道战棋，跳弹打得很有想法。'],
    ['蒸汽世界：劫掠2', 'SteamWorld Heist II', 2024, '战棋|海盗', 'PC,PS5,XSX,NS', 82, 108, 0, 'Thunderful', 'Thunderful', '海上蒸汽机器人，弹道与职业都更丰富。'],
    ['战锤40K：机械神教', 'Warhammer 40,000: Mechanicus', 2018, '战锤|战棋', 'PC,PS4,XSX,NS', 80, 98, 0, 'Bulwark Studios', 'Kasedo Games', '机械神教的探索与战斗，气氛做成恐怖片。'],
    ['战争交响曲：尼非订传奇', 'Symphony of War: The Nephilim Saga', 2022, '战棋|军团', 'PC', 81, 78, 0, 'Dancing Dragon Games', 'Freedom Games', '小队编制成军团，战场规模比同类更大。'],
    ['战锤40K：混沌之门', 'Warhammer 40,000: Chaos Gate - Daemonhunters', 2022, '战锤|灰骑士', 'PC', 78, 198, 0, 'Complex Games', 'Frontier Foundry', '灰骑士对抗纳垢，回合制战斗很有分量。']
  ]);

  /* ── 沙盒 ──────────────────────────────────────────────────── */
  G('沙盒', [
    ['我的世界', 'Minecraft', 2011, '方块|建造', 'PC,PS5,XSX,NS', 93, 165, 0, 'Mojang Studios', '微软', '挖到基岩，再盖一座自己的城，玩十年都还有得挖。'],
    ['泰拉瑞亚', 'Terraria', 2011, '2D|探索', 'PC,PS4,XSX,NS', 92, 36, 0, 'Re-Logic', 'Re-Logic', '横版的挖掘与战斗，内容多到夸张。'],
    ['坎巴拉太空计划', 'Kerbal Space Program', 2015, '航天|物理', 'PC,PS5,XSX', 90, 128, 60, 'Squad', 'Private Division', '用胶带把火箭拼上天，失败也是乐趣。'],
    ['坎巴拉太空计划2', 'Kerbal Space Program 2', 2023, '航天|续作', 'PC,PS5,XSX', 68, 198, 0, 'Intercept Games', 'Private Division', '更大的航天沙盒，还在慢慢补齐，但潜力摆在那里。'],
    ['围攻', 'Besiege', 2020, '攻城|机械', 'PC,NS', 85, 68, 50, 'Spiderling Studios', 'Spiderling Studios', '造一台投石机去拆城堡，物理很欢乐。'],
    ['拆迁', 'Teardown', 2022, '破坏|体素', 'PC,PS5,XSX', 83, 108, 0, 'Tuxedo Labs', 'Saber Interactive', '每一块砖都能拆，规划路线才能全身而退。'],
    ['废品机械师', 'Scrap Mechanic', 2020, '造车|物理', 'PC', 79, 78, 40, 'Axolot Games', 'Axolot Games', '把废品拼成会动的机械，脑洞决定上限。'],
    ['异星探险家', 'Astroneer', 2019, '异星|采集', 'PC,PS4,XSX,NS', 84, 128, 0, 'System Era Softworks', 'System Era Softworks', '在星球上挖洞造基地，画面清新可爱。'],
    ['太空工程师', 'Space Engineers', 2019, '太空|工程', 'PC,XSX', 82, 108, 0, 'Keen Software House', 'Keen Software House', '从一颗螺丝开始造飞船，工程党天堂。'],
    ['Trailmakers', 'Trailmakers', 2019, '载具|竞速', 'PC,PS5,XSX', 78, 88, 0, 'Flashbulb Games', 'Flashbulb Games', '造车造飞机，然后开着它们去撞，物理笑话不断。'],
    ['幻兽帕鲁', 'Palworld', 2024, '怪物|生存', 'PC,XSX', 82, 128, 20, 'Pocketpair', 'Pocketpair', '抓怪、建基地、让它们上班，想法很野。'],
    ['英灵神殿', 'Valheim', 2021, '维京|生存', 'PC,XSX', 88, 98, 0, 'Iron Gate Studio', 'Coffee Stain Publishing', '维京人的木屋与海船，探索感极好。'],
    ['雾锁王国', 'Enshrouded', 2024, '迷雾|建造', 'PC', 81, 128, 0, 'Keen Games', 'Keen Games', '在迷雾笼罩的大陆上建城，建造系统很细。'],
    ['禁闭求生', 'Grounded', 2022, '缩小|后院', 'PC,XSX', 83, 198, 0, 'Obsidian Entertainment', 'Xbox 游戏工作室', '缩小之后，后院的一只蜘蛛就是 Boss。'],
    ['木筏求生', 'Raft', 2022, '海上|漂流', 'PC', 80, 98, 40, 'Redbeet Interactive', 'Axolot Games', '在木筏上捞垃圾建家园，鲨鱼一直跟着。'],
    ['漫漫长夜', 'The Long Dark', 2017, '寒冬|生存', 'PC,PS4,XSX,NS', 84, 108, 0, 'Hinterland Studio', 'Hinterland Studio', '零下三十度的荒野，火柴比枪重要。'],
    ['绿色地狱', 'Green Hell', 2019, '雨林|生存', 'PC,PS5,XSX,NS', 79, 98, 0, 'Creepy Jar', 'Creepy Jar', '亚马逊雨林里，感染和饥饿一样要命。'],
    ['饥荒', "Don't Starve", 2013, '哥特|生存', 'PC,PS4,NS', 87, 48, 50, 'Klei Entertainment', 'Klei Entertainment', '手绘哥特世界的生存，第一天就天黑。'],
    ['核心守护者', 'Core Keeper', 2024, '地底|挖掘', 'PC,PS5,XSX,NS', 82, 88, 30, 'Pugstorm', 'Fireshine Games', '在地底造一条贯穿世界的矿道，挖着挖着就天亮了。'],
    ['勇者斗恶龙：创世小玩家2', 'Dragon Quest Builders 2', 2019, '建造|JRPG', 'PC,PS4,NS', 87, 298, 0, 'Omega Force', '史克威尔艾尼克斯', '一边盖房子一边推剧情，村民会真心感谢你。']
  ]);

  /* ── 音乐 ──────────────────────────────────────────────────── */
  G('音乐', [
    ['完美音浪', 'Hi-Fi Rush', 2023, '节奏|动作', 'PC,PS5,XSX', 89, 198, 40, 'Tango Gameworks', '贝塞斯达软件', '所有动作都踩在节拍上，越打越有韵律。'],
    ['节奏医生', 'Rhythm Doctor', 2021, '节奏|一键', 'PC', 90, 68, 0, '7th Beat Games', '7th Beat Games', '只在第七拍按一下，故事比想象中动人。'],
    ['冰与火之舞', 'A Dance of Fire and Ice', 2019, '节奏|极简', 'PC,NS', 87, 38, 0, '7th Beat Games', 'indienova', '两个星球沿着轨道走，节奏全靠手感。'],
    ['喵斯快跑', 'Muse Dash', 2018, '节奏|二次元', 'PC,NS', 83, 68, 50, 'PeroPeroGames', 'PeroPeroGames', '跑酷加音游，画面甜度很高，曲子一首接一首。'],
    ['Cytus II', 'Cytus II', 2018, '节奏|赛博', 'PC,NS', 84, 68, 40, 'Rayark', '雷亚游戏', '赛博世界的音乐档案，判定线很优雅。'],
    ['Deemo', 'Deemo', 2013, '钢琴|治愈', 'PC,NS', 87, 68, 0, 'Rayark', '雷亚游戏', '钢琴曲与一个小女孩，结局很安静。'],
    ['DJMAX RESPECT V', 'DJMAX RESPECT V', 2020, '下落|硬核', 'PC', 85, 98, 0, 'NEOWIZ', 'NEOWIZ', '下落式音游的硬核代表，手速门槛很高。'],
    ['节奏光剑', 'Beat Saber', 2019, 'VR|挥砍', 'PC,PS5', 88, 128, 0, 'Beat Games', 'Beat Games', '挥着光剑砍节拍方块，运动量不小。'],
    ['Thumper', 'Thumper', 2016, '节奏|压抑', 'PC,PS4,NS', 82, 68, 0, 'Drool', 'Drool', '在隧道里撞节拍，压迫感极强，玩久了手心出汗。'],
    ['再见狂野之心', 'Sayonara Wild Hearts', 2019, '流行|梦境', 'PC,PS4,NS', 86, 78, 50, 'Simogo', 'Annapurna Interactive', '一张流行专辑变成一场梦境跑酷，二十分钟一气呵成。'],
    ['俄罗斯方块效应：连接', 'Tetris Effect: Connected', 2020, '俄罗斯方块|沉浸', 'PC,PS5,XSX,NS', 90, 158, 0, 'Monstars', 'Enhance', '俄罗斯方块加上音乐与光影，能玩到出神。'],
    ['不羁之路', 'No Straight Roads', 2020, '摇滚|Boss', 'PC,PS4,XSX,NS', 75, 128, 50, 'Metronomik', 'Sold Out', '用音乐攻击的 Boss 战，美术风格很跳。'],
    ['Everhood', 'Everhood', 2021, '节奏|荒诞', 'PC,NS', 84, 48, 0, 'Foreign Gnomes', 'Foreign Gnomes', '躲节拍的战斗，故事意外地认真，荒诞底下有点温柔。'],
    ['Melatonin', 'Melatonin', 2022, '节奏|梦境', 'PC,PS5,NS', 82, 48, 0, 'Half Asleep', 'Half Asleep', '梦境与现实的节奏切换，画风很软。'],
    ['长号冠军', 'Trombone Champ', 2022, '搞怪|吹奏', 'PC,NS', 78, 68, 0, 'Holy Wow Studios', 'Holy Wow Studios', '吹长号不讲音准，笑点全在走音上。'],
    ['重金属：地狱歌手', 'Metal: Hellsinger', 2022, '金属|射击', 'PC,PS5,XSX', 82, 128, 0, 'The Outsiders', 'Funcom', '踩着金属乐节拍开枪，鼓点就是准星。'],
    ['Wandersong', 'Wandersong', 2018, '唱歌|冒险', 'PC,PS4,NS', 85, 68, 0, 'Greg Lobanov', 'Humble Games', '用唱歌解决一切问题，温柔又有趣。']
  ]);

  /* ── 战术射击 ──────────────────────────────────────────────── */
  G('战术射击', [
    ['严阵以待', 'Ready or Not', 2023, '特警|清房', 'PC', 84, 158, 0, 'VOID Interactive', 'VOID Interactive', '慢一点再慢一点，破门前先看门缝。'],
    ['特警小队4', 'SWAT 4', 2005, '特警|经典', 'PC', 88, 48, 0, 'Irrational Games', '雪乐山', '非致命优先的老派特警模拟，喊话比开枪重要。'],
    ['破门而入2：北境行动', 'Door Kickers 2: Task Force North', 2023, '俯视|规划', 'PC', 87, 78, 0, 'KillHouse Games', 'KillHouse Games', '暂停规划路线，再让小队同时破门。'],
    ['零时', 'Zero Hour', 2020, '特警|拟真', 'PC', 76, 68, 40, 'M7 Productions', 'Attrito', '室内近距离作战，队友沟通很关键。'],
    ['地面分支', 'Ground Branch', 2018, '特种|拟真', 'PC', 78, 128, 0, 'BlackFoot Studios', 'BlackFoot Studios', '硬核到连弹匣带几个都要自己配，慢就是快。'],
    ['叛乱：沙漠风暴', 'Insurgency: Sandstorm', 2018, '现代|硬核', 'PC,PS5,XSX', 82, 108, 50, 'New World Interactive', 'Focus Entertainment', '没有准星的战场上，听声辨位能保命。'],
    ['武装突袭3', 'Arma 3', 2013, '军事|沙盒', 'PC', 86, 198, 60, 'Bohemia Interactive', 'Bohemia Interactive', '两三百平方公里的战场，模组生态庞大。'],
    ['武装突袭：重制者', 'Arma Reforger', 2022, '军事|冷战', 'PC,XSX', 74, 248, 0, 'Bohemia Interactive', 'Bohemia Interactive', '新引擎的军事沙盒，载具与地形都升级。'],
    ['幽灵行动：断点', 'Ghost Recon Breakpoint', 2019, '特种|海岛', 'PC,PS5,XSX', 68, 298, 70, 'Ubisoft Paris', '育碧', '极光岛上的幽灵小队，潜行或强攻自选。'],
    ['狙击手：幽灵战士契约2', 'Sniper Ghost Warrior Contracts 2', 2021, '狙击|契约', 'PC,PS5,XSX', 76, 128, 50, 'CI Games', 'CI Games', '两千米外的狙击，风偏和心跳都要算。'],
    ['特殊行动：一线生机', 'Spec Ops: The Line', 2012, '迪拜|战争', 'PC,PS4', 86, 68, 60, 'Yager Development', '2K Games', '一个关于战争片本身的战争故事，越玩越难受。'],
    ['彩虹六号：维加斯2', 'Rainbow Six Vegas 2', 2008, '反恐|掩体', 'PC,PS4', 83, 48, 0, 'Ubisoft Montreal', '育碧', '掩体射击与破门突入，系列转型的经典。'],
    ['费卢杰六日', 'Six Days in Fallujah', 2023, '城市战|写实', 'PC', 68, 128, 0, 'Highwire Games', 'Victura', '程序生成的巷战，破墙与清房都很真实。'],
    ['使命召唤：黑色行动 冷战', 'Call of Duty: Black Ops Cold War', 2020, '冷战|谍战', 'PC,PS5,XSX', 79, 298, 0, 'Treyarch', '动视', '八十年代的谍战剧情，支线可以自己选。'],
    ['使命召唤：现代战争II', 'Call of Duty: Modern Warfare II', 2022, '现代|特种', 'PC,PS5,XSX', 78, 398, 0, 'Infinity Ward', '动视', '水面渗透与车队追击，战役关卡很有想法。'],
    ['战地3', 'Battlefield 3', 2011, '战场|破坏', 'PC,PS4', 87, 98, 0, 'EA DICE', '艺电', '当年的画面标杆，战役也有几段名场面。'],
    ['荣誉勋章：战士', 'Medal of Honor: Warfighter', 2012, '特种|全球', 'PC,PS4', 68, 88, 60, 'Danger Close Games', '艺电', '全球反恐的小队叙事，真实事件改编。'],
    ['三角洲特种部队：黑鹰坠落', 'Delta Force: Black Hawk Down', 2003, '索马里|经典', 'PC', 80, 38, 0, 'NovaLogic', 'NovaLogic', '摩加迪沙的街道战，老派战术射击的记忆。']
  ]);


  /* ── 2026 档期 ─────────────────────────────────────────────── */
  G('开放世界', [
    ['侠盗猎车手6', 'Grand Theft Auto VI', 2026, '都市|犯罪', 'PS5,XSX', 92, 498, 0, 'Rockstar Games', 'Rockstar Games', '回到罪城，双主角的犯罪故事，最受期待的一部。']
  ]);

  G('恐怖生存', [
    ['生化危机：安魂曲', 'Resident Evil Requiem', 2026, '丧尸|恐怖', 'PC,PS5,XSX', 85, 348, 0, 'Capcom', '卡普空', '格蕾丝回到浣熊市废墟，第九部正传回到起点。']
  ]);

  G('魂类', [
    ['仁王3', 'Nioh 3', 2026, '战国|妖怪', 'PC,PS5', 85, 298, 0, 'Team Ninja', '光荣特库摩', '战国与妖怪并行，双战斗风格的续作。']
  ]);

  /* ---------- 展开为对象 ---------- */
  function slug(s) {
    return String(s).toLowerCase()
      .replace(/[':：，,·]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  var used = Object.create(null);
  var data = new Array(rows.length);

  for (var i = 0; i < rows.length; i++) {
    var r = rows[i];
    var base = slug(r[2]) || 'game';
    if (used[base]) {
      used[base] += 1;
      base = base + '-' + used[base];
    } else {
      used[base] = 1;
    }
    data[i] = {
      id: base,
      cn: r[1],
      en: r[2],
      year: r[3],
      genre: r[0],
      tags: r[4].split('|'),
      platforms: r[5].split(','),
      score: r[6],
      price: r[7],
      discount: r[8],
      dev: r[9],
      pub: r[10],
      blurb: r[11]
    };
  }

  window.GAME_DATA = data;
})();
