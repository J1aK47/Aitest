/* ==========================================================================
   游集 GAMEHUB — cover.js
   程序化封面引擎：window.CoverEngine.render(game, opts) -> data:image/svg+xml
   --------------------------------------------------------------------------
   设计约束：
   1. 零网络请求。全部为内联 SVG，转 data-uri 后交给 <img>。
   2. 确定性。种子来自标题字符串 hash，同一款游戏每次生成完全一致。
   3. 排版分层：渐变底 -> 几何母题(1-2 种) -> 纹理 -> 暗角 -> 类型胶囊 -> 标题。
   4. 类型家族配色，同类型有家族感，个体靠色相抖动与母题组合区分。
   5. 结果按 id 缓存（Map），避免重复拼接字符串。
   ========================================================================== */

(function () {
  'use strict';

  var W = 600;
  var H = 800;

  /* ---------- 类型家族配色 ----------------------------------------------
     h       基础色相
     span    个体色相抖动范围（家族感 + 个体差异）
     shift   第二色相偏移
     sat/l   两档饱和度与明度区间
     acc*    点缀色（母题描边、色块） */
  var FAMILIES = {
    ember: { h: 354, span: 16, shift: 12, s1: 44, s2: 54, l0: 7, l1: 21, accH: 6, accS: 74, accL: 46 },
    cyan: { h: 196, span: 28, shift: 46, s1: 52, s2: 66, l0: 9, l1: 25, accH: 268, accS: 78, accL: 64 },
    sunset: { h: 22, span: 26, shift: -16, s1: 60, s2: 74, l0: 10, l1: 29, accH: 44, accS: 92, accL: 58 },
    clash: { h: 318, span: 62, shift: 205, s1: 64, s2: 78, l0: 10, l1: 27, accH: 168, accS: 82, accL: 56 },
    steel: { h: 214, span: 14, shift: 8, s1: 24, s2: 36, l0: 10, l1: 23, accH: 202, accS: 58, accL: 62 },
    moss: { h: 152, span: 24, shift: -16, s1: 36, s2: 50, l0: 10, l1: 25, accH: 86, accS: 60, accL: 58 },
    blush: { h: 328, span: 20, shift: -30, s1: 50, s2: 64, l0: 11, l1: 27, accH: 268, accS: 72, accL: 68 },
    royal: { h: 268, span: 20, shift: 14, s1: 46, s2: 56, l0: 9, l1: 23, accH: 42, accS: 88, accL: 60 },
    pop: { h: 214, span: 16, shift: 14, s1: 60, s2: 72, l0: 12, l1: 29, accH: 48, accS: 96, accL: 60 }
  };

  /* 类型 -> 家族 */
  var GENRE_FAMILY = {
    '动作角色扮演': 'sunset',
    '魂类': 'ember',
    '开放世界': 'sunset',
    '第一人称射击': 'cyan',
    '角色扮演': 'royal',
    '策略': 'steel',
    '模拟经营': 'moss',
    '独立': 'clash',
    '恐怖生存': 'ember',
    '解谜': 'clash',
    '竞速': 'cyan',
    '体育': 'moss',
    '动作冒险': 'sunset',
    '平台跳跃': 'pop',
    'Roguelike': 'royal',
    '视觉小说': 'blush',
    '回合制': 'steel',
    '沙盒': 'moss',
    '音乐': 'blush',
    '战术射击': 'steel'
  };

  /* ---------- 工具 ---------- */
  function hash(str) {
    var h = 5381;
    for (var i = 0; i < str.length; i++) {
      h = ((h << 5) + h + str.charCodeAt(i)) >>> 0;
    }
    return h >>> 0;
  }

  /* mulberry32：小而稳的确定性 PRNG */
  function makeRng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6d2b79f5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  }

  function hsl(h, s, l, a) {
    h = ((h % 360) + 360) % 360;
    /* 用色值 3 代的逗号语法，兼容面最广（SVG 以图片方式解码时同样适用） */
    if (a === undefined) {
      return 'hsl(' + h.toFixed(0) + ', ' + s.toFixed(0) + '%, ' + l.toFixed(0) + '%)';
    }
    return 'hsla(' + h.toFixed(0) + ', ' + s.toFixed(0) + '%, ' + l.toFixed(0) + '%, ' + a + ')';
  }

  function r1(n) { return Math.round(n * 10) / 10; }

  /* ---------- 调色板 ---------- */
  /* 亮度兜底：任何家族都必须保证白字对比度，避免"好看但读不清" */
  function lumOf(h, s, l) {
    s /= 100;
    l /= 100;
    function f(n) {
      var k = (n + h / 30) % 12;
      var a = s * Math.min(l, 1 - l);
      return l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
    }
    var rgb = [f(0), f(8), f(4)].map(function (v) {
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
  }

  function darkenFor(h, s, l, minRatio) {
    var L = l;
    while (L > 3 && 1.05 / (lumOf(h, s, L) + 0.05) < minRatio) L -= 1.5;
    return Math.max(3, L);
  }

  function makePalette(genre, rnd) {
    var key = GENRE_FAMILY[genre] || 'steel';
    var f = FAMILIES[key];

    /* 同家族内分三档色相分支 + ±28° 抖动：同一个家族也能铺出冷暖差，
       不至于一屏全是同一块橙或同一块蓝 */
    var branch = Math.floor(rnd() * 3) - 1;          /* -1 / 0 / 1 */
    var spread = Math.max(56, f.span);               /* 至少 ±28° */
    var base = f.h + branch * 34 + (rnd() - 0.5) * spread;

    var second = base + f.shift + (rnd() - 0.5) * 22;

    /* 母题色取与底色成 140—200° 的对比色，不再用同色系浅色 */
    var acc = base + 140 + rnd() * 60;

    var l0 = darkenFor(base, f.s1, f.l0 + rnd() * 3, 6.5);
    var l1 = darkenFor(second, f.s2, f.l1 + rnd() * 4, 5.4);

    return {
      key: key,
      c0: hsl(base, f.s1, l0),                                 // 深端
      c1: hsl(second, f.s2, l1),                               // 中段
      c2: hsl(acc, Math.min(90, f.accS + 8), f.accL, 0.9),     // 点缀（对比色）
      cSoft: hsl(acc, f.accS, f.accL, 0.2),
      cLine: hsl(acc, Math.max(40, Math.min(62, f.accS - 10)), Math.min(72, f.accL + 6), 0.42),
      light: hsl(acc, 90, 76, 0.14)
    };
  }

  /* ---------- 几何母题 ---------- */
  /* 每个母题返回 { body, weight } —— weight 用于决定是否叠加第二种 */
  var MOTIFS = {
    /* 圆环 */
    rings: function (rnd, p) {
      var cx = 130 + rnd() * 360;
      var cy = 150 + rnd() * 420;
      var base = 110 + rnd() * 120;
      var rot = (rnd() - 0.5) * 40;
      var out = ['<g transform="rotate(' + r1(rot) + ' ' + r1(cx) + ' ' + r1(cy) + ')" fill="none">'];
      for (var i = 0; i < 3; i++) {
        out.push(
          '<circle cx="' + r1(cx) + '" cy="' + r1(cy) + '" r="' + r1(base * (1 + i * 0.46)) +
          '" stroke="' + p.cLine + '" stroke-width="' + r1(1.4 + rnd() * 2.4) +
          '" opacity="' + r1(0.75 - i * 0.18) + '"/>'
        );
      }
      out.push('</g>');
      return out.join('');
    },

    /* 同心弧（用 dasharray 切出弧段） */
    arcs: function (rnd, p) {
      var cx = 300 + (rnd() - 0.5) * 220;
      var cy = 330 + (rnd() - 0.5) * 200;
      var r = 150 + rnd() * 90;
      var out = ['<g fill="none" stroke="' + p.c2 + '" stroke-linecap="round">'];
      for (var i = 0; i < 4; i++) {
        var rr = r + i * 46;
        var dash = 60 + rnd() * 110;
        out.push(
          '<circle cx="' + r1(cx) + '" cy="' + r1(cy) + '" r="' + r1(rr) +
          '" stroke-width="' + r1(2 + rnd() * 5) +
          '" stroke-dasharray="' + r1(dash) + ' ' + r1(360 - dash * 0.55) +
          '" opacity="' + r1(0.34 - i * 0.05) + '" transform="rotate(' +
          r1(rnd() * 360) + ' ' + r1(cx) + ' ' + r1(cy) + ')"/>'
        );
      }
      out.push('</g>');
      return out.join('');
    },

    /* 斜切色带 */
    bands: function (rnd, p) {
      var rot = -32 + (rnd() - 0.5) * 18;
      var out = ['<g transform="rotate(' + r1(rot) + ' 300 400)" opacity="0.9">'];
      var y = -260 + rnd() * 120;
      for (var i = 0; i < 5; i++) {
        var hgt = 26 + rnd() * 88;
        out.push(
          '<rect x="-320" y="' + r1(y) + '" width="1240" height="' + r1(hgt) +
          '" fill="' + (i % 2 === 0 ? p.cSoft : p.cLine) +
          '" opacity="' + r1(0.16 + rnd() * 0.28) + '"/>'
        );
        y += hgt + 24 + rnd() * 70;
      }
      out.push('</g>');
      return out.join('');
    },

    /* 半调网点 */
    halftone: function (rnd, p) {
      var id = 'ht' + Math.floor(rnd() * 1e6);
      var cell = 12 + Math.floor(rnd() * 10);
      var rad = 1.6 + rnd() * 1.8;
      var cols = Math.ceil(W / cell);
      var rows = Math.ceil(H / cell);
      var out = [
        '<g opacity="0.55">',
        '<defs><pattern id="' + id + '" width="' + cell + '" height="' + cell + '" patternUnits="userSpaceOnUse">',
        '<circle cx="' + r1(cell / 2) + '" cy="' + r1(cell / 2) + '" r="' + r1(rad) + '" fill="' + p.c2 + '"/>',
        '</pattern></defs>',
        '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="url(#' + id + ')" opacity="0.34" transform="rotate(' +
          r1((rnd() - 0.5) * 16) + ' ' + (W / 2) + ' ' + (H / 2) + ')"/>',
        '</g>'
      ];
      return out.join('');
    },

    /* 细网格 */
    grid: function (rnd, p) {
      var id = 'gr' + Math.floor(rnd() * 1e6);
      var step = 34 + Math.floor(rnd() * 26);
      var out = [
        '<g opacity="0.4" transform="rotate(' + r1((rnd() - 0.5) * 10) + ' 300 400)">',
        '<defs><pattern id="' + id + '" width="' + step + '" height="' + step + '" patternUnits="userSpaceOnUse">',
        '<path d="M' + step + ' 0H0V' + step + '" fill="none" stroke="' + p.cLine + '" stroke-width="0.8"/>',
        '</pattern></defs>',
        '<rect x="-200" y="-200" width="1000" height="1200" fill="url(#' + id + ')"/>',
        '</g>'
      ];
      return out.join('');
    },

    /* 三角棱镜 */
    prism: function (rnd, p) {
      var cx = 160 + rnd() * 280;
      var cy = 240 + rnd() * 240;
      var size = 190 + rnd() * 120;
      var out = ['<g opacity="0.72">'];
      for (var i = 0; i < 3; i++) {
        var s = size * (1 - i * 0.24);
        var off = i * (26 + rnd() * 22);
        var pts = [
          [cx + off, cy - s * 0.58],
          [cx + s * 0.52 + off, cy + s * 0.42],
          [cx - s * 0.52 + off, cy + s * 0.42]
        ].map(function (pt) { return r1(pt[0]) + ',' + r1(pt[1]); }).join(' ');
        out.push(
          '<polygon points="' + pts + '" fill="' + (i === 0 ? 'none' : p.cSoft) +
          '" stroke="' + p.c2 + '" stroke-width="' + r1(1.2 + rnd() * 1.6) +
          '" stroke-opacity="' + r1(0.5 - i * 0.1) + '"/>'
        );
      }
      out.push('</g>');
      return out.join('');
    },

    /* 斜向光带 */
    beam: function (rnd, p) {
      var rot = -18 + (rnd() - 0.5) * 30;
      var x = 60 + rnd() * 240;
      return (
        '<g transform="rotate(' + r1(rot) + ' 300 400)" opacity="0.7">' +
        '<rect x="' + r1(x) + '" y="-260" width="' + r1(60 + rnd() * 90) + '" height="1320" fill="' + p.light + '"/>' +
        '<rect x="' + r1(x + 110) + '" y="-260" width="' + r1(14 + rnd() * 26) + '" height="1320" fill="' + p.cSoft + '"/>' +
        '</g>'
      );
    }
  };

  var MOTIF_KEYS = ['rings', 'arcs', 'bands', 'halftone', 'grid', 'prism', 'beam'];

  /* ---------- 纹理（hatch + 噪点，均用 pattern，避免大滤镜开销） ---------- */
  function texture(rnd, p) {
    var idA = 'tx' + Math.floor(rnd() * 1e6);
    var idB = 'tx' + Math.floor(rnd() * 1e6) + 'b';
    var gap = 5 + Math.floor(rnd() * 4);
    return (
      '<g opacity="' + r1(0.1 + rnd() * 0.08) + '">' +
      '<defs>' +
      '<pattern id="' + idA + '" width="' + gap + '" height="' + gap + '" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">' +
      '<line x1="0" y1="0" x2="0" y2="' + gap + '" stroke="#ffffff" stroke-width="0.7" stroke-opacity="0.5"/>' +
      '</pattern>' +
      '<pattern id="' + idB + '" width="14" height="14" patternUnits="userSpaceOnUse">' +
      '<circle cx="2" cy="3" r="0.55" fill="#ffffff" opacity="0.7"/>' +
      '<circle cx="9" cy="8" r="0.45" fill="#ffffff" opacity="0.5"/>' +
      '<circle cx="5" cy="12" r="0.4" fill="#000000" opacity="0.4"/>' +
      '</pattern>' +
      '</defs>' +
      '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="url(#' + idA + ')"/>' +
      '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="url(#' + idB + ')"/>' +
      '</g>'
    );
  }

  /* ---------- 标题排版 ---------- */
  function unitOf(ch) {
    /* 中日韩字符按 1 个字宽，拉丁/数字按 0.56 */
    return /[\u2e80-\u9fff\uf900-\ufaff\uff00-\uffef\u3000-\u303f]/.test(ch) ? 1 : 0.56;
  }

  function unitsOf(str) {
    var u = 0;
    for (var i = 0; i < str.length; i++) u += unitOf(str.charAt(i));
    return u;
  }

  function truncateTo(str, budget) {
    var u = 0;
    var out = '';
    for (var i = 0; i < str.length; i++) {
      var w = unitOf(str.charAt(i));
      if (u + w + 0.6 > budget) break;
      u += w;
      out += str.charAt(i);
    }
    return out.replace(/[\s·]+$/, '') + '…';
  }

  /* 中文断行禁则：
     NO_START —— 这些字符不允许出现在行首（标点、收尾括号、连字符等）
     NO_END   —— 这些字符不允许留在行尾（开括号、开引号） */
  var NO_START = [
    '：', ':', '，', ',', '。', '、', '·', '；', ';', '！', '!', '？', '?',
    '—', '…', '－', '-', '～', '／', '/', '）', ')', '》', '>', '」', '』', '】', '〉', '〕',
    '”', '’', '"', "'"
  ];
  var NO_END = ['（', '(', '《', '<', '「', '『', '【', '〈', '〔', '“', '‘', '"', "'"];

  /* 把标题拆成最多两行：优先在标点/空格后断开，且满足行首行尾禁则 */
  function splitTitle(cn, maxLines) {
    var s = String(cn).trim();
    var total = unitsOf(s);
    if (maxLines === 1 || total <= 5.4) return [s];

    var best = null;
    for (var i = 1; i < s.length; i++) {
      var head = s.charAt(i);
      var tail = s.charAt(i - 1);
      if (NO_START.indexOf(head) >= 0) continue;  /* 标点不得行首 */
      if (NO_END.indexOf(tail) >= 0) continue;    /* 开括号不得行尾 */

      var left = unitsOf(s.slice(0, i));
      var right = total - left;
      if (right <= 0.4) continue;

      var score = Math.abs(left - right);
      if (NO_START.indexOf(tail) >= 0) score -= 2.6;      /* 标点后断开最优 */
      else if (/\s/.test(tail)) score -= 1.4;             /* 空格次之 */

      if (!best || score < best.score) best = { score: score, i: i };
    }

    if (!best) {
      /* 兜底：找不到合法断点时，把紧邻的标点并回上一行 */
      var mid = Math.ceil(s.length / 2);
      while (mid < s.length && NO_START.indexOf(s.charAt(mid)) >= 0) mid++;
      if (mid >= s.length) return [s];
      best = { i: mid };
    }

    var lines = [s.slice(0, best.i).trim(), s.slice(best.i).trim()];

    /* 二次兜底：并入残留的行首标点，保证第二行一定以正文字符开头 */
    while (lines[1] && NO_START.indexOf(lines[1].charAt(0)) >= 0) {
      lines[0] += lines[1].charAt(0);
      lines[1] = lines[1].slice(1).trim();
    }

    return lines.filter(Boolean);
  }

  function titleBlock(cn, en) {
    var usable = W - 76 - 10;      // 左右各 38 内边距，再留 10px 安全余量
    var lines = splitTitle(cn, 2);

    var maxUnits = 0;
    for (var i = 0; i < lines.length; i++) maxUnits = Math.max(maxUnits, unitsOf(lines[i]));

    var size = Math.min(58, Math.floor(usable / Math.max(maxUnits, 1)));
    size = Math.max(size, 25);

    /* 仍然放不下就截断（极小概率，兜底防溢出） */
    var budget = usable / size;
    for (var j = 0; j < lines.length; j++) {
      if (unitsOf(lines[j]) > budget) lines[j] = truncateTo(lines[j], budget);
    }

    var lh = Math.round(size * 1.16);
    var enSize = 14;
    var enText = String(en || '');
    /* 英文副标题限一行，超长截断 */
    while (unitsOf(enText) * (enSize / 14) > (usable / 14) && enSize > 11) enSize -= 1;
    if (unitsOf(enText) > usable / enSize * 0.98) {
      enText = truncateTo(enText, (usable / enSize) * 0.96);
    }

    var enY = H - 42;
    var titleBottom = enY - 30;
    var out = [];

    out.push(
      '<text x="38" y="' + r1(enY) + '" font-size="' + enSize +
      '" font-weight="600" letter-spacing="0.6" fill="#ffffff" fill-opacity="0.62" ' +
      'font-family="-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif">' +
      esc(enText) + '</text>'
    );

    for (var k = lines.length - 1; k >= 0; k--) {
      var y = titleBottom - (lines.length - 1 - k) * lh;
      out.push(
        '<text x="38" y="' + r1(y) + '" font-size="' + size +
        '" font-weight="800" letter-spacing="-0.5" fill="#ffffff" ' +
        'font-family="-apple-system,BlinkMacSystemFont,\'PingFang SC\',\'Microsoft YaHei\',sans-serif">' +
        esc(lines[k]) + '</text>'
      );
    }

    return out.join('');
  }

  /* ---------- 类型胶囊 ---------- */
  function genrePill(genre) {
    var label = String(genre || '');
    var wText = unitsOf(label) * 14;
    var w = Math.round(wText + 30);
    return (
      '<g>' +
      '<rect x="38" y="38" width="' + w + '" height="32" rx="16" fill="#ffffff" fill-opacity="0.14" ' +
      'stroke="#ffffff" stroke-opacity="0.26"/>' +
      '<text x="' + (38 + w / 2) + '" y="59" text-anchor="middle" font-size="14" font-weight="700" ' +
      'letter-spacing="0.4" fill="#ffffff" fill-opacity="0.94" ' +
      'font-family="-apple-system,BlinkMacSystemFont,\'PingFang SC\',\'Microsoft YaHei\',sans-serif">' +
      esc(label) + '</text>' +
      '</g>'
    );
  }

  /* ---------- 缓存 ---------- */
  var cache = new Map();

  function buildSvg(game, opts) {
    opts = opts || {};
    var seedStr = String(game.cn || '') + '|' + String(game.en || '') + '|' + String(game.id || '');
    var seed = hash(seedStr);
    var rnd = makeRng(seed);
    var p = makePalette(game.genre, rnd);

    /* 母题：主母题 + 55% 概率叠加副母题，二者不同 */
    var pool = MOTIF_KEYS.slice();
    var a = pool.splice(Math.floor(rnd() * pool.length), 1)[0];
    var b = pool[Math.floor(rnd() * pool.length)];
    var motifA = MOTIFS[a](rnd, p);
    var motifB = rnd() < 0.78 ? MOTIFS[b](rnd, p) : '';

    /* 渐变方向随种子变化，避免所有封面同向 */
    var angle = [0.5, 1.2, 0.85][Math.floor(rnd() * 3)];
    var x1 = r1(0.1 + Math.cos(angle) * 0.35);
    var y1 = r1(0.05);
    var x2 = r1(0.9 - Math.cos(angle) * 0.2);
    var y2 = r1(0.95);

    var svg = [
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '">',
      '<defs>',
      '<linearGradient id="bg" x1="' + x1 + '" y1="' + y1 + '" x2="' + x2 + '" y2="' + y2 + '">',
      '<stop offset="0" stop-color="' + p.c0 + '"/>',
      '<stop offset="0.62" stop-color="' + p.c1 + '"/>',
      '<stop offset="1" stop-color="' + p.c0 + '"/>',
      '</linearGradient>',
      '<radialGradient id="glow" cx="0.72" cy="0.2" r="0.72">',
      '<stop offset="0" stop-color="' + p.c2 + '" stop-opacity="0.5"/>',
      '<stop offset="1" stop-color="' + p.c2 + '" stop-opacity="0"/>',
      '</radialGradient>',
      '<linearGradient id="scrim" x1="0" y1="0" x2="0" y2="1">',
      '<stop offset="0" stop-color="#05080e" stop-opacity="0"/>',
      '<stop offset="0.45" stop-color="#05080e" stop-opacity="0.34"/>',
      '<stop offset="1" stop-color="#05080e" stop-opacity="0.82"/>',
      '</linearGradient>',
      '</defs>',
      '<rect width="' + W + '" height="' + H + '" fill="url(#bg)"/>',
      '<rect width="' + W + '" height="' + H + '" fill="url(#glow)"/>',
      motifA,
      motifB,
      texture(rnd, p),
      '<rect y="' + (H - 340) + '" width="' + W + '" height="340" fill="url(#scrim)"/>',
      '<rect x="0.5" y="0.5" width="' + (W - 1) + '" height="' + (H - 1) + '" fill="none" stroke="#ffffff" stroke-opacity="0.08"/>',
      opts.pill === false ? '' : genrePill(game.genre),
      titleBlock(game.cn, game.en),
      '</svg>'
    ].join('');

    return svg;
  }

  function render(game, opts) {
    if (!game) return '';
    /* 缓存键必须带上 pill 开关：同一部作品在卡片（无胶囊）与详情（有胶囊）下是两张图 */
    var key = (game.id || game.cn) +
      '|' + (opts && opts.variant ? opts.variant : '') +
      '|' + (opts && opts.pill === false ? 'nopill' : 'pill');
    var hit = cache.get(key);
    if (hit) return hit;
    var uri = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(buildSvg(game, opts));
    cache.set(key, uri);
    return uri;
  }

  /* 便捷挂载：把封面放进容器（容器先给好尺寸） */
  function renderInto(el, game, opts) {
    if (!el || !game) return null;
    var img = el.querySelector('img[data-cover]');
    if (!img) {
      img = document.createElement('img');
      img.setAttribute('data-cover', game.id);
      img.setAttribute('decoding', 'async');
      img.setAttribute('loading', 'lazy');
      img.width = W;
      img.height = H;
      el.appendChild(img);
    }
    var alt = game.cn + ' 封面';
    if (img.getAttribute('alt') !== alt) img.setAttribute('alt', alt);
    var src = render(game, opts);
    if (img.getAttribute('src') !== src) img.setAttribute('src', src);
    return img;
  }

  /* ======================================================================
     横版场景静帧（16:9）
     与封面同源：同一套类型调色板 + 确定性种子，但构图换成景别 ——
     天空 / 地景层次 / 光源 / 雾与颗粒，读起来像一张游戏静帧而非竖版海报。
     ====================================================================== */
  var SHOT_W = 1200;
  var SHOT_H = 675;
  var shotCache = new Map();

  /* 起伏的天际线 / 山脊：向下闭合成面，用作地景层 */
  function ridgePath(rnd, baseY, amp, step, floorY) {
    var d = 'M -30 ' + r1(baseY);
    for (var x = 0; x <= SHOT_W + 30; x += step) {
      d += ' L ' + r1(x) + ' ' + r1(baseY - rnd() * amp);
    }
    d += ' L ' + (SHOT_W + 30) + ' ' + r1(floorY) + ' L -30 ' + r1(floorY) + ' Z';
    return d;
  }

  function moteLayer(rnd, p, n, maxR) {
    var out = ['<g fill="' + p.c2 + '">'];
    for (var i = 0; i < n; i++) {
      out.push(
        '<circle cx="' + r1(rnd() * SHOT_W) + '" cy="' + r1(rnd() * SHOT_H) +
        '" r="' + r1(0.6 + rnd() * maxR) + '" opacity="' + r1(0.14 + rnd() * 0.5) + '"/>'
      );
    }
    out.push('</g>');
    return out.join('');
  }

  var SHOTS = [
    /* 0 地平线：低垂天光 + 远山剪影 */
    function (rnd, p) {
      var hz = SHOT_H * (0.54 + rnd() * 0.12);
      var sunX = SHOT_W * (0.26 + rnd() * 0.46);
      var sunR = 52 + rnd() * 56;
      return [
        '<rect width="' + SHOT_W + '" height="' + r1(hz) + '" fill="url(#sky)"/>',
        '<circle cx="' + r1(sunX) + '" cy="' + r1(hz) + '" r="' + r1(sunR) + '" fill="' + p.c2 + '" opacity="0.3"/>',
        '<circle cx="' + r1(sunX) + '" cy="' + r1(hz) + '" r="' + r1(sunR * 0.44) + '" fill="' + p.c2 + '" opacity="0.62"/>',
        '<path d="' + ridgePath(rnd, hz - 16, 92, 96, hz) + '" fill="' + p.c0 + '" opacity="0.62"/>',
        '<rect y="' + r1(hz) + '" width="' + SHOT_W + '" height="' + r1(SHOT_H - hz) + '" fill="' + p.c0 + '" opacity="0.94"/>',
        '<path d="' + ridgePath(rnd, hz + 30, 46, 74, SHOT_H) + '" fill="' + p.c0 + '" opacity="0.9"/>',
        '<rect y="' + r1(hz - 42) + '" width="' + SHOT_W + '" height="96" fill="url(#fog)"/>',
        moteLayer(rnd, p, 26, 1.6)
      ].join('');
    },

    /* 1 长廊：灭点透视 + 地面网格 */
    function (rnd, p) {
      var vx = SHOT_W * (0.38 + rnd() * 0.24);
      var vy = SHOT_H * (0.42 + rnd() * 0.12);
      var out = ['<rect width="' + SHOT_W + '" height="' + SHOT_H + '" fill="' + p.c0 + '"/>'];
      out.push('<rect width="' + SHOT_W + '" height="' + SHOT_H + '" fill="url(#sky)" opacity="0.34"/>');

      /* 两侧墙面 */
      out.push('<path d="M0 0 L' + r1(vx) + ' ' + r1(vy) + ' L' + r1(vx) + ' ' + SHOT_H + ' L0 ' + SHOT_H + ' Z" fill="' + p.c1 + '" opacity="0.5"/>');
      out.push('<path d="M' + SHOT_W + ' 0 L' + r1(vx) + ' ' + r1(vy) + ' L' + r1(vx) + ' ' + SHOT_H + ' L' + SHOT_W + ' ' + SHOT_H + ' Z" fill="' + p.c1 + '" opacity="0.3"/>');

      /* 地面网格：从灭点放射 */
      var g = ['<g stroke="' + p.cLine + '" stroke-width="1" opacity="0.5">'];
      for (var i = -6; i <= 6; i++) {
        g.push('<path d="M' + r1(vx + i * 14) + ' ' + r1(vy) + ' L' + r1(vx + i * 190) + ' ' + SHOT_H + '" fill="none"/>');
      }
      for (var k = 1; k <= 6; k++) {
        var y = vy + (SHOT_H - vy) * Math.pow(k / 6, 2.1);
        g.push('<path d="M0 ' + r1(y) + ' H' + SHOT_W + '" fill="none" opacity="' + r1(0.2 + k * 0.09) + '"/>');
      }
      g.push('</g>');
      out.push(g.join(''));

      /* 顶部灯带 */
      var lights = ['<g>'];
      for (var j = 0; j < 5; j++) {
        var t = j / 5;
        var lx = vx + (SHOT_W * 0.12 - vx) * t;
        lights.push('<rect x="' + r1(lx) + '" y="' + r1(vy - (vy - 30) * t) + '" width="' + r1(60 - 46 * t) +
          '" height="' + r1(7 - 5 * t) + '" rx="2" fill="' + p.c2 + '" opacity="' + r1(0.5 - t * 0.3) + '"/>');
      }
      lights.push('</g>');
      out.push(lights.join(''));

      out.push('<defs><radialGradient id="vp" cx="0.5" cy="0.5" r="0.5">' +
        '<stop offset="0" stop-color="' + p.c2 + '" stop-opacity="0.42"/>' +
        '<stop offset="0.55" stop-color="' + p.c2 + '" stop-opacity="0.1"/>' +
        '<stop offset="1" stop-color="' + p.c2 + '" stop-opacity="0"/>' +
        '</radialGradient></defs>');
      out.push('<rect x="' + r1(vx - 300) + '" y="' + r1(vy - 300) + '" width="600" height="600" fill="url(#vp)"/>');
      out.push(moteLayer(rnd, p, 22, 1.4));
      return out.join('');
    },

    /* 2 城郭：层叠楼群 + 双月 */
    function (rnd, p) {
      var hz = SHOT_H * 0.72;
      var out = ['<rect width="' + SHOT_W + '" height="' + SHOT_H + '" fill="url(#sky)"/>'];
      out.push('<circle cx="' + r1(SHOT_W * 0.74) + '" cy="' + r1(SHOT_H * 0.24) + '" r="' + r1(30 + rnd() * 18) + '" fill="' + p.c2 + '" opacity="0.45"/>');
      out.push('<circle cx="' + r1(SHOT_W * 0.84) + '" cy="' + r1(SHOT_H * 0.34) + '" r="' + r1(11 + rnd() * 8) + '" fill="' + p.cLine + '"/>');

      for (var layer = 0; layer < 3; layer++) {
        var baseY = hz - layer * 34;
        var x = -20 + rnd() * 30;
        var blocks = ['<g opacity="' + r1(0.5 + layer * 0.22) + '">'];
        while (x < SHOT_W + 20) {
          var bw = 42 + rnd() * 96;
          var bh = (44 + rnd() * 150) * (1 - layer * 0.16);
          var top = baseY - bh;
          blocks.push('<rect x="' + r1(x) + '" y="' + r1(top) + '" width="' + r1(bw) + '" height="' + r1(bh + 200) + '" fill="' + p.c0 + '"/>');
          if (layer === 2) {
            for (var wi = 0; wi < 4; wi++) {
              for (var wj = 0; wj < 3; wj++) {
                if (rnd() < 0.42) continue;
                blocks.push('<rect x="' + r1(x + 8 + wi * 14) + '" y="' + r1(top + 12 + wj * 18) +
                  '" width="6" height="8" fill="' + p.c2 + '" opacity="' + r1(0.3 + rnd() * 0.55) + '"/>');
              }
            }
          }
          x += bw + 6 + rnd() * 16;
        }
        blocks.push('</g>');
        out.push(blocks.join(''));
      }

      out.push('<rect y="' + r1(hz) + '" width="' + SHOT_W + '" height="' + r1(SHOT_H - hz) + '" fill="' + p.c0 + '"/>');
      out.push('<rect y="' + r1(hz - 60) + '" width="' + SHOT_W + '" height="120" fill="url(#fog)"/>');
      out.push(moteLayer(rnd, p, 16, 1.2));
      return out.join('');
    },

    /* 3 旷野：沙丘 / 雾谷 + 斜射光束 */
    function (rnd, p) {
      var out = ['<rect width="' + SHOT_W + '" height="' + SHOT_H + '" fill="url(#sky)"/>'];
      for (var i = 0; i < 4; i++) {
        var y = SHOT_H * (0.36 + i * 0.16);
        var lift = 40 + rnd() * 50;
        var d = 'M -30 ' + r1(y);
        d += ' C ' + r1(SHOT_W * 0.22) + ' ' + r1(y - lift) + ', ' + r1(SHOT_W * 0.42) + ' ' + r1(y + lift * 0.5) +
          ', ' + r1(SHOT_W * 0.58) + ' ' + r1(y - lift * 0.7);
        d += ' S ' + r1(SHOT_W * 0.9) + ' ' + r1(y + lift * 0.4) + ', ' + r1(SHOT_W + 30) + ' ' + r1(y - lift * 0.2);
        d += ' L ' + (SHOT_W + 30) + ' ' + SHOT_H + ' L -30 ' + SHOT_H + ' Z';
        out.push('<path d="' + d + '" fill="' + (i % 2 ? p.c1 : p.c0) + '" opacity="' + r1(0.5 + i * 0.13) + '"/>');
      }
      out.push('<rect x="' + r1(SHOT_W * 0.44) + '" y="-40" width="' + r1(70 + rnd() * 60) +
        '" height="' + (SHOT_H + 80) + '" fill="' + p.light +
        '" transform="rotate(14 ' + r1(SHOT_W * 0.5) + ' ' + r1(SHOT_H * 0.5) + ')"/>');
      out.push('<rect y="' + r1(SHOT_H * 0.42) + '" width="' + SHOT_W + '" height="120" fill="url(#fog)"/>');
      out.push(moteLayer(rnd, p, 34, 1.8));
      return out.join('');
    },

    /* 4 遗迹：环形拱门 + 石柱 */
    function (rnd, p) {
      var cx = SHOT_W * (0.34 + rnd() * 0.32);
      var cy = SHOT_H * (0.52 + rnd() * 0.1);
      var r = 150 + rnd() * 70;
      var out = ['<rect width="' + SHOT_W + '" height="' + SHOT_H + '" fill="' + p.c0 + '"/>'];
      out.push('<rect width="' + SHOT_W + '" height="' + SHOT_H + '" fill="url(#sky)" opacity="0.4"/>');
      out.push('<circle cx="' + r1(cx) + '" cy="' + r1(cy) + '" r="' + r1(r) + '" fill="none" stroke="' + p.cLine + '" stroke-width="' + r1(14 + rnd() * 10) + '" opacity="0.7"/>');
      out.push('<circle cx="' + r1(cx) + '" cy="' + r1(cy) + '" r="' + r1(r * 1.34) + '" fill="none" stroke="' + p.c2 + '" stroke-width="1.4" stroke-dasharray="22 16" opacity="0.45"/>');
      out.push('<circle cx="' + r1(cx) + '" cy="' + r1(cy) + '" r="' + r1(r * 0.82) + '" fill="' + p.c2 + '" opacity="0.1"/>');

      var cols = ['<g>'];
      for (var i = 0; i < 5; i++) {
        var x = SHOT_W * (0.08 + i * 0.2) + rnd() * 20;
        var hgt = SHOT_H * (0.28 + rnd() * 0.2);
        var wdt = 26 + rnd() * 22;
        cols.push('<rect x="' + r1(x) + '" y="' + r1(SHOT_H - hgt) + '" width="' + r1(wdt) + '" height="' + r1(hgt) + '" fill="' + p.c0 + '" opacity="0.86"/>');
        cols.push('<rect x="' + r1(x) + '" y="' + r1(SHOT_H - hgt) + '" width="' + r1(wdt) + '" height="10" fill="' + p.cLine + '" opacity="0.4"/>');
      }
      cols.push('</g>');
      out.push(cols.join(''));
      out.push('<rect y="' + r1(SHOT_H * 0.62) + '" width="' + SHOT_W + '" height="140" fill="url(#fog)"/>');
      out.push(moteLayer(rnd, p, 30, 1.6));
      return out.join('');
    }
  ];

  function buildShot(game, index) {
    var seed = hash(String(game.id || game.cn || '') + '#shot#' + index);
    var rnd = makeRng(seed);
    var p = makePalette(game.genre, rnd);
    var scene = SHOTS[Math.abs(index) % SHOTS.length](rnd, p);

    return [
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + SHOT_W + ' ' + SHOT_H + '" width="' + SHOT_W + '" height="' + SHOT_H + '">',
      '<defs>',
      '<linearGradient id="sky" x1="0" y1="0" x2="0.2" y2="1">',
      '<stop offset="0" stop-color="' + p.c0 + '"/>',
      '<stop offset="0.5" stop-color="' + p.c1 + '"/>',
      '<stop offset="1" stop-color="' + p.c0 + '"/>',
      '</linearGradient>',
      '<linearGradient id="fog" x1="0" y1="0" x2="0" y2="1">',
      '<stop offset="0" stop-color="' + p.c2 + '" stop-opacity="0"/>',
      '<stop offset="0.5" stop-color="' + p.c2 + '" stop-opacity="0.13"/>',
      '<stop offset="1" stop-color="' + p.c2 + '" stop-opacity="0"/>',
      '</linearGradient>',
      '<radialGradient id="vig" cx="0.5" cy="0.46" r="0.78">',
      '<stop offset="0.5" stop-color="#04070d" stop-opacity="0"/>',
      '<stop offset="1" stop-color="#04070d" stop-opacity="0.6"/>',
      '</radialGradient>',
      '<pattern id="grain" width="6" height="6" patternUnits="userSpaceOnUse">',
      '<circle cx="1" cy="1" r="0.5" fill="#ffffff" opacity="0.05"/>',
      '<circle cx="4" cy="3.5" r="0.4" fill="#000000" opacity="0.06"/>',
      '</pattern>',
      '</defs>',
      scene,
      '<rect width="' + SHOT_W + '" height="' + SHOT_H + '" fill="url(#grain)"/>',
      '<rect width="' + SHOT_W + '" height="' + SHOT_H + '" fill="url(#vig)"/>',
      '</svg>'
    ].join('');
  }

  function renderShot(game, index) {
    if (!game) return '';
    index = Math.abs(index || 0);
    var key = (game.id || game.cn) + '#shot#' + index;
    var hit = shotCache.get(key);
    if (hit) return hit;
    var uri = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(buildShot(game, index));
    shotCache.set(key, uri);
    return uri;
  }

  function renderShotInto(el, game, index) {
    if (!el || !game) return null;
    var img = el.querySelector('img[data-shot]');
    if (!img) {
      img = document.createElement('img');
      img.setAttribute('data-shot', String(index));
      img.setAttribute('decoding', 'async');
      img.setAttribute('loading', 'lazy');
      img.width = SHOT_W;
      img.height = SHOT_H;
      el.appendChild(img);
    }
    var alt = game.cn + ' 场景 ' + (index + 1);
    if (img.getAttribute('alt') !== alt) img.setAttribute('alt', alt);
    var src = renderShot(game, index);
    if (img.getAttribute('src') !== src) img.setAttribute('src', src);
    return img;
  }

  window.CoverEngine = {
    render: render,
    renderInto: renderInto,
    renderShot: renderShot,
    renderShotInto: renderShotInto,
    shotCount: SHOTS.length,
    buildSvg: buildSvg,
    genreFamily: function (genre) { return GENRE_FAMILY[genre] || 'steel'; },
    families: FAMILIES,
    clearCache: function () { cache.clear(); shotCache.clear(); }
  };
})();
